"use strict";
var ajaxurl = ep_data.ajaxurl;
var loader_image = ep_data.loading_image;
var pdf_image_url = ep_data.pdf_image_url;

jQuery(window).on("load", function () {
  if (jQuery(".epinputdate")[0]) {
    jQuery(".epinputdate").datepicker();
  }
});
function edit_gallery_image(profile_image_id) {
  var image_gallery_frame;
  var hidden_field_image_ids = jQuery("#gallery_image_ids").val();
  image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
    title: ep_data.set_image,
    button: {
      text: ep_data.set_image,
    },
    multiple: true,
    displayUserSettings: true,
  });
  image_gallery_frame.on("select", function () {
    var selection = image_gallery_frame.state().get("selection");
    selection.map(function (attachment) {
      attachment = attachment.toJSON();
      console.log(attachment);
      if (attachment.id) {
        jQuery("#" + profile_image_id).append(
          '<div id="gallery_image_div' +
            attachment.id +
            '" class="col-md-4"><img  class="img-responsive"  src="' +
            attachment.sizes.thumbnail.url +
            '"><button type="button" onclick="remove_gallery_image(\'gallery_image_div' +
            attachment.id +
            "', " +
            attachment.id +
            ');"  class="btn btn-xs btn-danger">X</button> </div>'
        );
        hidden_field_image_ids = hidden_field_image_ids + "," + attachment.id;
        jQuery("#gallery_image_ids").val(hidden_field_image_ids);
      }
    });
  });
  image_gallery_frame.open();
}
function remove_gallery_image(img_remove_div, rid) {
  var hidden_field_image_ids = jQuery("#gallery_image_ids").val();
  hidden_field_image_ids = hidden_field_image_ids.replace(rid, "");
  jQuery("#" + img_remove_div).remove();
  jQuery("#gallery_image_ids").val(hidden_field_image_ids);
}
//*****DOC Start****************
function update_profile_image_doc() {
  jQuery("#update_message_gallery").html(loader_image);
  var search_params = {
    action: "iv_membership_update_profile_doc",
    form_data: jQuery("#profile_images_form").serialize(),
    _wpnonce: ep_data.dirwpnonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message_gallery").html(
        '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
          response.msg +
          ".</div>"
      );
    },
  });
}
function edit_gallery_doc(profile_doc_id) {
  var image_gallery_frame;
  var hidden_field_image_ids = jQuery("#gallery_doc_ids").val();
  image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
    title: "PDF Doc ",
    button: {
      text: "PDF DOC",
    },
    multiple: true,
    library: { type: "application/pdf" },
    displayUserSettings: true,
  });
  image_gallery_frame.on("select", function () {
    var selection = image_gallery_frame.state().get("selection");
    selection.map(function (attachment) {
      attachment = attachment.toJSON();
      console.log(attachment);
      if (attachment.id) {
        jQuery("#" + profile_doc_id).append(
          '<div id="gallery_doc_div' +
            attachment.id +
            '" class="col-md-4"><img  class="img-responsive"  src="' +
            pdf_image_url +
            '"><button type="button" onclick="remove_gallery_doc(\'gallery_doc_div' +
            attachment.id +
            "', " +
            attachment.id +
            ');"  class="btn btn-xs btn-danger">X</button> </div>'
        );
        hidden_field_image_ids = hidden_field_image_ids + "," + attachment.id;
        jQuery("#gallery_doc_ids").val(hidden_field_image_ids);
      }
    });
  });
  image_gallery_frame.open();
}
function remove_gallery_doc(img_remove_div, rid) {
  var hidden_field_image_ids = jQuery("#gallery_doc_ids").val();
  hidden_field_image_ids = hidden_field_image_ids.replace(rid, "");
  jQuery("#" + img_remove_div).remove();
  jQuery("#gallery_doc_ids").val(hidden_field_image_ids);
}

function delete_message_myaccount(h_id, divename) {
  var search_params = {
    action: "wpmembership_message_delete",
    data: "id=" + h_id,
    _wpnonce: ep_data.dirwpnonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message").html("");
      if (response.msg == "success") {
        jQuery("#" + divename + "_" + h_id).fadeOut(500, function () {
          jQuery(this).remove();
        });
      } else {
        alert("Try later");
      }
    },
  });
}
function candidate_bookmark_delete_myaccount(h_id, divename) {
  var search_params = {
    action: "wpmembership_profile_bookmark_delete",
    data: "id=" + h_id,
    _wpnonce: ep_data.dirwpnonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message").html("");
      if (response.msg == "success") {
        jQuery("#" + divename + "_" + h_id).fadeOut(500, function () {
          jQuery(this).remove();
        });
      } else {
        alert("Try later");
      }
    },
  });
}
jQuery(document).ready(function ($) {
  if (jQuery("#user-bookmark")[0]) {
    jQuery("#user-bookmark").show();
    var oTablecandidate = jQuery("#user-bookmark").dataTable({
      language: {
        sProcessing: ep_data.sProcessing,
        sSearch: "",
        searchPlaceholder: ep_data.sSearch,
        lengthMenu: ep_data.lengthMenu,
        zeroRecords: ep_data.zeroRecords,
        info: ep_data.info,
        infoEmpty: ep_data.infoEmpty,
        infoFiltered: ep_data.infoFiltered,

        oPaginate: {
          sFirst: ep_data.sFirst,
          sLast: ep_data.sLast,
          sNext: ep_data.sNext,
          sPrevious: ep_data.sPrevious,
        },
      },
    });
    //oTablecandidate.fnSort( [ [1,'DESC'] ] );
  }
});
function iv_update_hide_setting() {
  jQuery("#update_message_hide").html(loader_image);
  var search_params = {
    action: "iv_membership_update_setting_hide",
    form_data: jQuery("#setting_hide_form").serialize(),
    _wpnonce: ep_data.profilenonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message_hide").html(
        '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
          response.msg +
          ".</div>"
      );
    },
  });
}

function iv_update_fb() {
  jQuery("#update_message_fb").html(loader_image);
  var search_params = {
    action: "iv_membership_update_setting_fb",
    form_data: jQuery("#setting_fb").serialize(),
    _wpnonce: ep_data.profilenonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message_fb").html(
        '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
          response.msg +
          ".</div>"
      );
    },
  });
}
function iv_update_password() {
  jQuery("#update_message_pass").html(loader_image);
  var search_params = {
    action: "iv_membership_update_setting_password",
    form_data: jQuery("#pass_word").serialize(),
    _wpnonce: ep_data.profilenonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message_pass").html(
        '<div class="bg-[#eec42d] p-2 rounded text-black">' +
          response.msg +
          ".</div>"
      );
    },
  });
}

function edit_profile_image(profile_image_id) {
  var image_gallery_frame;
  image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
    title: ep_data.set_image,
    button: {
      text: ep_data.set_image,
    },
    multiple: false,
    displayUserSettings: true,
  });
  image_gallery_frame.on("select", function () {
    var selection = image_gallery_frame.state().get("selection");
    selection.map(function (attachment) {
      attachment = attachment.toJSON();
      if (attachment.id) {
        var search_params = {
          action: "iv_membership_update_profile_pic",
          attachment_thum: attachment.sizes.thumbnail.url,
          profile_pic_url_1: attachment.url,
          _wpnonce: ep_data.profilenonce,
        };
        jQuery.ajax({
          url: ajaxurl,
          dataType: "json",
          type: "post",
          data: search_params,
          success: function (response) {
            if (response == "success") {
              jQuery("#" + profile_image_id).html(
                '<img  class="img-circle img-responsive"  src="' +
                  attachment.sizes.thumbnail.url +
                  '">'
              );
            }
          },
        });
      }
    });
  });
  image_gallery_frame.open();
}
function update_profile_setting() {
  jQuery("#update_message").html(loader_image);
  var search_params = {
    action: "iv_membership_update_profile_setting",
    form_data: jQuery("#profile_setting_form").serialize(),
    _wpnonce: ep_data.profilenonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message").html(
        '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
          response.msg +
          ".</div>"
      );
    },
  });
}
function iv_save_post() {
  tinyMCE.triggerSave();
  jQuery("#update_message").html(loader_image);
  var search_params = {
    action: "iv_membership_save_wp_post",
    form_data: jQuery("#new_post").serialize(),
    _wpnonce: ep_data.profilenonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      if (response.code == "success") {
        var url = ep_data.all_postpage;
        jQuery(location).attr("href", url);
      }
    },
  });
}
function iv_cancel_membership_paypal() {
  if (confirm("Are you sure to cancel this Membership?")) {
    jQuery("#update_message_paypal").html(loader_image);
    var search_params = {
      action: "iv_membership_cancel_paypal",
      form_data: jQuery("#paypal_cancel_form").serialize(),
      _wpnonce: ep_data.profilenonce,
    };
    jQuery.ajax({
      url: ajaxurl,
      dataType: "json",
      type: "post",
      data: search_params,
      success: function (response) {
        if (response.code == "success") {
          jQuery("#paypal_cancel_div").hide();
          jQuery("#update_message_paypal").html(
            '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
              response.msg +
              ".</div>"
          );
        } else {
          jQuery("#update_message_paypal").html(
            '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
              response.msg +
              ".</div>"
          );
        }
      },
    });
  }
}
function iv_cancel_membership_stripe() {
  if (confirm("Are you sure to cancel this Membership?")) {
    jQuery("#update_message_stripe").html(loader_image);
    var search_params = {
      action: "iv_membership_cancel_stripe",
      form_data: jQuery("#profile_cancel_form").serialize(),
      _wpnonce: ep_data.profilenonce,
    };
    jQuery.ajax({
      url: ajaxurl,
      dataType: "json",
      type: "post",
      data: search_params,
      success: function (response) {
        jQuery("#stripe_cancel_div").hide();
        jQuery("#update_message_stripe").html(
          '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
            response.msg +
            ".</div>"
        );
      },
    });
  }
}

jQuery(function () {
  jQuery("#package_sel").on("change", function (e) {
    var optionSelected = jQuery("option:selected", this);
    var pack_id = this.value;
    jQuery("#package_id").val(pack_id);

    var search_params = {
      action: "iv_membership_check_package_amount",
      coupon_code: jQuery("#coupon_name").val(),
      package_id: pack_id,
      package_amount: "",
      form_data: jQuery("#profile_upgrade_form").serialize(),
      api_currency: ep_data.currencyCode,
      _wpnonce: ep_data.signup,
    };
    jQuery.ajax({
      url: ajaxurl,
      dataType: "json",
      type: "post",
      data: search_params,
      success: function (response) {
        if (response.code == "success") {
          jQuery("#coupon-result").html(
            '<img src="<?php echo WP_iv_membership_URLPATH; ?>admin/files/images/right_icon.png">'
          );
        } else {
          jQuery("#coupon-result").html(
            '<img src="<?php echo WP_iv_membership_URLPATH; ?>admin/files/images/wrong_16x16.png">'
          );
        }
        jQuery("#p_amount").html(response.p_amount);
        jQuery("#total").html(response.gtotal);
        jQuery("#tax").html(response.tax_total);
      },
    });
  });
});

function iv_update_post() {
  tinyMCE.triggerSave();
  jQuery("#update_message").html(loader_image);
  var search_params = {
    action: "iv_membership_update_wp_post",
    form_data: jQuery("#edit_post").serialize(),
    _wpnonce: ep_data.profilenonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message").html(
        '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>' +
          response.msg +
          ".</div>"
      );
    },
  });
}
function add_custom_field() {
  jQuery("#custom_field_div").append(
    '<div class="row form-group "><div class=" col-md-6"> <input type="text" class="form-control" name="custom_name[]" id="custom_name[]" value="" placeholder="Custom Field Name"> </div><div  class=" col-md-6"><textarea name="custom_value[]" id="custom_value[]"  class="form-control  col-md-12"  rows="1" placeholder="Value"></textarea></div></div>'
  );
}
function remove_post_image(profile_image_id) {
  jQuery("#" + profile_image_id).html("");
  jQuery("#feature_image_id").val("");
  jQuery("#post_image_edit").html(
    '<button type="button" onclick="edit_post_image(\'post_image_div\');"  class="btn btn-xs green-haze">Add</button>'
  );
}
function edit_post_image(profile_image_id) {
  var image_gallery_frame;

  image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
    title: ep_data.set_image,
    button: {
      text: ep_data.set_image,
    },
    multiple: false,
    displayUserSettings: true,
  });
  image_gallery_frame.on("select", function () {
    var selection = image_gallery_frame.state().get("selection");
    selection.map(function (attachment) {
      attachment = attachment.toJSON();
      if (attachment.id) {
        jQuery("#" + profile_image_id).html(
          '<img  class="img-responsive"  src="' +
            attachment.sizes.thumbnail.url +
            '">'
        );
        jQuery("#feature_image_id").val(attachment.id);
        jQuery("#post_image_edit").html(
          '<button type="button" onclick="edit_post_image(\'post_image_div\');"  class="btn btn-xs green-haze">Edit</button>&nbsp;<button type="button" onclick="remove_post_image(\'post_image_div\');"  class="btn btn-xs green-haze">Remove</button>'
        );
      }
    });
  });
  image_gallery_frame.open();
}
function update_profile_billing() {
  jQuery("#update_message").html(loader_image);
  var search_params = {
    action: "iv_membership_update_profile_setting",
    form_data: jQuery("#profile_setting_form").serialize(),
    _wpnonce: ep_data.profilenonce,
  };
  jQuery.ajax({
    url: ajaxurl,
    dataType: "json",
    type: "post",
    data: search_params,
    success: function (response) {
      jQuery("#update_message").html(
        '<div class="bg-[#132F33] text-[#30C3BB] px-4 flex text-center py-2 rounded">' +
          response.msg +
          ".</div>"
      );
      jQuery("#update_profile_button").hide();
    },
  });
}
