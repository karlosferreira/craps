jQuery(function() {
	jQuery( "#start_date" ).datepicker();
	jQuery( "#end_date" ).datepicker();
});
