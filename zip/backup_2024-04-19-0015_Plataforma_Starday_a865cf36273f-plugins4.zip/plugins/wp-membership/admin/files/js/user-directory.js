"use strict";
var ajaxurl = ep_data_public.ajaxurl;
var loader_image = ep_data_public.loading_image;
jQuery(function() {
	jQuery(window).load(function() {
			jQuery('#package_sel').change(function() {
				this.form.submit();
			});
	});
});
		