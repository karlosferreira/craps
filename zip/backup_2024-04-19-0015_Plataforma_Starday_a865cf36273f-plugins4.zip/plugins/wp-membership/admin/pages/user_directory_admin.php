<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-md-12">
				<h3 class="page-header" ><?php  esc_html_e('User Setting','wpmembership')	;?>  <small>  </small> </h3>
			</div>
			<?php
		include('footer.php');
		?>
		</div>
		
		<div class="form-group col-md-12 row">
			<?php
				$no=20000;
				$paged = (isset($_REQUEST['paged'])) ? sanitize_text_field($_REQUEST['paged']) : 1;
				if($paged==1){
					$offset=0;
					}else {
					$offset= ($paged-1)*$no;
				}
				$args = array();
				$args['number']='999999999';
				
				$args['orderby']='registered';
				$args['order']='DESC';
				$user_query = new WP_User_Query( $args );
				
				$default_fields = array();
				$field_set=get_option('iv_membership_profile_fields' );
				if($field_set!=""){
					$default_fields=get_option('iv_membership_profile_fields' );
					}else{
					$default_fields['first_name']='First Name';
					$default_fields['last_name']='Last Name';
					$default_fields['phone']='Phone Number';
					$default_fields['mobile']='Mobile Number';
					$default_fields['address']='Address';
					$default_fields['city']='City';
					$default_fields['zipcode']='Zipcode';
					$default_fields['country-userprofile']='Country';
					$default_fields['job_title']='Job title';
					$default_fields['gender']='Gender';
					$default_fields['occupation']='Occupation';
					$default_fields['description']='About';
					$default_fields['web_site']='Website Url';
				}
				$i=0;								
				
				
			?>
			<table id="user-data" class="display table responsive" width="99%">
				<thead>
					<tr>
						<th> <?php  esc_html_e('User Info','wpmembership')	;?> </th>						
						<th> <?php  esc_html_e('Expiry Date','wpmembership')	;?> </th>
						<th> <?php  esc_html_e('Payment Status','wpmembership')	;?> </th>
						<th> <?php  esc_html_e('Role','wpmembership')	;?> </th>
						<?php						
						foreach ( $default_fields as $field_key => $field_value ) {?>
							<th> <?php  echo esc_html($field_value)	;?> </th>
							
						<?php
						}
						?>
						
						<th><?php  esc_html_e('Action','wpmembership')	;?></th>						
					</tr>
				</thead>
				<tbody>
					<?php						
						if ( ! empty( $user_query->results ) ) {
							foreach ( $user_query->results as $user ) {								
							?>
							<tr>
								<td><p><?php  esc_html_e('ID : ','wpmembership')	;?><?php echo esc_html($user->ID); ?></p>
									<p><?php  esc_html_e('Date : ','wpmembership')	;?><?php echo date("d-M-Y h:m:s A" ,strtotime($user->user_registered) ); ?></p>
									<p><?php  esc_html_e('User Name : ','wpmembership')	;?><?php echo get_user_meta($user->ID, 'first_name', true).' '.get_user_meta($user->ID, 'last_name', true).' ('. esc_html($user->display_name).')'; ?>
									</p>
									<p><?php  esc_html_e('Email : ','wpmembership')	;?><?php echo esc_html($user->user_email); ?></p>
								</td>	
									<td>
								<?php
									$exp_date= get_user_meta($user->ID, 'iv_membership_exprie_date', true);
									if($exp_date!=''){
										echo date('d-M-Y',strtotime($exp_date));
									}
								?></td>
								<td>
									<?php
										echo get_user_meta($user->ID, 'iv_membership_payment_status', true);
									?>
								</td>
								<td><?php
									if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
										foreach ( $user->roles as $role )
										echo ' '. ucfirst(esc_html($role));
									}
									?>
								</td>								
								<?php						
								foreach ( $default_fields as $field_key => $field_value ) {?>
									<td> <?php  echo esc_html(wp_trim_words(get_user_meta($user->ID,$field_key,true),'3'))	;?> </td>
									
								<?php
								}
								?>
								<td><a class="btn btn-primary btn-xs" href="?page=wp-iv_membership-user_update&id=<?php echo esc_html($user->ID); ?>"> <?php  esc_html_e('Edit','wpmembership')	;?></a>
									<a class="btn btn-danger btn-xs" href="<?php echo admin_url().'/users.php'?>"><?php  esc_html_e('Delete','wpmembership')	;?> </a>
								</td>
							</tr>
							<?php
							}
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
