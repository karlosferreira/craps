<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-md-12">
				<h3 class="page-header" ><?php esc_html_e('Public Profile ','wpmembership');?><small>  </small> </h3>
			</div>
		</div>
		<div class="form-group col-md-12 row">
			<div class="row ">
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Short Code','wpmembership');?></label>
				<div class="col-md-4" >
					[iv_membership_profile_public]
				</div>
			</div>
			<div class="row ">
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Php Code','wpmembership');?></label>
				<div class="col-md-10" >
					<p>
						&lt;?php
						echo do_shortcode('[iv_membership_profile_public]');
					?&gt;</p>
				</div>
			</div>
			<div class="row ">
				<label for="text" class="col-md-2 control-label"> <?php esc_html_e('Profile Page','wpmembership');?> </label>
				<div class="col-md-10" >
					<?php
						$form_wizard=get_option('_iv_membership_profile_public_page');
					?>
					<a class="btn btn-info btn-xs " href="<?php echo get_permalink( $form_wizard ); ?>" target="blank"><?php esc_html_e('View Page','wpmembership');?></a>
				</div>
			</div>
			<div class="col-md-12" id="success_message">
			</div>
			<br/>
			<table class="table table-striped">
				<?php
					$opt_style=	get_option('iv_membership_profile-public');
				?>
				<tr>
					<td width ="15%">
						<label >
							<input type="radio" name="option-profile" id="option-profile" value="style-1"  class="option-profile"<?php  echo ($opt_style=='style-1' ? 'checked': ''); ?> >
							<?php esc_html_e('Style 1','wpmembership');?>
						</label>
					</td>
					<td>
						<?php include( WP_iv_membership_template. 'profile-public/profile-template-1.php');?>
					</td>
				</tr>
				<tr>
					<td>
						<label >
							<input type="radio" name="option-profile" id="option-profile" value="style-2"  class="option-profile"<?php  echo ($opt_style=='style-2' ? 'checked': ''); ?>>
							<?php esc_html_e('Style 2','wpmembership');?>
						</label>
					</td>
					<td>
						<?php include( WP_iv_membership_template. 'profile-public/profile-template-2.php');?>
					</td>
				</tr>
				<tr>
					<td>
						<label >
							<input type="radio" name="option-profile" id="option-profile" class="option-profile" value="style-3"  <?php  echo ($opt_style=='style-3' ? 'checked': ''); ?>>
							<?php esc_html_e('Style 3','wpmembership');?>
						</label>
					</td>
					<td>
						<?php include(WP_iv_membership_template. 'profile-public/profile-template-3.php');?>
					</td>
				</tr>
				<tr>
					<td>
						<label >
							<input type="radio" name="option-profile" id="option-profile" value="style-5"  class="option-profile"<?php  echo ($opt_style=='style-5' ? 'checked': ''); ?>>
							<?php esc_html_e('Style 4','wpmembership');?>
						</label>
					</td>
					<td>
						<?php include( WP_iv_membership_template. 'profile-public/profile-template-5.php');?>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>
