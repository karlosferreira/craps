<?php
	$newpost_id='';
	$args = array(
	'post_type' => 'iv_payment_setting',
	'posts_per_page'=> '999',
	);
	$ep_query = new WP_Query( $args );
	if ( $ep_query->have_posts() ) :
	while ( $ep_query->have_posts() ) : $ep_query->the_post();
	$pid = get_the_ID();
	if(get_the_title($pid)==='iv_membership_paypal_setting'){
		$newpost_id = get_the_ID();
	}
	endwhile;
	endif;
	$paypal_mode=get_post_meta( $newpost_id,'iv_membership_paypal_mode',true);
?>
<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-md-12"><h3 class="page-header"><?php esc_html_e('Paypal Api Settings [Express Checkout]','wpmembership');?> </h3>
			</div>
		</div>
		<form id="paypal_form_iv" name="paypal_form_iv" class="form-horizontal" role="form" onsubmit="return false;">
			<div class="form-group">
				<label for="text" class="col-md-3 control-label"></label>
				<div id="iv-loading"></div>
			</div>
			<div class="form-group">
				<label for="text" class="col-md-3 control-label"><?php esc_html_e('Gateway Mode','wpmembership');?></label>
				<div class="col-md-5">
					<select name="paypal_mode" id ="paypal_mode" class="form-control">
						<option value="test" <?php echo ($paypal_mode == 'test' ? 'selected' : '') ?>><?php esc_html_e('Test Mode','wpmembership');?></option>
						<option value="live" <?php echo ($paypal_mode == 'live' ? 'selected' : '') ?>><?php esc_html_e('Live Mode','wpmembership');?></option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label for="text" class="col-md-3 control-label"><?php esc_html_e('PayPal API Username','wpmembership');?> <span class="chili"></span></label>
				<div class="col-md-5">
					<input type="text" class="form-control" name="paypal_username" id="paypal_username" value="<?php echo get_post_meta($newpost_id, 'iv_membership_paypal_username', true); ?>" placeholder="<?php esc_html_e('Enter Paypal Username','wpmembership');?>">
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail3" class="col-md-3 control-label"><?php esc_html_e('PayPal API Password ','wpmembership');?><span class="chili"></span></label>
				<div class="col-md-5">
					<input type="text" class="form-control" id="paypal_api_password" name="paypal_api_password" value="<?php echo get_post_meta($newpost_id, 'iv_membership_paypal_api_password', true); ?>"  placeholder="<?php esc_html_e('Enter Paypal Api Password','wpmembership');?>">
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail3" class="col-md-3 control-label"><?php esc_html_e('PayPal API Signature ','wpmembership');?><span class="chili"></span></label>
				<div class="col-md-5">
					<input type="text" class="form-control" id="paypal_api_signature" name="paypal_api_signature" value="<?php echo get_post_meta($newpost_id, 'iv_membership_paypal_api_signature', true); ?>"  placeholder="<?php esc_html_e('Enter Paypal Api Signature','wpmembership');?>">
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail3" class="col-md-3 control-label"><?php esc_html_e('PayPal API Currency Code','wpmembership');?></label>
				<div class="col-md-5">
					<?php
						$currency_iv=get_post_meta($newpost_id, 'iv_membership_paypal_api_currency', true);
					?>
					<select id="paypal_api_currency" name="paypal_api_currency" class="form-control">
						<option value="USD" <?php echo ($currency_iv=='USD' ? 'selected':'')  ?> ><?php esc_html_e('US Dollars ($)', 'wpmembership'); ?></option>
						<option value="EUR" <?php echo ($currency_iv=='EUR' ? 'selected':'')  ?> ><?php esc_html_e('Euros (€)', 'wpmembership'); ?></option>
						<option value="GBP" <?php echo ($currency_iv=='GBP' ? 'selected':'')  ?> ><?php esc_html_e('Pounds Sterling (£)', 'wpmembership'); ?></option>
						<option value="AUD" <?php echo ($currency_iv=='AUD' ? 'selected':'')  ?> ><?php esc_html_e('Australian Dollars ($)', 'wpmembership'); ?></option>
						<option value="BRL" <?php echo ($currency_iv=='BRL' ? 'selected':'')  ?> ><?php esc_html_e('Brazilian Real (R$)', 'wpmembership'); ?></option>
						<option value="CAD" <?php echo ($currency_iv=='CAD' ? 'selected':'')  ?> ><?php esc_html_e('Canadian Dollars ($)', 'wpmembership'); ?></option>
						<option value="CNY" <?php echo ($currency_iv=='CNY' ? 'selected':'')  ?> ><?php esc_html_e('Chinese Yuan', 'wpmembership'); ?></option>
						<option value="CZK" <?php echo ($currency_iv=='CZK' ? 'selected':'')  ?> ><?php esc_html_e('Czech Koruna', 'wpmembership'); ?></option>
						<option value="DKK" <?php echo ($currency_iv=='DKK' ? 'selected':'')  ?> ><?php esc_html_e('Danish Krone', 'wpmembership'); ?></option>
						<option value="HKD" <?php echo ($currency_iv=='HKD' ? 'selected':'')  ?> ><?php esc_html_e('Hong Kong Dollar ($)', 'wpmembership'); ?></option>
						<option value="HUF" <?php echo ($currency_iv=='HUF' ? 'selected':'')  ?> ><?php esc_html_e('Hungarian Forint', 'wpmembership'); ?></option>
						<option value="INR" <?php echo ($currency_iv=='INR' ? 'selected':'')  ?> ><?php esc_html_e('Indian Rupee', 'wpmembership'); ?></option>
						<option value="ILS" <?php echo ($currency_iv=='ILS' ? 'selected':'')  ?> ><?php esc_html_e('Israeli Sheqel', 'wpmembership'); ?></option>
						<option value="JPY" <?php echo ($currency_iv=='JPY' ? 'selected':'')  ?> ><?php esc_html_e('Japanese Yen (¥)', 'wpmembership'); ?></option>
						<option value="MYR" <?php echo ($currency_iv=='MYR' ? 'selected':'')  ?> ><?php esc_html_e('Malaysian Ringgits', 'wpmembership'); ?></option>
						<option value="MXN" <?php echo ($currency_iv=='MXN' ? 'selected':'')  ?> ><?php esc_html_e('Mexican Peso ($)', 'wpmembership'); ?></option>
						<option value="NZD" <?php echo ($currency_iv=='NZD' ? 'selected':'')  ?> ><?php esc_html_e('New Zealand Dollar ($)', 'wpmembership'); ?></option>
						<option value="NOK" <?php echo ($currency_iv=='NOK' ? 'selected':'')  ?> ><?php esc_html_e('Norwegian Krone', 'wpmembership'); ?></option>
						<option value="PHP" <?php echo ($currency_iv=='PHP' ? 'selected':'')  ?> ><?php esc_html_e('Philippine Pesos', 'wpmembership'); ?></option>
						<option value="PLN" <?php echo ($currency_iv=='PLN' ? 'selected':'')  ?> ><?php esc_html_e('Polish Zloty', 'wpmembership'); ?></option>
						<option value="SGD" <?php echo ($currency_iv=='SGD' ? 'selected':'')  ?> ><?php esc_html_e('Singapore Dollar ($)', 'wpmembership'); ?></option>
						<option value="ZAR" <?php echo ($currency_iv=='ZAR' ? 'selected':'')  ?> ><?php esc_html_e('South African Rand', 'wpmembership'); ?></option>
						<option value="KRW" <?php echo ($currency_iv=='KRW' ? 'selected':'')  ?> ><?php esc_html_e('South Korean Won', 'wpmembership'); ?></option>
						<option value="SEK" <?php echo ($currency_iv=='SEK' ? 'selected':'')  ?> ><?php esc_html_e('Swedish Krona', 'wpmembership'); ?></option>
						<option value="CHF" <?php echo ($currency_iv=='CHF' ? 'selected':'')  ?> ><?php esc_html_e('Swiss Franc', 'wpmembership'); ?></option>
						<option value="RUB" <?php echo ($currency_iv=='RUB' ? 'selected':'')  ?> ><?php esc_html_e('Russian Ruble', 'wpmembership'); ?></option>
						<option value="TWD" <?php echo ($currency_iv=='TWD' ? 'selected':'')  ?> ><?php esc_html_e('Taiwan New Dollars', 'wpmembership'); ?></option>
						<option value="THB" <?php echo ($currency_iv=='THB' ? 'selected':'')  ?> ><?php esc_html_e('Thai Baht', 'wpmembership'); ?></option>
						<option value="TRY" <?php echo ($currency_iv=='TRY' ? 'selected':'')  ?> ><?php esc_html_e('Turkish Lira', 'wpmembership'); ?></option>
					</select>
				</div>
			</div>
		</form>
		<div class="row">
			<label for="" class="col-md-3 control-label"></label>
			<div class="col-md-5">
				<div align="">
				<button class="btn btn-info " onclick="return update_paypal_setting();"><?php esc_html_e('Update Settings','wpmembership');?></button></div>
				<p>&nbsp;</p>
			</div>
		</div>
	</div>
</div>
