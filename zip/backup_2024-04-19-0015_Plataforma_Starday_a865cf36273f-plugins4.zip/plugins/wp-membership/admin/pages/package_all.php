<?php
	$currencies = array();
	$currencies['AUD'] ='$';$currencies['CAD'] ='$';
	$currencies['EUR'] ='€';$currencies['GBP'] ='£';
	$currencies['JPY'] ='¥';$currencies['USD'] ='$';
	$currencies['NZD'] ='$';$currencies['CHF'] ='Fr';
	$currencies['HKD'] ='$';$currencies['SGD'] ='$';
	$currencies['SEK'] ='kr';$currencies['DKK'] ='kr';
	$currencies['PLN'] ='zł';$currencies['NOK'] ='kr';
	$currencies['HUF'] ='Ft';$currencies['CZK'] ='Kč';
	$currencies['ILS'] ='₪';$currencies['MXN'] ='$';
	$currencies['BRL'] ='R$';$currencies['PHP'] ='₱';
	$currencies['MYR'] ='RM';$currencies['AUD'] ='$';
	$currencies['TWD'] ='NT$';$currencies['THB'] ='฿';
	$currencies['TRY'] ='TRY';	$currencies['CNY'] ='¥';
	if(isset($_REQUEST['id']))  {
	}
	if(isset($_REQUEST['delete_id']))  {
		$post_id=sanitize_text_field($_REQUEST['delete_id']);
		$recurring= get_post_meta($post_id, 'iv_membership_package_recurring', true);
		if($recurring=='on'){
			$iv_gateway = get_option('iv_membership_payment_gateway');
			if($iv_gateway=='stripe'){				
					include(WP_iv_membership_DIR . '/admin/files/init.php');
				$args = array(
				'post_type' => 'iv_payment_setting',
				'posts_per_page'=> '999',
				);
				$ep_query = new WP_Query( $args );
				if ( $ep_query->have_posts() ) :
				while ( $ep_query->have_posts() ) : $ep_query->the_post();
				$pid = get_the_ID();
				if(get_the_title($pid)==='iv_membership_stripe_setting'){
					$stripe_id = get_the_ID();
				}
				endwhile;
				endif;
				$post_package = get_post($post_id);
				$p_name = $post_package->post_name;
				$stripe_mode=get_post_meta( $stripe_id,'iv_membership_stripe_mode',true);
				if($stripe_mode=='test'){
					$stripe_api =get_post_meta($stripe_id, 'iv_membership_stripe_secret_test',true);
					}else{
					$stripe_api =get_post_meta($stripe_id, 'iv_membership_stripe_live_secret_key',true);
				}
				$plan='';	
				\Stripe\Stripe::setApiKey($stripe_api);
				try {
					$plan = \Stripe\Plan::retrieve($p_name);
					$plan->delete();
					
				} catch (Exception $e) {
					
				}	
			}
		}
		wp_delete_post($post_id);
		delete_post_meta($post_id,true);
		$message=__('Deleted Successfully','wpmembership');
	}
	if(isset($_REQUEST['form_submit']))  {
		$message=__('Update Successfully','wpmembership');
	}
  $api_currency= get_option('_iv_membership_api_currency' );
	
?>
<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row ">
			<div class="col-md-12" id="submit-button-holder">
				<div class="pull-right ">
					<a class="btn btn-info "  href="<?php echo WP_iv_membership_ADMINPATH; ?>admin.php?page=wp-iv_membership-package-create"><?php esc_html_e('Create A New Package','wpmembership');?></a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 table-responsive">
				<h3  class=""><?php esc_html_e('All Package / Membership Level','wpmembership');?>  <small></small>
					<small >
						<?php
							if (isset($_REQUEST['form_submit']) AND $_REQUEST['form_submit'] <> "") {
							}
							if (isset($message) AND $message <> "") {
								echo  '<span class="spcolor"> [ '.esc_html($message).' ]</span>';
							}
						?>
					</small>
				</h3>
				<div class="panel panel-info">
					<div class="panel-body">
						<table class="table table-striped col-md-12">
							<thead >
								<tr>
									<th ><?php esc_html_e('Package Name','wpmembership');?></th>
									<th ><?php esc_html_e('Amount','wpmembership');?></th>
									<th><?php esc_html_e('Link','wpmembership');?></th>
									<th><?php esc_html_e('User Role','wpmembership');?></th>
									<th><?php esc_html_e('Status','wpmembership');?></th>
									<th ><?php esc_html_e('Action','wpmembership');?></th>
								</tr>
							</thead>
							<tbody>
								<?php
									$currency=$api_currency ;
									$currency_symbol=(isset($currencies[$currency]) ? $currencies[$currency] :$currency );
									$args = array(
									'post_type' => 'iv_membership_pack',
									'posts_per_page'=> '999',
									'orderby' => 'date',
									'order' => 'ASC',
									);
									$ep_query = new WP_Query( $args );
									if ( $ep_query->have_posts() ){
										while ( $ep_query->have_posts() ) : $ep_query->the_post();
										$epid = get_the_ID();
										echo'<tr>';
										echo '<td>'. get_the_title($epid).'</td>';
										$amount='';
										if(get_post_meta($epid, 'iv_membership_package_cost', true)!="" AND get_post_meta($epid, 'iv_membership_package_cost', true)!="0"){
											$amount= get_post_meta($epid, 'iv_membership_package_cost', true).' '.$currency;
											}else{
											$amount= '0 '.$currency;
										}
										$recurring= get_post_meta($epid, 'iv_membership_package_recurring', true);
										if($recurring == 'on'){
											$count_arb=get_post_meta($epid, 'iv_membership_package_recurring_cycle_count', true);
											if($count_arb=="" or $count_arb=="1"){
												$recurring_text=" per ".' '.get_post_meta($epid, 'iv_membership_package_recurring_cycle_type', true);
												}else{
												$recurring_text=' per '.$count_arb.' '.get_post_meta($epid, 'iv_membership_package_recurring_cycle_type', true).'s';
											}
											}else{
											$recurring_text=' &nbsp; ';
										}
										$recurring= get_post_meta($epid, 'iv_membership_package_recurring', true);
										if($recurring == 'on'){
											$amount= get_post_meta($epid, 'iv_membership_package_recurring_cost_initial', true).' '.$currency;
											$amount=$amount. ' / '.$recurring_text;
										}
										echo '<td>'. esc_html($amount).'</td>';
										$page_name_reg=get_option('_iv_membership_registration' );
										echo '<td><a target="blank" href="'.get_page_link($page_name_reg).'?&package_id=	'.esc_html($epid).'">'.get_page_link($page_name_reg).'?&package_id=	'.esc_html($epid).' </a>
										</td>';
										echo '<td>'. get_the_title($epid).'</td>';
									?>
									<td>
										<div id="status_<?php echo esc_html($epid); ?>">
											<?php
												if(get_post_status($epid)=="draft"){
													$pac_msg= esc_html__( 'Active','wpmembership');
													}else{
													$pac_msg=esc_html__('Inactive','wpmembership');
												}
											?>
											<button class="btn btn-info btn-xs" onclick="return iv_package_status_change('<?php echo esc_html($epid); ?>','<?php echo get_post_status($epid); ?>');"><?php echo esc_html($pac_msg); ?></button>
										</div>
										<?php
											echo" </td> ";
											echo '<td>  <a class="btn btn-primary btn-xs" href="?page=wp-iv_membership-package-update&id='.esc_html($epid).'"> Edit</a> <a href="?page=wp-iv_membership-package-all&delete_id='.esc_html($epid).'" class="btn btn-danger btn-xs" onclick="return confirm(\'Are you sure to delete this package?\');">Delete</a></td>';
											echo'</tr>';
											endwhile;
										}else{ ?>
										<br/><tr><td> <h4><?php esc_html_e('Package List is Empty','wpmembership');?> </h4></td></tr>
										<?php
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="">
						<a class="btn btn-info "  href="<?php echo WP_iv_membership_ADMINPATH; ?>admin.php?page=wp-iv_membership-package-create"><?php esc_html_e('Create A New Package','wpmembership');?></a>
						<a class="btn btn-info "  href="<?php echo WP_iv_membership_ADMINPATH; ?>admin.php?page=wp-iv_membership-payment-settings"><?php esc_html_e('Setup Payment Gateway','wpmembership');?></a>
					</div>
				</div>
				
				
			</div>
			<br/>
			<?php
				include('footer.php');
				?>
			<br/>
			<div class="panel panel-info">
				<div class="panel-body">
					<div class=" col-md-12  bs-callout bs-callout-info">
						<?php esc_html_e('User role "Basic" is created on the plugin activation. Paid exprired or unsuccessful payment user will set on the "Basic" user role.','wpmembership');?>
					</div>
					<div class="clearfix"></div>
					<ul class=" list-group col-md-6">
						<li class="list-group-item"><?php esc_html_e('Short Code','wpmembership');?> : <code>[iv_membership_price_table]  </code></li>
						<li class="list-group-item">PHP Code :<code>
							&lt;?php
							echo do_shortcode('[iv_membership_price_table ]');
						?&gt;</code>
						</li>
						<li class="list-group-item">
							<?php esc_html_e('Package Page :','wpmembership'); ?>
							<?php
								$iv_membership_price_table=get_option('_iv_membership_price_table');
							?>
							<a class="btn btn-info btn-xs " href="<?php echo get_permalink( $iv_membership_price_table ); ?>" target="blank"><?php esc_html_e('View Page','wpmembership');?></a>
						</li>
					</ul>
					<div class="clearfix"></div>
					<div class="  bs-callout bs-callout-info">
						<?php esc_html_e('Note: You can use other available pricing table. The package link URL will go on "Sign UP " button. ','wpmembership');?>
					</div>
				</div>
			</div>
			<br/>
			<div class="row">
				<div class="col-md-12 ">
					<h3  class=""><?php esc_html_e('Pricing Table','wpmembership');?> <small><?php esc_html_e('Select Your Style','wpmembership');?></small>
					</h3>
					<div id="success_message">	</div>
					<?php
						if(get_option('iv_membership_price-table')){
							$opt_style=	get_option('iv_membership_price-table');
							}else{
							$opt_style=	'style-1';
						}
					?>
					<table class="table table-striped">
						<tr>
							<td width="10%" class="tdalign" >
								<label >
									<input type="radio" name="option-price-table" id="option-price-table" value="style-1" class="" <?php  echo ($opt_style=='style-1' ? 'checked': ''); ?>>
									<?php esc_html_e('Style 1','wpmembership'); ?>
								</label>
							</td>
							<td width="90%">
								<br/>	<br/>
								<?php include( WP_iv_membership_ABSPATH. 'admin/pages/price-table/price-table-1.php');?>
							</td>
						</tr>
						<tr>
							<td width="10%" class="tdalign">
								<label >
									<input type="radio" name="option-price-table" id="option-price-table" value="style-2"  <?php  echo ($opt_style=='style-2' ? 'checked': ''); ?> >
									<?php esc_html_e('Style 2','wpmembership'); ?>
								</label>
							</td>
							<td width="90%">
								<br/>	<br/>
								<?php include( WP_iv_membership_ABSPATH. 'admin/pages/price-table/price-table-2.php');?>
							</td>
						</tr>
						<tr>
							<td width="10%" class="tdalign">
								<label >
									<input type="radio" name="option-price-table" id="option-price-table" value="style-3"  <?php  echo ($opt_style=='style-3' ? 'checked': ''); ?> >
									<?php esc_html_e('Style 3','wpmembership'); ?>
								</label>
							</td>
							<td width="90%">
								<br/>	<br/>
								<?php include( WP_iv_membership_ABSPATH. 'admin/pages/price-table/price-table-3.php');?>
							</td>
						</tr>
						<tr>
							<td width="10%" class="tdalign">
								<label >
									<input type="radio" name="option-price-table" id="option-price-table" value="style-4"  <?php  echo ($opt_style=='style-4' ? 'checked': ''); ?> >
									<?php esc_html_e('Style 4','wpmembership'); ?>
								</label>
							</td>
							<td width="90%">
								<br/>	<br/>
								<?php include( WP_iv_membership_ABSPATH. 'admin/pages/price-table/price-table-4.php');?>
							</td>
						</tr>
						<tr>
							<td width="10%" class="tdalign">
								<label >
									<input type="radio" name="option-price-table" id="option-price-table" value="style-5"  <?php  echo ($opt_style=='style-5' ? 'checked': ''); ?> >
									<?php esc_html_e('Style 5','wpmembership'); ?>
								</label>
							</td>
							<td width="90%">
								<br/>	<br/>
								<?php include( WP_iv_membership_ABSPATH. 'admin/pages/price-table/price-table-5.php');?>
							</td>
						</tr>
						<tr>
							<td width="10%" class="tdalign">
								<label >
									<input type="radio" name="option-price-table" id="option-price-table" value="style-6"  <?php  echo ($opt_style=='style-6' ? 'checked': ''); ?> >
									<?php esc_html_e('Style 6','wpmembership'); ?>
								</label>
							</td>
							<td width="90%">
								<br/>	<br/>
								<?php include( WP_iv_membership_ABSPATH. 'admin/pages/price-table/price-table-6.php');?>
							</td>
						</tr>
						<tr>
							<td width="10%" class="tdalign">
								<label >
									<input type="radio" name="option-price-table" id="option-price-table" value="style-7"  <?php  echo ($opt_style=='style-7' ? 'checked': ''); ?> >
									<?php esc_html_e('Style 7','wpmembership'); ?>
								</label>
							</td>
							<td width="90%">
								<br/>	<br/>
								<?php include( WP_iv_membership_ABSPATH. 'admin/pages/price-table/price-table-7.php');?>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
	