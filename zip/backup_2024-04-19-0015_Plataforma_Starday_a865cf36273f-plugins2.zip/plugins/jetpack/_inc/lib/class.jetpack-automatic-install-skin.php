<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase
/**
 * This file has been moved to the jetpack-plugins-installer package
 *
 * @deprecated 10.7
 *
 * @package jetpack
 */

class_alias( Automattic\Jetpack\Automatic_Install_Skin::class, 'Jetpack_Automatic_Install_Skin' );
