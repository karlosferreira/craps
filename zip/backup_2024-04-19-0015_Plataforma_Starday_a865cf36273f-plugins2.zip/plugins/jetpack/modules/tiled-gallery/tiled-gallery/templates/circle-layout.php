<?php
/**
 * Square layout Tiled Gallery template.
 *
 * @package automattic/jetpack
 */

$this->template( 'square-layout', $context ); // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable
