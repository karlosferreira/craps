<?php return array('dependencies' => array(), 'version' => 'cf724453044d90f52a0a');
