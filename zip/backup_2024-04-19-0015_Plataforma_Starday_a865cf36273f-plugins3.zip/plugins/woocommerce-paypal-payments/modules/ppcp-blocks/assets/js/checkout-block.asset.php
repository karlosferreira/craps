<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => '96207e03cf075fb1b2d2');
