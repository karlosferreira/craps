import BaseHandler from "./BaseHandler";

class CartHandler extends BaseHandler {

}

export default CartHandler;
