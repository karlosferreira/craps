<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => 'e701ad3970037f393f5b');
