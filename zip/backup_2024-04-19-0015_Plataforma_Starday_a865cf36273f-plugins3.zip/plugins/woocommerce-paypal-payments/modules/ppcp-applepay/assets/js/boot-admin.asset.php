<?php return array('dependencies' => array(), 'version' => 'f04ff8ef8ff5f447b987');
