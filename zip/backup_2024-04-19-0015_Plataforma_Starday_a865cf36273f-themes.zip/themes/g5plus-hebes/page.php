<?php
/**
 * The template for displaying page
 *
 */
G5Plus_Hebes()->helper()->get_header();
	while (have_posts()) : the_post();
		G5Plus_Hebes()->helper()->getTemplate('content-page');
	endwhile;
G5Plus_Hebes()->helper()->get_footer();