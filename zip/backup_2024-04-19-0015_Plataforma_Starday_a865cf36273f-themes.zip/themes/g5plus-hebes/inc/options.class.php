<?php
if (!class_exists('G5Plus_Hebes_Options')) {
    class G5Plus_Hebes_Options
    {
        private static $_instance;
        public static function getInstance() {
            if (self::$_instance == NULL) { self::$_instance = new self(); }
            return self::$_instance;
        }


        public function get_option($key, $default = '') {
            if (function_exists('G5P')) {
                return G5P()->options()->get_option($key,$default);
            }
            return $default;
        }

        public function set_option($key, $value) {
            if (function_exists('G5P')) {
                G5P()->options()->set_option($key,$value);
            }
        }

        public function set_preset($preset_name) {
            if (function_exists('G5P')) {
                G5P()->options()->set_preset($preset_name);
            }
        }
    }
}