<?php
if (!class_exists('G5Plus_Hebes_Options_Skin')) {
	class G5Plus_Hebes_Options_Skin
	{
		private static $_instance;

		public static function getInstance()
		{
			if (self::$_instance == NULL) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		public function get_color_skin()
		{
            if (function_exists('G5P')) {
                return G5P()->optionsSkin()->get_color_skin();
            }
            return array(
                array(
                    'skin_id' => 'skin-light',
                    'skin_name' => 'Light',
                    'background_color' => '#fff',
                    'text_color' => '#a1a1a1',
                    'text_hover_color' => '',
                    'heading_color' => '#000',
                    'disable_color' => '#9fa4af',
                    'border_color' => '#ebebeb',
                ),
                array(
                    'skin_id' => 'skin-dark',
                    'skin_name' => 'Dark',
                    'background_color' => '#0e0e0e',
                    'text_color' => '#555',
                    'text_hover_color' => '',
                    'heading_color' => '#fff',
                    'disable_color' => '#b7b7b7',
                    'border_color' => '#252525',
                )
            );
		}
	}
}