		<!-- Open Wrapper Content -->
		<div id="wrapper-content" class="clearfix ">
			<?php
			/**
			 *
			 * @hooked - G5Plus_Hebes()->templates()->content_wrapper_start() - 1
			 **/
			do_action('g5plus_main_wrapper_content_start');
			?>
