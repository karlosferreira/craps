<?php
G5Plus_Hebes()->helper()->get_header();
$portfolio_filter = G5Plus_Hebes()->options()->get_option('portfolio_cate_filter');
$query_args = $settings = null;
if('' !== $portfolio_filter) {
    $settings['category_filter_enable'] = true;
    $settings['category_filter_align'] = $portfolio_filter;
    if (is_tax(G5Plus_Hebes()->portfolio()->get_taxonomy_category())) {
        global $wp_query;
        if (isset($wp_query->queried_object)) {
            $settings['current_cat'] = $wp_query->queried_object->term_id;
        }
    }
}
G5Plus_Hebes()->portfolio()->archive_markup($query_args,$settings);
G5Plus_Hebes()->helper()->get_footer();