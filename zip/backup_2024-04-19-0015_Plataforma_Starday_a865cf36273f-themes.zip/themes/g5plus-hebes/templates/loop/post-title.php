<?php
/**
 * The template for displaying post-title.php
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
?>
<h4 class="gf-post-title heading-color"><a title="<?php the_title_attribute() ?>" href="<?php the_permalink() ?>"><?php the_title() ?></a></h4>