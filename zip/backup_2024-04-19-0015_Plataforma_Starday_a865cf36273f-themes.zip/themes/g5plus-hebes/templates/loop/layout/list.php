<?php
/**
 * The template for displaying content-list
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 * @var $post_class
 * @var $post_inner_class
 */
?>
<article <?php post_class($post_class) ?>>
	<div class="<?php echo esc_attr($post_inner_class); ?>">
		<div class="gf-post-content">
			<div class="gf-post-content-left">
				<div class="post-date">
					<?php
					$date_string = get_the_date('d');
					$month_string = get_the_date('M');
					?>
					<span class="date"><?php echo esc_html($date_string); ?></span>
					<span class="month"><?php echo esc_html($month_string); ?></span>
				</div>
			</div>
			<div class="gf-post-content-right">
                <?php G5Plus_Hebes()->templates()->post_meta(array(
                    'date' => true,
                    'extend_class' => 'layout-2'
                )); ?>
				<?php G5Plus_Hebes()->helper()->getTemplate('loop/post-title') ?>
			</div>
		</div>
	</div>
</article>