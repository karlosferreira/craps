<?php
/**
 * Template display product title
 *
 * @package WordPress
 * @subpackage hebes
 */
$product_rating_enable = G5Plus_Hebes()->options()->get_option('product_rating_enable','on');
$classes = array(
        'product-name',
    'product_title'
);
if ($product_rating_enable === 'on') {
    $classes[] = 'product-title-rating';
}
?>
<h4 class="<?php echo esc_attr(implode(' ', $classes))?>">
    <a class="gsf-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
</h4>
