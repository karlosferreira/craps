<?php
/**
 * Created by PhpStorm.
 * User: MyPC
 * Date: 07/08/2017
 * Time: 8:11 SA
 */

global $wp_registered_sidebars;
?>
<div class="gf-toggle-filter gf-filter-bellow" data-target="#filter-content">
    <span class="gf-filter-icon"></span> <?php esc_html_e('Filter', 'g5plus-hebes'); ?>
</div>
