<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.2
 */

if (!defined('ABSPATH')) {
    exit;
}
global $product;
if (!is_a($product, 'WC_Product')) {
    $product = wc_get_product(get_the_ID());
}

if (wc_notice_count()) {
    echo '<div class="container mg-top-50 mg-bottom-50">';
    /**
     * woocommerce_before_single_product hook.
     *
     * @hooked wc_print_notices - 10
     */
    do_action('woocommerce_before_single_product');
    echo '</div>';
}
?>
<div id="single-product-image-10">
    <div class="container gf-container-fluid">
        <div class="row justify-content-center single-product-image-main-wrap">
            <div class="single-product-image-inner col-xl-8 col-md-6">
                <div class="product-flash-inner">
                    <?php
                    do_action('woocommerce_before_single_product_summary');
                    ?>
                </div>
            </div>
            <div class="summary entry-summary col-xl-4 col-md-6">
                <div class="summary-product-inner">
                    <?php
                    $product_add_to_cart_enable = G5Plus_Hebes()->options()->get_option('product_add_to_cart_enable','on');
                    if (!$product_add_to_cart_enable) {
                        remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
                    }
                    ?>

                    <?php
                    /**
                     * woocommerce_single_product_summary hook.
                     *
                     * @hooked woocommerce_template_single_title - 5
                     * @hooked woocommerce_template_single_rating - 10
                     * @hooked woocommerce_template_single_price - 10
                     * @hooked shop_single_loop_sale_count_down - 15
                     * @hooked woocommerce_template_single_excerpt - 20
                     * @hooked woocommerce_template_single_add_to_cart - 30
                     * @hooked g5plus_woocommerce_template_single_function - 35
                     * @hooked woocommerce_template_single_meta - 40
                     * @hooked woocommerce_template_single_sharing - 50
                     */
                    do_action('woocommerce_single_product_summary');
                    ?>
                </div>
            </div><!-- .summary -->
        </div>
    </div>
</div>

