<?php
/**
 * The template for displaying layout-6
 * @var $header_layout
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */

$header_classes = array(
	'header-wrap'
);

$header_above_inner_classes = array(
	'header-inner',
	'd-flex',
	'align-items-center',
	'x-nav-menu-container'
);

$header_class = implode(' ', array_filter($header_classes));
$header_above_inner_class = implode(' ', array_filter($header_above_inner_classes));

?>
<div class="<?php echo esc_attr($header_class) ?>">
	<div class="<?php echo esc_attr($header_above_inner_class) ?>">
		<?php G5Plus_Hebes()->helper()->getTemplate('header/desktop/logo', array('header_layout' => $header_layout)); ?>
		<div class="header-below-inner">
			<?php G5Plus_Hebes()->helper()->getTemplate('header/header-customize', array('customize_location' => 'left', 'canvas_position' => 'left')); ?>
			<?php
			add_action('wp_footer', array(G5Plus_Hebes()->templates(), 'canvas_menu'), 10);
			?>
			<div class="gf-menu-icon-wrap">
                <a class="gf-menu-icon-circle gf-menu-canvas" href="#popup-canvas-menu"><i class="fal fa-ellipsis-h"></i></a>
			</div>
			<?php G5Plus_Hebes()->helper()->getTemplate('header/header-customize', array('customize_location' => 'right', 'canvas_position' => 'right')); ?>
		</div>
	</div>
</div>

