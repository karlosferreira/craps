<?php
/**
 * The template for displaying search.php
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
$mobile_header_search_enable = G5Plus_Hebes()->options()->get_option('mobile_header_search_enable');
if ($mobile_header_search_enable !== 'on') return;
$post_type = G5Plus_Hebes()->options()->get_option('search_popup_post_type',array('post'));
?>
<div class="mobile-header-search">
	<div class="container">
        <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) )  ?>">
            <?php if(is_array($post_type) &&  count($post_type) == 1 && $post_type[0] == 'product'): ?>
                <input type="hidden" name="post_type" value="product">
            <?php endif; ?>
            <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search &hellip;', 'placeholder', 'g5plus-hebes' ) ?>" value="<?php echo esc_attr(get_search_query())  ?>" name="s" />
            <button type="submit" class="search-submit"><?php echo esc_attr_x( 'Search', 'submit button','g5plus-hebes' ) ?> <i class="fal fa-search"></i></button>
        </form>
	</div>
</div>
