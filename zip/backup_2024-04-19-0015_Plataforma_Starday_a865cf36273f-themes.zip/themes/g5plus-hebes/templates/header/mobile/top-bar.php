<?php
/**
 * The template for displaying top-bar
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
$top_bar_enable = G5Plus_Hebes()->options()->get_option('mobile_top_bar_enable');
if ($top_bar_enable !== 'on') return;
$content_block = G5Plus_Hebes()->options()->get_option('mobile_top_bar_content_block');
$content_block = G5Plus_Hebes()->helper()->content_block($content_block);
?>
<div class="mobile-top-bar">
    <?php if (!empty($content_block)) {
        echo wp_kses_post($content_block);
    } ?>
</div>
