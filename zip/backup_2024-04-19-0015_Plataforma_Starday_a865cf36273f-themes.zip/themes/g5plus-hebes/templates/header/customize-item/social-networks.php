<?php
/**
 * The template for displaying social-networks
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 * @var $customize_location
 */
$social_networks =  G5Plus_Hebes()->options()->get_option("header_customize_{$customize_location}_social_networks",array());
G5Plus_Hebes()->templates()->social_networks($social_networks,'classic');

