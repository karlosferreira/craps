<?php
/**
 * The template for displaying mobile
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
$mobile_header_layout = G5Plus_Hebes()->options()->get_option('mobile_header_layout','header-1');
$mobile_header_float_enable = G5Plus_Hebes()->options()->get_option('mobile_header_float_enable');
$mobile_header_sticky = G5Plus_Hebes()->options()->get_option('mobile_header_sticky');
$mobile_header_border = G5Plus_Hebes()->options()->get_option('mobile_header_border','none');
$skin = G5Plus_Hebes()->options()->get_option('mobile_header_skin','light');

$mobile_header_classes = array(
	'mobile-header',
	$mobile_header_layout
);
$header_attributes = array();

if ($mobile_header_float_enable === 'on') {
    $mobile_header_classes[] = 'header-float';
}
$skin_classes = G5Plus_Hebes()->helper()->getSkinClass($skin);
$mobile_header_classes = array_merge($mobile_header_classes,$skin_classes);
if (!empty($skin)) {
	$header_attributes[] = 'data-sticky-skin="gf-skin '. $skin .'"';
}

if('' !== $mobile_header_sticky) {
    $header_attributes[] = 'data-sticky-type="'. $mobile_header_sticky .'"';
}

$mobile_header_class = implode(' ',array_filter($mobile_header_classes));
?>
<header <?php echo implode(' ',$header_attributes)?> class="<?php echo esc_attr($mobile_header_class) ?>">
	<?php G5Plus_Hebes()->helper()->getTemplate('header/mobile/top-bar'); ?>
	<?php G5Plus_Hebes()->helper()->getTemplate("header/mobile/{$mobile_header_layout}",array(
		'header_layout' => $mobile_header_layout,
		'header_border' => $mobile_header_border,
		'header_sticky' => $mobile_header_sticky
	)); ?>
	<?php G5Plus_Hebes()->helper()->getTemplate('header/mobile/search'); ?>
</header>