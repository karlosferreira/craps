<?php
/**
 * The template for displaying pulse.php
 */
?>
<div class="sk-spinner sk-spinner-pulse"></div>