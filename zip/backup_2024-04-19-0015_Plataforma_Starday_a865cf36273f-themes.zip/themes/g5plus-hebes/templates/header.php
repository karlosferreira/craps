<?php
/**
 * The template for displaying header
 */
$header_enable = G5Plus_Hebes()->options()->get_option('header_enable','on');
if ($header_enable !== 'on') return;
G5Plus_Hebes()->helper()->getTemplate('header/desktop');
G5Plus_Hebes()->helper()->getTemplate('header/mobile');