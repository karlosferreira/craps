<?php
/**
 * Created by PhpStorm.
 * User: MyPC
 * Date: 13/02/2018
 * Time: 10:37 SA
 */
$mailchimp_popup_enable = G5Plus_Hebes()->options()->get_option('mailchimp_popup_enable');
$mailchimp_popup_content_block = G5Plus_Hebes()->options()->get_option('mailchimp_popup_content_block');
if (isset($_COOKIE['remember_show']) || $mailchimp_popup_enable !== 'on' || empty($mailchimp_popup_content_block)) return;

$mailchimp_popup_timeout = intval(G5Plus_Hebes()->options()->get_option('mailchimp_popup_timeout','500'));
if($mailchimp_popup_timeout < 0 ) {
    $mailchimp_popup_timeout = 500;
}
$data_popup_mailchimp = array(
    'data-popup-mailchimp-enable="on"',
    'data-mailchimp-popup-timeout="'.$mailchimp_popup_timeout.'"'
);
$wrapper_classes = array(
    'modal fade',
    G5Plus_Hebes()->options()->get_option('mailchimp_layout','mailchimp-layout-01')
);

$mailchimp_skin = G5Plus_Hebes()->options()->get_option('mailchimp_popup_skin','skin-dark');
$skin_classes = G5Plus_Hebes()->helper()->getSkinClass($mailchimp_skin, true);
$wrapper_classes = array_merge($wrapper_classes, $skin_classes);
$wrap_background = G5Plus_Hebes()->options()->get_option('mailchimp_popup_wrap_bg');
$background = G5Plus_Hebes()->options()->get_option('mailchimp_popup_bg');
$wrap_background_attributes = $background_attributes = array();
if (is_array($wrap_background) && isset($wrap_background['background_color']) && !empty($wrap_background['background_color'])) {
    $wrap_background_attributes[] = "background-color: {$wrap_background['background_color']} !important";
}

if (is_array($wrap_background) && isset($wrap_background['background_image_url']) && !empty($wrap_background['background_image_url'])) {
    $background_repeat = isset($wrap_background['background_repeat']) ? $wrap_background['background_repeat'] : '';
    $background_position = isset($wrap_background['background_position']) ? $wrap_background['background_position'] : '';
    $background_size = isset($wrap_background['background_size']) ? $wrap_background['background_size'] : '';
    $background_attachment = isset($wrap_background['background_attachment']) ? $wrap_background['background_attachment'] : '';

    $wrap_background_attributes[] = "background-image: url('{$wrap_background['background_image_url']}')";

    if (!empty($background_repeat)) {
        $wrap_background_attributes[] = "background-repeat: {$background_repeat}";
    }

    if (!empty($background_position)) {
        $wrap_background_attributes[] = "background-position: {$background_position}";
    }

    if (!empty($background_size)) {
        $wrap_background_attributes[] = "background-size: {$background_size}";
    }

    if (!empty($background_attachment)) {
        $wrap_background_attributes[] = "background-attachment: {$background_attachment}";
    }
}

if (is_array($background) && isset($background['background_color']) && !empty($background['background_color'])) {
    $background_attributes[] = "background-color: {$background['background_color']} !important";
}
if (is_array($background) && isset($background['background_image_url']) && !empty($background['background_image_url'])) {
    $background_repeat = isset($background['background_repeat']) ? $background['background_repeat'] : '';
    $background_position = isset($background['background_position']) ? $background['background_position'] : '';
    $background_size = isset($background['background_size']) ? $background['background_size'] : '';
    $background_attachment = isset($background['background_attachment']) ? $background['background_attachment'] : '';

    $background_attributes[] = "background-image: url('{$background['background_image_url']}')";

    if (!empty($background_repeat)) {
        $background_attributes[] = "background-repeat: {$background_repeat}";
    }

    if (!empty($background_position)) {
        $background_attributes[] = "background-position: {$background_position}";
    }

    if (!empty($background_size)) {
        $background_attributes[] = "background-size: {$background_size}";
    }

    if (!empty($background_attachment)) {
        $background_attributes[] = "background-attachment: {$background_attachment}";
    }
}

?>
<div id="gsf-popup-mailchimp-wrapper" class="<?php echo esc_attr(join(' ', $wrapper_classes))  ?>" tabindex="-1" role="dialog"
     aria-hidden="true" <?php echo implode(' ',$data_popup_mailchimp) ?> style="<?php echo esc_attr(implode('; ', array_filter($wrap_background_attributes))) ;?>">
    <div class="modal-dialog block-center">
        <div id="gsf-popup-mailchimp-form" class="modal-content block-center-inner" style="<?php echo esc_attr(implode('; ', array_filter($background_attributes)));?>">
            <div class="mailchimp-form-inner">
                <button type="button" class="close" data-dismiss="modal"
                        aria-label="<?php esc_attr_e('Close', 'g5plus-hebes'); ?>"><i class="fal fa-times"></i></button>
                <div class="modal-header">
                    <?php echo G5Plus_Hebes()->helper()->content_block($mailchimp_popup_content_block); ?>
                </div>
                <div class="modal-footer">
                    <input id="remember-show" type="checkbox" name="remember-show"/>
                    <label for="remember-show"><?php esc_html_e("Don't show this popup again", 'g5plus-hebes') ?></label>
                </div>
            </div>
        </div>
    </div>
</div>
