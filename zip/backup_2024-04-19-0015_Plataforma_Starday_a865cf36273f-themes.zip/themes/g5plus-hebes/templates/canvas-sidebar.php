<?php
/**
 * The template for displaying canvas-sidebar
 */
$skin = G5Plus_Hebes()->options()->get_option('canvas_sidebar_skin','skin-dark');
$wrapper_classes = array(
	'canvas-sidebar-wrapper'
);

$inner_classes = array(
	'canvas-sidebar-inner',
	'sidebar'
);

$skin_classes = G5Plus_Hebes()->helper()->getSkinClass($skin, true);
$wrapper_classes = array_merge($wrapper_classes,$skin_classes);

$wrapper_class = implode(' ',array_filter($wrapper_classes));
$inner_class = implode(' ',array_filter($inner_classes));
?>
<div id="canvas-sidebar-wrapper" class="<?php echo esc_attr($wrapper_class); ?>">
	<div class="<?php echo esc_attr($inner_class)?>">
		<?php if (is_active_sidebar('canvas')): ?>
			<?php dynamic_sidebar('canvas'); ?>
		<?php endif; ?>
	</div>
</div>