<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 8/28/2017
 * Time: 3:18 PM
 */

?>
<a class="gsf-link" href="<?php G5Plus_Hebes()->portfolio()->the_permalink(); ?>"><i class="fal fa-link"></i></a>
