<?php
echo get_the_term_list(get_the_ID(),G5Plus_Hebes()->portfolio()->get_taxonomy_category(),'<h6 class="portfolio-cat">',', ','</h6>');