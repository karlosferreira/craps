<?php
/**
 * The template for displaying post-title.php
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
?>
<h3 class="gsf-portfolio-title fs-20 mg-bottom-10"><a title="<?php the_title_attribute() ?>" href="<?php G5Plus_Hebes()->portfolio()->the_permalink() ?>"><?php the_title() ?></a></h3>
