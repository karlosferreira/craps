<?php
/**
 * The template for displaying footer
 */
$footer_enable = G5Plus_Hebes()->options()->get_option('footer_enable','on');
if ($footer_enable !== 'on') return;
$footer_fixed_enable = G5Plus_Hebes()->options()->get_option('footer_fixed_enable');
$wrapper_classes = array(
	'main-footer-wrapper'
);

if ($footer_fixed_enable === 'on') {
	$wrapper_classes[] = 'footer-fixed';
}
$content_block = G5Plus_Hebes()->options()->get_option('footer_content_block');
$content_block = G5Plus_Hebes()->helper()->content_block($content_block);
$wrapper_class = implode(' ', array_filter($wrapper_classes));
?>
<footer class="<?php echo esc_attr($wrapper_class); ?>">
    <?php if (!empty($content_block)) : ?>
        <?php printf('%s', $content_block); ?>
    <?php endif; ?>
</footer>