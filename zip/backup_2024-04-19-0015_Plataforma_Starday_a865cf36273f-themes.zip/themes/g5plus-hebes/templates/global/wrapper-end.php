<?php
/**
 * The template for displaying wrapper-end
 */
?>
			</div> <!-- End Primary Content Inner -->
			<?php get_sidebar(); ?>
		</div> <!-- End Primary Content Row -->
	</div> <!-- End Primary Content Container -->
	<?php
	/**
	 * * @hooked - woocommerce_output_upsells_products - 15
	 * @hooked - woocommerce_output_related_products - 20
	 
	 **/
	do_action('g5plus_after_main_content');
	?>
</div> <!-- End Primary Content Wrapper -->