<?php
/**
 * The template for displaying back-to-top
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
$back_to_top = G5Plus_Hebes()->options()->get_option('back_to_top','on');
if ($back_to_top !== 'on') return;
?>
<a class="back-to-top" href="javascript:;">
	<i class="fal fa-angle-up"></i>
</a>