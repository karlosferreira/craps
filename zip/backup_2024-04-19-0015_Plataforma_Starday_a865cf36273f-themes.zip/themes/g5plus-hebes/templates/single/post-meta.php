<?php
/**
 * The template for displaying post-meta.php
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
?>
<ul class="gf-post-meta disable-color gf-inline">
	<div class="gf-author-avatar">
		<?php
		$author_bio_avatar_size = apply_filters( 'g5plus_author_bio_avatar_size', 40 );
		echo get_avatar( get_the_author_meta( 'user_email' ), $author_bio_avatar_size );
		?>
	</div>
	<li class="meta-author">
		<span><?php esc_html_e('by ', 'g5plus-hebes'); ?></span><a title="<?php echo esc_attr(get_the_author())?>" href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) ))?>"><?php echo esc_html(get_the_author()); ?></a>
	</li>
	<span>|</span>
	<li class="meta-date">
		<?php
		$date_string = get_the_date(get_option('date_format'));
		echo G5Plus_Hebes()->blog()->time_elapsed_string($date_string);
		?>
	</li>
	<span>|</span>
	<li class="gf-post-cat-meta">
		<?php echo get_the_category_list(', '); ?>
	</li>
</ul>
