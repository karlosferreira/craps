<?php
/**
 * The template for displaying layout-1.php
 *
 */
add_action('g5plus_before_main_content',array(G5Plus_Hebes()->templates(),'post_single_image'),10);
G5Plus_Hebes()->helper()->get_header();
while (have_posts()) : the_post();
	G5Plus_Hebes()->helper()->getTemplate('single/layout-7/content');
endwhile;
G5Plus_Hebes()->helper()->get_footer();