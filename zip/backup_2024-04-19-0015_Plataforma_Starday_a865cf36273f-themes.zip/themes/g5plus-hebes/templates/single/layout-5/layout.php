<?php
/**
 * The template for displaying layout-1.php
 */
G5Plus_Hebes()->helper()->get_header();
while (have_posts()) : the_post();
    G5Plus_Hebes()->helper()->getTemplate('single/layout-5/content');
endwhile;
G5Plus_Hebes()->helper()->get_footer();