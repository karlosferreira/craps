<?php
/**
 * The template for displaying post-title.php
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
?>
<h1 class="gf-post-title heading-color"><?php the_title() ?></h1>
