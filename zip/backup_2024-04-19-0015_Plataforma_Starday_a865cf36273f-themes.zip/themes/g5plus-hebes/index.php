<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
G5Plus_Hebes()->helper()->get_header();
$blog_cate_filter = G5Plus_Hebes()->options()->get_option('blog_cate_filter');
$query_args = $settings = null;
if('' !== $blog_cate_filter) {
    $settings['category_filter_enable'] = true;
    $settings['category_filter_align'] = $blog_cate_filter;
}
G5Plus_Hebes()->blog()->archive_markup($query_args,$settings);
G5Plus_Hebes()->helper()->get_footer();