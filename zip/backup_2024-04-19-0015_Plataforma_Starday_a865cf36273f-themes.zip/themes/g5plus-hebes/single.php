<?php
/**
 * The template for displaying single
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
$single_post_layout = G5Plus_Hebes()->options()->get_option('single_post_layout','layout-1');
G5Plus_Hebes()->helper()->getTemplate("single/{$single_post_layout}/layout");


