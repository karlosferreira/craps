<?php
/**
 * The template for displaying category.php
 *
 * @package WordPress
 * @subpackage hebes
 * @since hebes 1.0
 */
G5Plus_Hebes()->helper()->get_header();
$blog_cate_filter = G5Plus_Hebes()->options()->get_option('blog_cate_filter');
$query_args = $settings = null;
$current_cat = get_category( get_query_var( 'cat' ) );
if('' !== $blog_cate_filter) {
    $settings['category_filter_enable'] = true;
    $settings['category_filter_align'] = $blog_cate_filter;
    $settings['current_cat'] = $current_cat->term_id;
}
G5Plus_Hebes()->blog()->archive_markup($query_args,$settings);
G5Plus_Hebes()->helper()->get_footer();