<?php
$single_layout = G5Plus_Hebes()->options()->get_option('single_portfolio_layout','layout-1');
G5Plus_Hebes()->helper()->get_header();
while (have_posts()) : the_post();
    G5Plus_Hebes()->helper()->getTemplate("portfolio/single/layout/{$single_layout}");
endwhile;
G5Plus_Hebes()->helper()->get_footer();
