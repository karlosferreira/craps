<?php
/**
 * The template for displaying footer.php
 *
 */
/**
 * @hooked - G5Plus_Hebes()->templates()->content_wrapper_end() - 1
 **/
do_action('g5plus_main_wrapper_content_end');
?>
</div><!-- Close Wrapper Content -->


