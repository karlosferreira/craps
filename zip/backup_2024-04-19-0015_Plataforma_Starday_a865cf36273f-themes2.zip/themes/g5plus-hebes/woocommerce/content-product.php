<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
  * @package WooCommerce/Templates
 * @version 3.6.0
 * @var $image_size
 * @var $post_class
 * @var $post_inner_class
 * @var $placeholder_enable
 * @var $product_item_skin
 */

if (!isset($post_class)) {
    $post_class = G5Plus_Hebes()->woocommerce()->get_product_class();
}

if (!isset($post_inner_class)) {
    $post_inner_class = G5Plus_Hebes()->woocommerce()->get_product_inner_class();
}


if (!isset($placeholder_enable)) {
    $placeholder_enable = true;
}


$product_item_skin = isset($product_item_skin) ? $product_item_skin : G5Plus_Hebes()->options()->get_option('product_item_skin','product-skin-01');
$product_layout = G5Plus_Hebes()->options()->get_option('product_catalog_layout','grid');
if (!isset($image_size)) {
	$image_size = 'shop_catalog';
}
if (!in_array($product_layout, array('grid', 'list', 'list-02'))) {
	$product_item_skin = '';
}

if ($product_item_skin == 'product-skin-03') {
	$product_item_skin = 'product-skin-02';
}

G5Plus_Hebes()->helper()->getTemplate('woocommerce/loop/layout/' . $product_item_skin, array(
    'post_class' => $post_class,
    'post_inner_class' => $post_inner_class,
    'placeholder_enable' => $placeholder_enable,
    'image_size' => $image_size
));