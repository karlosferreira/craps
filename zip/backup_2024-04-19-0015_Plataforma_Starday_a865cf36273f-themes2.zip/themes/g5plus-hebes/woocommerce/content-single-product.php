<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked wc_print_notices - 10
 */
do_action('woocommerce_before_single_product');

if (post_password_required()) {
	echo get_the_password_form();
	return;
}
$layout_class = '';
$sidebar_layout = G5Plus_Hebes()->options()->get_option('sidebar_layout','right');
$sidebar = G5Plus_Hebes()->cache()->get_sidebar();
$sidebar_condition = apply_filters('gsf_sidebar_condition', ($sidebar_layout !== 'none' && is_active_sidebar($sidebar)));
if ($sidebar_condition) {
	$layout_class = 'single-product-has-sidebar';
}
$single_layout = G5Plus_Hebes()->options()->get_option('product_single_layout','layout-09');
?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class($layout_class,$product); ?>>
    <?php
    if(!in_array($single_layout, array('layout-01', 'layout-02', 'layout-03', 'layout-05', 'layout-06', 'layout-10'))):
        /**
         * Hook: woocommerce_before_single_product_summary.
         *
         * @hooked woocommerce_show_product_sale_flash - 10
         * @hooked woocommerce_show_product_images - 20
         */
        do_action( 'woocommerce_before_single_product_summary' );
        ?>
        <div class="summary entry-summary">
            <?php
            /**
             * Hook: woocommerce_single_product_summary.
             *
             * @hooked woocommerce_template_single_title - 5
             * @hooked woocommerce_template_single_rating - 10
             * @hooked woocommerce_template_single_price - 10
             * @hooked woocommerce_template_single_excerpt - 20
             * @hooked woocommerce_template_single_add_to_cart - 30
             * @hooked woocommerce_template_single_meta - 40
             * @hooked woocommerce_template_single_sharing - 50
             * @hooked WC_Structured_Data::generate_product_data() - 60
             */
            do_action( 'woocommerce_single_product_summary' );
            ?>
        </div>
        <div class="clearfix"></div>
	<?php
    endif;
	$product_single_layout = G5Plus_Hebes()->options()->get_option('product_single_layout','layout-09');
	if ('layout-05' === $single_layout ) {
		G5Plus_Hebes()->helper()->getTemplate('woocommerce/single/' . $product_single_layout);
	}
	?>
	<?php
	/**
	 * woocommerce_after_single_product_summary hook.
	 *
	 * @hooked woocommerce_output_product_data_tabs - 10
	 * @hooked woocommerce_upsell_display - 15
	 * @hooked woocommerce_output_related_products - 20
	 */
	do_action('woocommerce_after_single_product_summary');
	?>
</div>

<?php do_action('woocommerce_after_single_product'); ?>
