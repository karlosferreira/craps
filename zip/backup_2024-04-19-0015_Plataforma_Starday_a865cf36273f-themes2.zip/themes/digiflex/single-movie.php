<?php
get_header();

$thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );
$title = get_the_title();
$title_image = get_field('title_image_black');
$description = get_field('description');
$rating_title = get_field('rating_title_black', 'option');
$select_quality_image = get_field('select_quality_image');

global $postid;
$postid = get_the_ID();
$comment_post_ID = get_the_ID();


?>
<header class="page-header single">
  <div class="pattern-bg"></div>
  <div class="poster-bg" data-background="<?php the_field('movie_slider_image') ?>"></div>
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="video-player">
          <?php the_field('embed_video') ?>
          <!-- end video-player -->
        </div>
        <!-- end col-12 -->
      </div>
      <!-- end row -->
    </div>
    <!-- end container -->
  </div>
			<style>
  .button-container {
    display: flex;
    justify-content: start;
}
.button-container2 {
  padding-top: 40px; /* Adjust the value as per your preference */
	margin-left: -38px;
}
.button {
    border: 2px solid;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    padding: 12px 24px;
    text-align: center;
    text-decoration: none;
    transition: background-color 0.3s, color 0.3s;
}

.button.black {
    color: black;
    border-color: black;
    margin-right: 20px; /* Create a 20px gap between buttons */
	text-decoration: none;
	font-size: 16px;
    padding: 12px 24px;
}

.button.black:hover {
    background-color: black;
    color: white;
	text-decoration: none;
}

.button.red {
    color: white;
    background-color: red;
	text-decoration: none;
	font-weight: bold;
}

.button.red:hover {
    background-color: darkred;
	text-decoration: none;
	font-weight: bold;
}

.info-bottom .pld-common-wrap > a.pld-like-dislike-trigger i{
  line-height: 66px
}
</style>
</header>
<main>
  <section class="content-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-9">
          <div class="movie-info-box">
            <h2 class="name" style="font-size:30px">
              <?php if(get_field('title_image_black')){ ?>
                  <img src="<?php echo esc_url($title_image['url']); ?>" alt="<?php echo esc_attr($title_image['alt']); ?>" class="img-fluid mb-3">
                <?php }else{ ?>
                  <?php echo wp_kses_post( $title ); ?>
              <?php } ?>
            </h2>
            <div class="features d-flex d-md-none mb-0">
              <div class="d-flex align-items-center imdb_score">
                <?php if( get_field('imdb_score') ): ?>
                  <!-- <div class="imdb_title">
                    <p class="mb-0 mr-2"><?php the_field('imdb_title', 'option') ?></p>
                  </div> -->
                  <!-- <?php if(get_field('rating_title_black', 'option')){ ?>
                    <img src="<?php echo esc_url($rating_title['url']); ?>" alt="<?php echo esc_attr($rating_title['alt']); ?>" class="img-fluid mr-2">
                  <?php } ?> -->
                  <div class="rate">
                    <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                      <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                      <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php  $num = get_field('imdb_score');  echo esc_html__( $num * '10' - '8' ); ?>,100" cx="15" cy="15" r="14"></circle>
                    </svg>
                    <b>
                    <?php the_field('imdb_score') ?>
                    </b> 
                    <!-- <img src="<?php //echo esc_url(get_template_directory_uri()); ?>/images/imdb-logo.svg" alt="IMDB"> <?php echo esc_html__( 'Score', 'digiflex' );?> -->
                  </div>
                  <!-- end rate -->
                <?php endif; ?>
              </div>
              <?php if( get_field('movie_range') ): ?>
                <div class="range">
                  <?php the_field('movie_range') ?>
                </div>
              <?php endif; ?>
                <!-- <?php if( get_field('release_year') ): ?>
                  <div class="year">
                    <?php the_field('release_year') ?>
                  </div>
                <?php endif; ?>
                <?php //if( get_field('select_quality') ): ?>
                  <div class="quality">
                    <?php //the_field('select_quality') ?>
                  </div>
                <?php //endif; ?>
                <?php if(get_field('select_quality_image')){ ?>
                    <img src="<?php echo esc_url($select_quality_image['url']); ?>" alt="<?php echo esc_attr($select_quality_image['alt']); ?>" class="img-fluid mr-4 quality">
                <?php } ?>  -->
              <?php if( get_field('movie_subtitle') ): ?>
              <?php the_field('movie_subtitle') ?>
              <?php endif; ?>
              <?php if( get_field('movie_dubbed') ): ?>
              <?php the_field('movie_dubbed') ?>
              <?php endif; ?>
              <?php

              $terms = get_the_terms( $post->ID, 'movie_categories' );
              if ( $terms && !is_wp_error( $terms ) ):
                ?>
              <div class="category">
                <?php foreach ( $terms as $term ) { ?>
                <?php echo esc_html__( $term->name ); ?>
                <?php } ?>
              </div>
              <?php endif;?>
            </div>
            <div class="movie-side-box d-block d-md-none">
                <figure>
                  <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>">
              </figure>
            </div>

            <h3>
              <div class="subdescription">
                <p>
                <?php echo $description; ?>
                </p>
              </div>
            </h3>
            <div class="features d-none d-md-flex">
              <div class="d-flex align-items-center imdb_score">
                <?php if( get_field('imdb_score') ): ?>
                  <div class="imdb_title">
                    <p class="mb-0 mr-2"><?php the_field('imdb_title', 'option') ?></p>
                  </div>
                  <!-- <?php if(get_field('rating_title_black', 'option')){ ?>
                    <img src="<?php echo esc_url($rating_title['url']); ?>" alt="<?php echo esc_attr($rating_title['alt']); ?>" class="img-fluid mr-2">
                  <?php } ?> -->
                  <div class="rate">
                    <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                      <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                      <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php  $num = get_field('imdb_score');  echo esc_html__( $num * '10' - '8' ); ?>,100" cx="15" cy="15" r="14"></circle>
                    </svg>
                    <b>
                    <?php the_field('imdb_score') ?>
                    </b> 
                    <!-- <img src="<?php //echo esc_url(get_template_directory_uri()); ?>/images/imdb-logo.svg" alt="IMDB"> <?php echo esc_html__( 'Score', 'digiflex' );?> -->
                  </div>
                  <!-- end rate -->
                  <?php endif; ?>
                </div>
                <!-- <?php if( get_field('release_year') ): ?>
                  <div class="year">
                    <?php the_field('release_year') ?>
                  </div>
                <?php endif; ?>
                <?php //if( get_field('select_quality') ): ?>
                  <div class="quality">
                    <?php //the_field('select_quality') ?>
                  </div>
                <?php //endif; ?>
                <?php if(get_field('select_quality_image')){ ?>
                    <img src="<?php echo esc_url($select_quality_image['url']); ?>" alt="<?php echo esc_attr($select_quality_image['alt']); ?>" class="img-fluid mr-4 quality">
                <?php } ?>
              <?php if( get_field('movie_range') ): ?>
              <div class="range">
                <?php the_field('movie_range') ?>
              </div> -->
              <!-- end range -->
              <?php endif; ?>
              <?php if( get_field('movie_subtitle') ): ?>
              <?php the_field('movie_subtitle') ?>
              <?php endif; ?>
              <?php if( get_field('movie_dubbed') ): ?>
              <?php the_field('movie_dubbed') ?>
              <?php endif; ?>
              <?php

              $terms = get_the_terms( $post->ID, 'movie_categories' );
              if ( $terms && !is_wp_error( $terms ) ):
                ?>
              <div class="category">
                <?php foreach ( $terms as $term ) { ?>
                <?php echo esc_html__( $term->name ); ?>
                <?php } ?>
              </div>
              <?php endif;?>
            </div>
            <!-- end features -->
            <?php if( get_field('movie_short_description') ): ?>
            <p class="description">
              <?php the_field('movie_short_description') ?>
            </p>
            <?php endif; ?>
            <ul class="info">
              <?php if( get_field('movie_director') ): ?>
              <li>
                <h6><?php echo esc_html__( 'Director', 'digiflex' );?></h6>
                : <span>
                <?php the_field('movie_director') ?>
                </span> </li>
              <?php endif; ?>
              <?php if( get_field('movie_cast') ): ?>
              <li>
                <h6><?php echo esc_html__( 'Casting', 'digiflex' );?></h6>
                : <span>
                <?php the_field('movie_cast') ?>
                </span> </li>
              <?php endif; ?>
              <?php if( get_field('movie_producer') ): ?>
              <li>
                <h6><?php echo esc_html__( 'Production', 'digiflex' );?></h6>
                : <span>
                <?php the_field('movie_producer') ?>
                </span> </li>
              <?php endif; ?>
              <?php

              if ( have_rows( 'extra_fields' ) ):


                ?>
              <?php while ( have_rows('extra_fields') ) : the_row(); ?>
              <li>
                <h6>
                  <?php the_sub_field('title'); ?>
                </h6>
                : <span>
                <?php the_sub_field('content'); ?>
                </span> </li>
              <?php
              endwhile;
              else :
                ?>
              <?php  endif;?>
            </ul>
            <!-- end info -->
          </div>
          <!-- end movie-info-box -->
        </div>
        <!-- end col-9 -->
        <div class="col-lg-3 d-none d-md-block">
          <div class="movie-side-box">
            <figure><img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>"></figure>
          </div>
          <!-- end movie-side-box -->
        </div>
        <!-- end col-3 -->
        <div class="col-12">
			   <div class="button-container">
    <a href="https://starday.com.br" target="_blank" class="button black">SAIBA MAIS</a>
    <a href="https://stardayoficial.com/assinatura-starday-passo-1/" target="_blank" class="button red">ASSINE AGORA</a>			
               </div>
			  <div class="button-container2">
          <div class="info-bottom">
			  	<?php echo do_shortcode('[posts_like_dislike]');?>
			  </div>
        </div>
        <!-- end col-12 -->
      </div>
      <!-- end row -->
    </div>
    <!-- end container -->
  </section>
  <!-- end content-section -->
  <section class="content-section" data-background="#111111">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="section-title light">
            <h6><?php echo esc_html__( 'FIND ANYWHERE ELSE', 'digiflex' );?></h6>
            <h2><?php echo esc_html__( 'Related Movies', 'digiflex' );?></h2>
          </div>
          <!-- end section-title -->
        </div>
        <!-- end col-12 -->
        <?php

        $args = array(
          'post_type' => 'movie',
          'posts_per_page' => '6',
          'meta_query' => array(
            array(
              'taxonomy' => $term,
              'field' => 'slug',
            ),
          ),

        );
        $movie = new WP_Query( $args );


        if ( $movie->have_posts() ):
          while ( $movie->have_posts() ):
            $movie->the_post();

        $thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );

        $title = get_the_title();


        ?>
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
          <div class="video-thumb light">
           <a href="<?php the_permalink(); ?>" class="video-image"> <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>">
              <?php if( get_field('imdb_score') ): ?>
              <div class="circle-rate">
                <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                  <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                  <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php  $num = get_field('imdb_score');  echo esc_html__( $num * '10' - '8' ); ?>,100" cx="15" cy="15" r="14"></circle>
                </svg>
                <b>
                <?php the_field('imdb_score') ?>
                </b> </div>
              <!-- end circle-rate -->
              <?php endif; ?>
              <?php if( get_field('select_quality') ): ?>
              <div class="hd">
                <?php the_field('select_quality') ?>
              </div>
              <!-- end hd -->
              <?php endif; ?>
            </a>
            <div class="video-content">
              <?php if( get_field('age_range') ): ?>
              <div class="age">
                <?php the_field('age_range') ?>
              </div>
              <!-- end age -->
              <?php endif; ?>
              <?php if( get_field('release_year') ): ?>
              <small class="year">
              <?php the_field('release_year') ?>
              </small>
              <?php endif; ?>
              <?php

              $terms = get_the_terms( $post->ID, 'movie_categories' );
              if ( $terms && !is_wp_error( $terms ) ):
                ?>
              <ul class="tags">
                <?php foreach ( $terms as $term ) { ?>
                <li><?php echo esc_html__( $term->name ); ?></li>
                <?php } ?>
              </ul>
              <?php endif;?>
              <h3 class="name"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" data-text="<?php echo wp_kses_post( $title ); ?>"> <?php echo wp_kses_post( $title ); ?> </a></h3>
            </div>
            <!-- end video-content -->
          </div>
          <!-- end video-thumb -->
        </div>
        <!-- end col-2 -->
        <?php endwhile; ?>
        <?php endif; ?>
      </div>
      <!-- end row -->
    </div>
    <!-- end container -->
  </section>
  <!-- end content-section -->
</main>
<?php get_footer(); ?>
