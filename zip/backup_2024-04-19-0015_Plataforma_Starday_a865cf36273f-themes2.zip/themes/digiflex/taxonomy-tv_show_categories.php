<?php

get_header();

digiflex_render_page_header( 'level' );
$queried_object = get_queried_object();
?>

<main>
  <section class="content-section">
    <div class="container">
      <div class="row">
        <?php
            $the_query = new WP_Query(array( 
                'posts_per_page' => 12,
                'post_type' => 'tv_show',
                'meta_key' => 'display_on_slider',
                'meta_value' => 'yes',
                'tax_query' => array(
                    array (
                        'taxonomy' => 'tv_show_categories',
                        'field' => 'slug',
                        'terms' => $queried_object->slug,
                    )
                ),
                'paged' => !empty($_GET['pg']) ? absint($_GET['pg']) : 1,
            ));

            while ( $the_query->have_posts() ): $the_query->the_post();

            $thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );
            $title = get_the_title();
            $post_terms = get_the_terms( get_the_ID(), 'tv_show_tag' );

        ?>

        
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
            <div class="video-thumb">
                <a href="<?php the_permalink(); ?>" class="video-image"> <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>">
                    <?php if( get_field('imdb_score') ): ?>
                        <div class="circle-rate">
                            <svg class="circle-chart" viewBox="0 0 30 30" width="100" height="100" xmlns="http://www.w3.org/2000/svg">
                                <circle class="circle-chart__background" stroke="#2f3439" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php  $num = get_field('imdb_score');  echo esc_html__( $num * '10' - '8' ); ?>,100" cx="15" cy="15" r="14"></circle>
                            </svg>
                            <b><?php the_field('imdb_score') ?></b>
                        </div>
                    <?php endif; ?>
                    <?php if( get_field('select_quality') ): ?>
                        <div class="hd">
                            <?php the_field('select_quality') ?>
                        </div>
                    <?php endif; ?>
                </a>

                <div class="video-content">
                    <?php if( get_field('age_range') ): ?>

                        <div class="age">
                            <?php the_field('age_range') ?>
                        </div>

                        <?php if( get_field('release_year') ): ?>
                            <small class="year"><?php the_field('release_year') ?></small>
                        <?php endif; ?>
                    
                        <?php $terms = get_the_terms( $post->ID, 'movie_categories' );
                        if ( $terms && !is_wp_error( $terms ) ): ?>
                            <ul class="tags">
                                <?php foreach ( $terms as $term )  ?>
                                    <li><?php echo esc_html__( $term->name ); ?></li>
                                <?php  ?>
                            </ul>
                        <?php endif;?>

                    <?php endif; ?>

                    <h3 class="name">
                        <a href="<?php the_permalink(); ?>"> <?php echo esc_html__($post_terms[0]->name); ?> </a>
                    </h3>
                </div>
                <!-- end video-content -->
            </div>
        <!-- end video-thumb -->
        </div>
        <!-- end col-2 -->

        <?php
        endwhile;
        ?>
        <div class="col-12">
          <div class="pagination">
            <?php echo myPaginateLinks($the_query);

            wp_reset_postdata();
            ?>
          </div>
          <!-- end pagination -->
        </div>
        <!-- end col-12 -->
      </div>
      <!-- end row -->
    </div>
    <!-- end container -->
  </section>
  <!-- end content-section -->
</main>

<?php
get_footer();