(function ($) {
  $(document).ready(function () {
    "use strict";

    var owlCarouselHomeBanner = $('.owl-carousel-home-banner').owlCarousel({
      loop: true,
      margin: 0,
      nav: false,
      // dots: true,
      dotsData: true,
      dotsContainer: '#carousel-custom-dots',
      items: 1,
      autoplay: true,
      // smartSpeed: 1000,
      autoplayTimeout: 8500,
      responsive: {
        // breakpoint from 0 up
        0: {
          dots: true
        },
        1024: {
          dots: true
        }
      }
    })

    var owlCarouselHomeLevels = $('.owl-carousel-home-levels').owlCarousel({
      loop: true,
      margin: 0,
      nav: false,
      dots: true,
      //dotsData: true,
      items: 1,
      autoplay: true,
      smartSpeed: 3000,
      autoplayTimeout: 7000,
      autoplayHoverPause: true
    });

    /* MENU TOGGLE */
    $('.mobile-menu .site-menu ul li i').on('click', function (e) {
      $(this).parent().children('.mobile-menu .site-menu ul li ul').toggle();
      return true;
    });


    // FIRST ELEMENTS
    $('.sidebar .widget .gallery-item a').attr('data-fancybox', '');
    $('.accordion .card:first-child .card-header a').attr('aria-expanded', 'true');
    $(".accordion .card:first-child .collapse").addClass("show");
    $(".nav.nav-tabs li:first-child a").addClass("active");
    $(".tab-content .tab-pane:first-child").addClass("active");

    // HAMBURGER MENU
    $('.hamburger-menu').on('click', function (e) {
      $(".hamburger-menu .hamburger").toggleClass('opened');
      $(".mobile-menu").toggleClass('active');
      $("body").toggleClass("overflow");
    });


    // NAVBAR SEARCH
    $('.navbar-search').on('click', function (e) {
      $(".search-box").toggleClass('active');
      $("body").toggleClass("overflow");
    });


    // MAIN SPACER

    if ($('body').hasClass('tax-tv_show_categories')) {
      var mastHeight = $('.page-header').height();
      $('main').css('margin-top', mastHeight);
    } else if ($('body').hasClass('home')) {
      $(window).on('resize', function () {
        var mastHeight = $('.page-header, .slider').outerHeight();
        $('main').css('margin-top', '100vh');
      });
    } else {
      $(window).on('resize', function () {
        var mastHeight = $('.page-header').height();
        $('main').css('margin-top', mastHeight);
      });
    }

    $(window).trigger('resize');



  });
  // END DOCUMENT READY


  var swiper = new Swiper('.carousel-tv-shows', {

    // slidesPerView: 5,
    spaceBetween: 30,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
    observer: true,
    observeParents: true,
    breakpoints: {
      1920: {
        slidesPerView: 6
      },
      1680: {
        slidesPerView: 6
      },
      1440: {
        slidesPerView: 6
      },
      1280: {
        slidesPerView: 6
      },
      1024: {
        slidesPerView: 6
      },
      768: {
        slidesPerView: 2
      },
      640: {
        slidesPerView: 1
      },
      320: {
        slidesPerView: 1
      }
    }
  });

  var swiper = new Swiper('.carousel-e-books', {

    slidesPerView: 4,
    spaceBetween: 30,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
    observer: true,
    observeParents: true,
    breakpoints: {
      1920: {
        slidesPerView: 4
      },
      1680: {
        slidesPerView: 4
      },
      1440: {
        slidesPerView: 4
      },
      1280: {
        slidesPerView: 4
      },
      1024: {
        slidesPerView: 4
      },
      768: {
        slidesPerView: 3
      },
      640: {
        slidesPerView: 1
      },
      320: {
        slidesPerView: 1
      }
    }
  });

  const tvShowsHome = new Swiper('.tv-shows-home', {
    slidesPerView: 3,
    loop: true,
    centeredSlides: true,
    spaceBetween: 40,
    // pagination: {
    //   el: '.swiper-pagination',
    //   dynamicBullets: true,
    //   clickable: true
    // },
    speed: 1400,
    autoplay: {
      delay: 5000,
      disableOnInteraction: true,
    },
    breakpoints: {
      1024: {
        slidesPerView: 3,
        spaceBetween: 50
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 50
      },
      640: {
        slidesPerView: 1,
        spaceBetween: 0,
      },
      320: {
        slidesPerView: 1,
        spaceBetween: 0,
      }
    },

  });

  //Correção do bug de quebra do layout da homepage. Quando a página carrega em
  //aba inativa.  
  document.addEventListener("visibilitychange", function () {
    tvShowsHome.update();
  });

  // hack para previnir bug de imagens no js do swiper para a nova estrutura
  // do slideshow de séries
  window.addEventListener('resize', function () {
    tvShowsHome.update();
  });

  // SLIDER
  var interleaveOffset = 0.5;
  var swiperOptions = {
    loop: true,
    speed: 500,
    parallax: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
    // autoplay: false,
    grabCursor: true,
    watchSlidesProgress: true,
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
      renderBullet: function (index, className) {
        return '<span class="' + className + '"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30"><circle r="13" cy="15" cx="15"></circle></svg></span>';
      },
    },
    on: {
      progress: function () {
        var swiper = this;
        for (var i = 0; i < swiper.slides.length; i++) {
          var slideProgress = swiper.slides[i].progress;
          var innerOffset = swiper.width * interleaveOffset;
          var innerTranslate = slideProgress * innerOffset;
          swiper.slides[i].querySelector(".slide-inner").style.transform =
            "translate3d(" + innerTranslate + "px, 0, 0)";
        }
      },
      touchStart: function () {
        var swiper = this;
        for (var i = 0; i < swiper.slides.length; i++) {
          swiper.slides[i].style.transition = "";
        }
      },
      setTransition: function (speed) {
        var swiper = this;
        for (var i = 0; i < swiper.slides.length; i++) {
          swiper.slides[i].style.transition = speed + "ms";
          swiper.slides[i].querySelector(".slide-inner").style.transition =
            speed + "ms";
        }
      }
    }
  };

  var swiper = new Swiper(".main-slider", swiperOptions);


  // DATA BACKGROUND IMAGE
  var pageSection = $("*");
  pageSection.each(function (indx) {
    if ($(this).attr("data-background")) {
      $(this).css("background", "url(" + $(this).data("background") + ")");
    }
  });

  // DATA BACKGROUND COLOR
  var pageSection = $("*");
  pageSection.each(function (indx) {
    if ($(this).attr("data-background")) {
      $(this).css("background", $(this).data("background"));
    }
  });

  $('.tv_show_categories_home_mobile .category a').click(function (e) {
    e.preventDefault();

    if ($(this).hasClass('clicked')) {
      $('.tv_show_categories_home_mobile .category a').removeClass('clicked')
      var url = $(this).attr('href');
      window.location = url;
    } else {
      $(this).addClass('clicked');
    }
  });

  $('.carousel-e-books a.video-image').click(function (e) {
    e.preventDefault();

    if ($(this).hasClass('clicked')) {
      $('.carousel-e-books a.video-image').removeClass('clicked')
      var url = $(this).attr('href');
      window.location = url;
    } else {
      $(this).addClass('clicked');
    }
  });
  

  // if (window.history) {
  //   var myOldUrl = window.location.href;
  //   window.addEventListener('hashchange', function(){
  //     $('.preoloader-plus').removeClass('complete');
  //     window.history.pushState({}, null, myOldUrl);
  //   });
  // }

  // $('a').on('click', function (){
  //   if(!$(this).hasClass('elementor-item-anchor')){
  //     $('.preloader-plus').css('transition', 'none').removeClass('complete');
  //   }
  // })
})(jQuery);