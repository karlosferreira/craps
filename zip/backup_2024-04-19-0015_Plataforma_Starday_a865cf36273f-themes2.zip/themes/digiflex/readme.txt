=== Digiflex ===
Author: Themezinho
Requires at least: 5.0
Tested up to: 5.5.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Online Movie Streaming WordPress Theme


== Description ==

Digiflex is a beautiful movies website for all kind of online streaming purpose. If you want to present your movie portal in best look than you might use Digiflex to create very quickly. Based on WP Bakery and all files and codes has been well organized.


== Changelog ==

= 1.0 =
* Initial Release

