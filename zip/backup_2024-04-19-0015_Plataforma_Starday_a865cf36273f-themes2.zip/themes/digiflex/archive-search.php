<?php
/**
 * Template Name: Movies
 *
 */

get_header();

digiflex_render_page_header( 'search' );


?>
<main>
  <section class="content-section">
    <div class="container">
      <div class="row">
        <?php
        $the_query = new WP_Query( array( 'posts_per_page' => 10,
          'post_type' => 'tv_show',
          'paged' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 ) );

        if ( have_posts() ): while ( have_posts() ): the_post();

        $thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );

        $title = get_the_title();

        ?>
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
          <div class="video-thumb">
            <a href="<?php the_permalink(); ?>" class="video-image"> <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>">
              <div class="circle-rate">
                <svg class="circle-chart" viewBox="0 0 30 30" width="100" height="100" xmlns="http://www.w3.org/2000/svg">
                  <circle class="circle-chart__background" stroke="#2f3439" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                  <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php  $num = get_field('imdb_score');  echo esc_html__( $num * '10' - '8' ); ?>,100" cx="15" cy="15" r="14"></circle>
                </svg>
                <b>
                <?php the_field('imdb_score') ?>
                </b> </div>
              <!-- end circle-rate -->
              <div class="hd">
                <?php the_field('select_quality') ?>
              </div>
              <!-- end hd --> 
            </a>
            <div class="video-content"> 
					<?php if( get_field('age_range') ): ?>
              <div class="age">
                <?php the_field('age_range') ?>
              </div>
              <!-- end age -->
				<?php if( get_field('release_year') ): ?>
				<small class="year">
              <?php the_field('release_year') ?>
              </small>
				<?php endif; ?>
              <?php

              $terms = get_the_terms( $post->ID, 'categories' );
              if ( $terms && !is_wp_error( $terms ) ):
                ?>
              <ul class="tags">
                <?php foreach ( $terms as $term )  ?>
                <li><?php echo esc_html__( $term->name ); ?></li>
                <?php  ?>
              </ul>
              <?php endif;?>
			
				<?php endif; ?>
              <h3 class="name"><a href="<?php the_permalink(); ?>"> <?php echo wp_kses_post( $title ); ?> </a></h3>
            </div>
            <!-- end video-content --> 
          </div>
          <!-- end video-thumb --> 
        </div>
        <!-- end col-2 -->
        <?php
        endwhile;
        ?>
        <?php else : ?>
        <p>
          <?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.',  'digiflex' ); ?>
        </p>
		  <form role="search" action="<?php echo site_url('/'); ?>" method="get" id="searchform">
			  <select name="post_type">
			<option value="movie">Movie</option>
			<option value="tv_show">TV Show</option>
		</select>
      <input type="search" name="s" placeholder="<?php echo esc_attr__( 'Search here', 'digiflex' );?>"/>
      <input type="submit" alt="Search" value="<?php echo esc_attr__( 'FIND', 'digiflex' );?>" />
    </form>
        <?php endif; ?>
      </div>
      <!-- end row --> 
    </div>
    <!-- end container --> 
  </section>
  <!-- end content-section --> 
</main>
<?php
get_footer();
