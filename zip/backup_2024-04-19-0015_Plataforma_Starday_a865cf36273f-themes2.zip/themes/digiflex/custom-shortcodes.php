<?php

function ts_levels_function(){

    $terms = get_terms( array(
        'taxonomy'   => 'tv_show_categories',
        'hide_empty' => false,
    ) );
        
    if ( $terms && ! is_wp_error( $terms ) ) :
        ?>
        <div class="d-none d-md-flex row tv_show_categories_home">
            <div class="col-md-10 offset-md-1">
                <div class="row">
                    <?php
                        foreach ( $terms as $term ) {
                        $imagem = get_field('imagem', $term);
                    ?>
                        <div class="col-6 col-md-4 mb-5 category">
                            <a href="<?php echo get_term_link( $term->term_id, 'tv_show_categories');?>">
                                <div class="overlay">
                                    <span class="title"><?php echo $term->name; ?></span>
                                    <?php echo $term->description; ?>
                                </div>
                                <img src="<?php echo esc_url($imagem['url']); ?>" alt="<?php echo esc_attr($imagem['alt']); ?>" class="img-fluid">
                            </a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <div class="d-md-none row tv_show_categories_home tv_show_categories_home_mobile">
            <div class="col-12 category">
                <div class="owl-carousel owl-theme owl-carousel-home-levels">
                    <?php
                        foreach ( $terms as $term ) {
                        $imagem = get_field('imagem', $term);
                    ?>
                        <div class="item">
                            <a href="<?php echo get_term_link( $term->term_id, 'tv_show_categories');?>">
                                <div class="overlay">
                                    <span class="title"><?php echo $term->name; ?></span>
                                    <?php echo $term->description; ?>
                                </div>
                                <img src="<?php echo esc_url($imagem['url']); ?>" alt="<?php echo esc_attr($imagem['alt']); ?>" class="img-fluid">
                            </a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    <?php endif;
}

function ts_banner1_function(){
    if( have_rows('banner_1') ):
        while( have_rows('banner_1') ): the_row();  ?>
            <?php $banner1_imagem_desktop = get_sub_field('imagem'); ?>
            <div class="featured_banner_home" style="background-image: url(<?php echo esc_url($banner1_imagem_desktop['url']); ?>)">
                <div class="container">
                    <div class="row">
                        <div class="col-12 offset-0 col-md-10 offset-md-1">
                            <p class="subtitulo"><?php the_sub_field('subtitulo') ?></p>
                            <h3><?php the_sub_field('titulo') ?></h3>
                            <p class="descricao"><?php the_sub_field('descricao') ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile;
    endif;
}

function ts_banner2_function(){
    if( have_rows('banner_2') ):
        while( have_rows('banner_2') ): the_row();  ?>
            <?php $banner1_imagem_desktop = get_sub_field('imagem'); ?>
            <div class="featured_banner_home" style="background-image: url(<?php echo esc_url($banner1_imagem_desktop['url']); ?>)">
                <div class="container">
                    <div class="row">
                        <div class="col-12 offset-0 col-md-10 offset-md-1">
                            <p class="subtitulo"><?php the_sub_field('subtitulo') ?></p>
                            <h3><?php the_sub_field('titulo') ?></h3>
                            <p class="descricao"><?php the_sub_field('descricao') ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile;
    endif;
}   

function ts_banner_videos_function(){
    if( have_rows('banner_videos') ):
        while( have_rows('banner_videos') ): the_row();  ?>
            <?php $banner1_imagem_desktop = get_sub_field('imagem'); ?>
            <div class="featured_banner_home" style="background-image: url(<?php echo esc_url($banner1_imagem_desktop['url']); ?>)">
                <div class="container">
                    <div class="row">
                        <div class="col-12 offset-0 col-md-10 offset-md-1">
                            <p class="subtitulo"><?php the_sub_field('subtitulo') ?></p>
                            <h3><?php the_sub_field('titulo') ?></h3>
                            <p class="descricao"><?php the_sub_field('descricao') ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile;
    endif;
}   

add_shortcode('ts_levels', 'ts_levels_function');
add_shortcode('ts_banner1', 'ts_banner1_function');
add_shortcode('ts_banner2', 'ts_banner2_function');
add_shortcode('ts_banner_videos', 'ts_banner_videos_function');
