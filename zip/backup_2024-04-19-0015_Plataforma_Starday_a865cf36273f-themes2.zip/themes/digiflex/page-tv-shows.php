<?php
/**
 * Template Name: TV Shows
 *
 */

get_header();
digiflex_render_page_header( 'page' );

?>
<main>
    <section class="content-section">
        <div class="container">
            <div class="row">
              <?php

                $the_query = new WP_Query( array( 'posts_per_page' => 8,
                  'post_type' => 'tv_show',
                  'paged' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 ) );

                while ( $the_query->have_posts() ): $the_query->the_post();

                $thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );
                $title = get_the_title();
                
              ?>
              <div class="col-lg-3 col-sm-6">
                <div class="category-thumb">
                  <figure class="category-image"><a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>"></a></figure>
                  <div class="category-content">
                    <?php
                      $terms = get_the_terms( $post->ID, 'tv_show_categories' );
                      if ( $terms && !is_wp_error( $terms ) ):
                    ?>
                      <ul class="tags">
                          <?php foreach ( $terms as $term ) { ?>
                          <li><?php echo esc_html__( $term->name ); ?></li>
                          <?php } ?>
                      </ul>
                    <?php endif;?>
                    <div class="play-btn"><a href="<?php the_permalink(); ?>"> +</a></div>
                      <!-- end category-content -->
                  </div>
                      <!-- end category-thumb -->
                </div>
                <!-- end col-3 -->
              </div>

              <?php endwhile; ?>

              <div class="col-12">
                <div class="pagination">
                  <?php
                    $big = 999999999;
                    echo paginate_links( array(
                      'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                      'format' => '?paged=%#%',
                      'current' => max( 1, get_query_var( 'paged' ) ),
                      'total' => $the_query->max_num_pages
                    ) );
                    wp_reset_postdata();
                  ?>
                </div>
                <!-- end pagination -->
              </div>
              <!-- end col-12 -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </section>
    <!-- end content-section -->
</main>
<?php
get_footer();