<?php

if( ! function_exists( 'digiflex_register_nav_menus' ) ) {
	/**
	 * Register required nav menus
	 */
	function digiflex_register_nav_menus() {

		register_nav_menus( array(
			'header' => esc_html__( 'Main menu',  'digiflex' ),
			'user_menu' => esc_html__( 'User menu',  'digiflex' ),
		) );
		

	}
	add_action( 'after_setup_theme', 'digiflex_register_nav_menus' );
}