<?php


if ( !function_exists( 'digiflex_enqueue_styles_and_scripts' ) ) {
  /**
   * This function enqueues the required css and js files.
   *
   * @return void
   */
  function digiflex_enqueue_styles_and_scripts() {
    /**
     * Enqueue css files.
     */
    wp_enqueue_style( 'lineicons', get_template_directory_uri() . '/css/lineicons.css' );
    wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/fancybox.min.css' );
    wp_enqueue_style( 'swiper', get_template_directory_uri() . '/css/swiper.min.css' );
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css' );
    wp_enqueue_style( 'digiflex-main-style', get_template_directory_uri() . '/css/style.css?v=' . mt_rand() );
    wp_enqueue_style( 'digiflex-stylesheet', get_stylesheet_uri() );
    wp_add_inline_style( 'digiflex-stylesheet', digiflex_dynamic_css() );

    /**
     * Enqueue javascript files.
     */

    wp_enqueue_script( 'comments', get_template_directory_uri() . '/js/comments.js', array(), false, false );
    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/js/fancybox.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'swiper', get_template_directory_uri() . '/js/swiper.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'owlcarousel', get_template_directory_uri() . '/js/owlcarousel.min.js', array( 'jquery' ), false, true );
    wp_enqueue_script( 'videojs', get_template_directory_uri() . '/js/videojs.min.js', array(), false, true );
    wp_enqueue_script( 'youtube', get_template_directory_uri() . '/js/youtube.min.js', array(), false, true );
    wp_enqueue_script( 'isotope', get_template_directory_uri() . '/js/isotope.min.js', array( 'jquery'), false, true );
    wp_enqueue_script( 'digiflex-scripts', get_template_directory_uri() . '/js/scripts.js?v=' . mt_rand(), array( 'jquery' ), false, true );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
      wp_enqueue_script( 'comment-reply' );
    }


    $comment_data = array(
      'name' => esc_html__( 'Name is required', 'digiflex' ),
      'email' => esc_html__( 'Email is required', 'digiflex' ),
      'comment' => esc_html__( 'Comment is required', 'digiflex' ),

    );

    wp_localize_script( 'comments', 'comment_data', $comment_data );
  }

  add_action( 'wp_enqueue_scripts', 'digiflex_enqueue_styles_and_scripts', 10 );
}

if ( !function_exists( 'digiflex_dynamic_css' ) ) {
  function digiflex_dynamic_css() {

    $styles = '';
    if ( digiflex_get_option( 'logo_height' ) ) {
      $logo_height = str_replace( ' ', '', digiflex_get_option( 'logo_height' ) );
      $logo_height = str_replace( 'px', '', $logo_height );
      $styles .= "
				.navbar .logo a img{
					height: {$logo_height}px;
				}
			";
    }
    if ( digiflex_get_option( 'pageheader_height' ) ) {
      $pageheader_height = str_replace( ' ', '', digiflex_get_option( 'pageheader_height' ) );
      $styles .= "
				.page-header{
					height: {$pageheader_height};
				}
			";
    }
    if ( digiflex_get_option( 'enable_dynamic_color' ) ) {

      $site_color = ( digiflex_get_option( 'theme_color' ) ) ? digiflex_get_option( 'theme_color' ) : '#e90101';
      $body_bg_color = ( digiflex_get_option( 'body_background_color' ) ) ? digiflex_get_option( 'body_background_color' ) : '#ffffff';

      $styles .= "
				:root {
  --color-main: {$site_color}; 
  --color-dark: {$body_bg_color}; 
}
				
			";
    }

    return $styles;
  }
}


add_action( 'init', 'digiflex_dynamic_css' );
add_action(
  'after_setup_theme',
  function () {
    add_theme_support( 'html5', [ 'script', 'style' ] );
  }
);