<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package digiflex
 */

get_header();
?>
<?php
digiflex_render_page_header( 'archive' );

$show_sidebar = ( digiflex_get_option( 'archive_show_sidebar' ) ) ? digiflex_get_option( 'archive_show_sidebar' ) : 'yes';
$wrapper_cols = '10';
$section_class = 'blog';

if ( !is_active_sidebar( 'sidebar-1' ) ) {
  $show_sidebar = 'no';
}

if ( $show_sidebar == 'yes' ) {
  $wrapper_cols = '8';
}
?>
<main>
  <section class="content-section">
    <div class="container">
      <div class="row">
		
		<?php
   $args = array(
               'taxonomy' => 'movie',
               'orderby' => 'name',
               'order'   => 'ASC'
           );

   $cats = get_categories($args);

   foreach($cats as $cat) {
?>
      <a href="<?php echo get_category_link( $cat->term_id ) ?>">
           <?php echo $cat->name; ?>
      </a>
<?php
   }
?>
		
		</div>
      <!-- end row --> 
    </div>
    <!-- end container --> 
  </section>
  <!-- end content-section --> 
</main>
<!-- end main -->
<?php
get_footer();
