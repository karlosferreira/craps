<?php

$series_slug = get_query_var('series');
$series = get_page_by_path($series_slug, OBJECT, 'series');
$serie_post_meta = get_post_meta($series->ID);
$playlist_items = isset($serie_post_meta['playlist_items']) ? $serie_post_meta['playlist_items'] : '';

if (!empty($playlist_items)) {
    $first_element = $playlist_items[0];
    $unserialized_array = unserialize($first_element);
    $serie_id = isset($unserialized_array[0]) ? $unserialized_array[0] : '';

    if (!empty($serie_id)) {
        $first_episode_url = get_permalink($serie_id);
        wp_redirect($first_episode_url, 301);
        exit;
    }
}

// Se não houver playlist personalizada, redirecione para a primeira página da série
$first_episode_url = get_permalink($series->ID);
wp_redirect($first_episode_url, 301);
exit;