<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package digiflex
 */

get_header();
?>
<?php
digiflex_render_page_header( 'page' );


?>
<main> 
  <!-- end int-hero -->
  <section class="content-section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12">
          <?php
          while ( have_posts() ):
            the_post();
          get_template_part( 'template-parts/content', get_post_type() );
          ?>
          <?php
          endwhile; // End of the loop.
          ?>
        </div>
      </div>
      <!-- end row --> 
    </div>
    <!-- end container --> 
  </section>
  <!-- end content-section --> 
</main>
<?php
get_footer();
