<?php

/**
 * Template Name: Favoritos
 *
 */

get_header();

digiflex_render_page_header('favoritos');


$logo = (digiflex_get_option('logo')) ? digiflex_get_option('logo') : get_template_directory_uri() . '/images/logo@2x.png';
$retina_logo = (digiflex_get_option('retina_logo')) ? digiflex_get_option('retina_logo') : '';

?>

<main>
  <section class="content-section">
    <div class="container-fluid">
      <div id="videos" class="vc_row wpb_row vc_row-fluid movies_section">
        <div class="wpb_column vc_column_container vc_col-sm-12">
          <div class="vc_column-inner">
            <div class="wpb_wrapper">
              <div class="row">
                <div class="col-12">
                  <?php
                    echo do_shortcode('[starday_favorite_list_shortcode current_user='. get_current_user_id() .']');
                  ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row justify-content-center">

      </div>
    </div>
  </section>
</main>

<style>
  .page-template-page-favoritos .content-section {
    background: #2d2d2d;
    padding: 170px 0;
  }

  /* .page-template-page-favoritos main {
    margin-top: 314px !important;
  } */

  /* .page-template-page-favoritos .tv-show-entry {
    margin-bottom: 30px;
  } */

  .page-template-page-favoritos .tv-show-entry img {
    max-width: 100%;
    height: auto;
  }

  .page-template-page-favoritos .video-thumb .video-content .name a {
    color: #fff !important;
    line-height: 22px;
    font-size: 12px;
  }

  .page-template-page-favoritos #videos .grid {
    text-align: center;
    color: #fff
  }
  
  .page-template-page-favoritos #videos {
    max-width: 1350px;
    margin-left: auto;
    margin-right: auto;
  }  

  /*.page-template-page-favoritos .content-section .container-fluid {
    width: 100%;
  }*/
  
  

  .page-template-page-favoritos .video-thumb .video-content .name {
    margin-top: 14px;
    text-align: left;
  }

  .page-template-page-favoritos .no-cover {
    height: 282px;
    padding: 49px;
    padding-bottom: 90px;
    padding-top: 90px;    
  }

  .video-thumb .video-image img {
    min-height: 219px;
  }

  @media only screen and (max-width: 767px), only screen and (max-device-width: 767px) {
    .video-thumb .video-image img {
      min-height: 224px;
    }  
  }

  /* .page-template-page-favoritos .grid-item {
    display: inline-flex
  } */

  /* .page-template-page-favoritos .wpb_wrapper .isotope-pager {
    margin: 0;
    width: 100%;
  } */

  /* .page-template-page-favoritos .wpb_wrapper .isotope-pager .pager {
    transform: translateX(0px);
    height: 42px;
    line-height: 42px;
    padding: 0 14px;
    font-size: 13px;
  } */

  .page-template-page-favoritos .page-header {
    background: url('<?php echo get_template_directory_uri() . '/images/banner-favoritos.png'; ?>')
  }

  .page-template-page-favoritos .page-header .container {
    position: relative;
    z-index: 1;
    color: #fff;
    padding-top: 40px;
    max-width: 1110px;
  }
</style>

<script>
    (function ($) {

        $(document).ready(function () {
          "use strict";

          var itemSelector = '.grid-item'; 

          var $container = $('.grid').isotope({
              layoutMode: 'fitRows',
              itemSelector: itemSelector,
              fitRows: {
                gutter: 20
              }
          })

          var responsiveIsotope = [
              [480, 12],
              [720, 12]
          ];

          var itemsPerPageDefault = 12;
          var itemsPerPage = defineItemsPerPage();
          var currentNumberPages = 1;
          var currentPage = 1;
          var currentFilter = '*';
          var filterAtribute = 'data-filter';
          var pageAtribute = 'data-page';
          var pagerClass = 'isotope-pager';

          var itemsLength = $container.children(itemSelector).length;
          var pages = Math.ceil(itemsLength / itemsPerPage);

          function changeFilter(selector) {
              $container.isotope({
              filter: selector
              });
          }

          function goToPage(n) {

              currentPage = n;
              let current = parseInt(n);
              var itemsLength = $container.children(itemSelector).length;
              var pages = Math.ceil(itemsLength / itemsPerPage);
              let max = pages;

              var selector = itemSelector;
              selector += ( currentFilter != '*' ) ? '['+filterAtribute+'="'+currentFilter+'"]' : '';
              selector += '['+pageAtribute+'="'+currentPage+'"]';

              $('html, body').animate({
                  scrollTop: $('.movies_section').offset().top
              }, 800);

              changeFilter(selector);

              var currentClass = '';
              var $isotopePager = ( $('.'+pagerClass).length == 0 ) ? $('<div class="'+pagerClass+'"></div>') : $('.'+pagerClass);
              $isotopePager.html('');

              var $isotopePager = ( $('.'+pagerClass).length == 0 ) ? $('<div class="'+pagerClass+'"></div>') : $('.'+pagerClass);
              $isotopePager.html('');

              console.log('current', current)
              var $previousButton = $('<a href="javascript:void(0);" class="pager previous" data-page="'+((current-1) === 0 ? pages : current - 1)+'">« <span>Anterior</span></a>');
              $previousButton.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
              });
              var $nextButton = $('<a href="javascript:void(0);" class="pager next" data-page="'+((current+1) > pages ? 1 : current+1)+'"><span>Próximo</span> »</a>');
              $nextButton.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
              });

              $isotopePager.append($previousButton);

              

              if (!current || !max) return null

              let prev = current === 1 ? null : current - 1,
                  next = current === max ? null : current + 1,
                  items = [1]

                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(1)+'"></a>');
                  $pager.html(1);	
                  $pager.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
                  });
                  $pager.appendTo($isotopePager);

              if (current === 1 && max === 1) return null
              if (current > 4){
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                  $pager.html('...');	
                  $pager.appendTo($isotopePager);
                  items.push('…')
              }

              let r = 2, r1 = current - r, r2 = current + r

              for (let i = r1 > 2 ? r1 : 2; i <= Math.min(max, r2); i++){
                  items.push(i)
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(i)+'"></a>');
                  $pager.html(i);	
                  $pager.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
                  });
                  $pager.appendTo($isotopePager);
              }

              if (r2 + 1 < max){
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                  $pager.html('...');	
                  $pager.appendTo($isotopePager);
                  items.push('…')
              }
              if (r2 < max){
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(max)+'"></a>');
                  $pager.html(max);	
                  $pager.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
                  });
                  $pager.appendTo($isotopePager);
                  items.push(max)
              }

              $isotopePager.append($nextButton);
              $container.after($isotopePager);

              $('.isotope-pager .pager[data-page="'+current+'"]').addClass('current');
          }

          function defineItemsPerPage() {
              var pages = itemsPerPageDefault;

              for( var i = 0; i < responsiveIsotope.length; i++ ) {
              if( $(window).width() <= responsiveIsotope[i][0] ) {
                  pages = responsiveIsotope[i][1];
                  break;
              }
              }
              return pages;
          }

          function setPagination() {
              var SettingsPagesOnItems = function(){
              var itemsLength = $container.children(itemSelector).length;
              var pages = Math.ceil(itemsLength / itemsPerPage);
              var item = 1;
              var page = 1;
              var selector = itemSelector;
                  selector += ( currentFilter != '*' ) ? '['+filterAtribute+'="'+currentFilter+'"]' : '';
              
              $container.children(selector).each(function(){
                  if( item > itemsPerPage ) {
                  page++;
                  item = 1;
                  }
                  $(this).attr(pageAtribute, page);
                  item++;
              });
              currentNumberPages = page;
              }();

              var CreatePagers = function() {
              var currentClass = '';
              let current = 1;

              var $isotopePager = ( $('.'+pagerClass).length == 0 ) ? $('<div class="'+pagerClass+'"></div>') : $('.'+pagerClass);
              $isotopePager.html('');

              var $previousButton = $('<a href="javascript:void(0);" class="pager previous" data-page="'+(current-1)+'">« <span>Anterior</span></a>');
              $previousButton.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
              });
              var $nextButton = $('<a href="javascript:void(0);" class="pager next" data-page="'+(current+1)+'"><span>Próximo</span> »</a>');
              $nextButton.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  console.log('pegou evento', page)
                  goToPage(page);
              });

              $isotopePager.append($previousButton);

              var itemsLength = $container.children(itemSelector).length;
              var pages = Math.ceil(itemsLength / itemsPerPage);
              let max = pages;
              if (!current || !max) return null

              let prev = current === 1 ? null : current - 1,
                  next = current === max ? null : current + 1,
                  items = [1]

                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(1)+'"></a>');
                  $pager.html(1);	
                  $pager.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
                  });
                  $pager.appendTo($isotopePager);

              if (current === 1 && max === 1) return null
              if (current > 4){
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                  $pager.html('...');	
                  $pager.appendTo($isotopePager);
                  items.push('…')
              }

              let r = 2, r1 = current - r, r2 = current + r

              for (let i = r1 > 2 ? r1 : 2; i <= Math.min(max, r2); i++){
                  items.push(i)
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(i)+'"></a>');
                  $pager.html(i);	
                  $pager.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
                  });
                  $pager.appendTo($isotopePager);
              }

              if (r2 + 1 < max){
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                  $pager.html('...');	
                  $pager.appendTo($isotopePager);
                  items.push('…')
              }
              if (r2 < max){
                  var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(max)+'"></a>');
                  $pager.html(max);	
                  $pager.click(function(){
                  var page = $(this).eq(0).attr(pageAtribute);
                  goToPage(page);
                  });
                  $pager.appendTo($isotopePager);
                  items.push(max)
              }
              
              $isotopePager.append($nextButton);
              $container.after($isotopePager);

              $('.isotope-pager .pager[data-page="'+current+'"]').addClass('current');
              }();
          }

          setPagination();
          goToPage(1);

          $('.isotope-pager .pager:first-of-type').addClass('current');
          $('body').on('click', '.isotope-pager .pager', function(){
              $('.isotope-pager .pager').removeClass('current');
              $(this).addClass('current');
          })

          //Adicionando Event de Click para as categorias
          $('.filters a').click(function(){
              var filter = $(this).attr(filterAtribute);
              currentFilter = filter;
              setPagination();
              //goToPage(1);
          });

          //Evento Responsivo
          $(window).resize(function(){
              itemsPerPage = defineItemsPerPage();
              setPagination();
              goToPage(1);
          });
        })

        $(window).load(function(){
        // updateVisiblePages();
        });

        
        
    })(jQuery);
</script>

<?php
get_footer();
?>