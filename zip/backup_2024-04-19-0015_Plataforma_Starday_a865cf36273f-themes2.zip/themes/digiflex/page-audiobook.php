<?php
/**
 * Template Name: Audiobook
 *
 */

get_header();

digiflex_render_page_header( 'page' );


?>
<main>
  <section class="content-section">
    <div class="container">
      <div class="row">
        <?php
        $the_query = new WP_Query( array( 'posts_per_page' => 10,
          'post_type' => 'audiobook',
          'paged' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 ) );

        while ( $the_query->have_posts() ): $the_query->the_post();

        $thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );

        $title = get_the_title();

        ?>
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
          <div class="video-thumb">
            <a href="<?php the_permalink(); ?>" class="video-image"> <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>">
             
              <?php if( get_field('audiobook_quality') ): ?>
              <div class="hd">
                <?php the_field('audiobook_quality') ?>
              </div>
              <!-- end hd -->
              <?php endif; ?>
            </a>
            <div class="video-content">
				 <?php if( get_field('audiobook_age_range') ): ?>
              <div class="age">
                <?php the_field('audiobook_age_range') ?>
              </div>
              <!-- end age -->
              <?php endif; ?>
              <?php if( get_field('audiobook_release_year') ): ?>
              <small class="year">
              <?php the_field('audiobook_release_year') ?>
              </small>
              <?php endif; ?>
              <?php

              $terms = get_the_terms( $post->ID, 'categories' );
              if ( $terms && !is_wp_error( $terms ) ):
                ?>
              <ul class="tags">
                <?php foreach ( $terms as $term )  ?>
                <li><?php echo esc_html__( $term->name ); ?></li>
                <?php  ?>
              </ul>
              <?php endif;?>
             
              <h3 class="name"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" data-text="<?php echo wp_kses_post( $title ); ?>"> <?php echo wp_kses_post( $title ); ?> </a></h3>
            </div>
            <!-- end video-content --> 
          </div>
          <!-- end video-thumb --> 
        </div>
        <!-- end col-2 -->
        
        <?php
        endwhile;
        ?>
        <div class="col-12">
          <div class="pagination">
            <?php
            $big = 999999999; // need an unlikely integer
            echo paginate_links( array(
              'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
              'format' => '?paged=%#%',
              'current' => max( 1, get_query_var( 'paged' ) ),
              'total' => $the_query->max_num_pages
            ) );

            wp_reset_postdata();
            ?>
          </div>
          <!-- end pagination --> 
        </div>
        <!-- end col-12 --> 
      </div>
      <!-- end row --> 
    </div>
    <!-- end container --> 
  </section>
  <!-- end content-section --> 
</main>
<?php
get_footer();
