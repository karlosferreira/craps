<?php
get_header();

$thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );
$title = get_the_title();
$categories = wp_list_categories();

?>
<header class="page-header single">
  <div class="poster-bg" data-background="<?php echo esc_url( $thumbnail_image ); ?>"></div>
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="video-player">
          <?php the_field('embed_audiobook') ?>
          <!-- end video-player --> 
        </div>
        <!-- end col-12 --> 
      </div>
      <!-- end row --> 
    </div>
    <!-- end container --> 
  </div>
</header>
<main>
  <section class="content-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-9">
          <div class="audiobook-info-box">
            <h2 class="name"> <?php echo wp_kses_post( $title ); ?></h2>
            <div class="features">
              <?php if( get_field('audiobook_release_year') ): ?>
              <div class="year">
                <?php the_field('audiobook_release_year') ?>
              </div>
              <!-- end year -->
              <?php endif; ?>
              <?php if( get_field('audiobook_quality') ): ?>
              <div class="quality">
                <?php the_field('audiobook_quality') ?>
              </div>
              <!-- end quality -->
              <?php endif; ?>
              <?php if( get_field('audiobook_range') ): ?>
              <div class="range">
                <?php the_field('audiobook_range') ?>
              </div>
              <!-- end range -->
              <?php endif; ?>
              <?php if( get_field('audiobook_age_range') ): ?>
              <?php the_field('audiobook_age_range') ?>
              -
              <?php endif; ?>
              <?php if( get_field('audiobook_language') ): ?>
              <div class="audiobook-language">
                <?php the_field('audiobook_language') ?>
              </div>
              <?php endif; ?>
              <?php

              $terms = get_the_terms( $post->ID, 'categories' );
              if ( $terms && !is_wp_error( $terms ) ):
                ?>
              <div class="category">
                <?php foreach ( $terms as $term ) { ?>
                <?php echo esc_html__( $term->name ); ?>
                <?php } ?>
              </div>
              <?php endif;?>
            </div>
            <!-- end features -->
            <?php if( get_field('audiobook_short_description') ): ?>
            <p class="description">
              <?php the_field('audiobook_short_description') ?>
            </p>
            <?php endif; ?>
            <ul class="info">
              <?php if( get_field('audiobook_written_by') ): ?>
              <li>
                <h6><?php echo esc_html__( 'Written By', 'digiflex' );?></h6>
                : <span>
                <?php the_field('audiobook_written_by') ?>
                </span> </li>
              <?php endif; ?>
              <?php if( get_field('audiobook_narrated_by') ): ?>
              <li>
                <h6><?php echo esc_html__( 'Narrated By', 'digiflex' );?></h6>
                : <span>
                <?php the_field('audiobook_narrated_by') ?>
                </span> </li>
              <?php endif; ?>
              <?php if( get_field('audiobook_published_by') ): ?>
              <li>
                <h6><?php echo esc_html__( 'Published By', 'digiflex' );?></h6>
                : <span>
                <?php the_field('audiobook_published_by') ?>
                </span> </li>
              <?php endif; ?>
              <?php

              if ( have_rows( 'extra_fields_audiobook' ) ):


                ?>
              <?php while ( have_rows('extra_fields_audiobook') ) : the_row(); ?>
              <li>
                <h6>
                  <?php the_sub_field('title_audiobook'); ?>
                </h6>
                : <span>
                <?php the_sub_field('content_audiobook'); ?>
                </span> </li>
              <?php  endwhile; ?>
				
				<?php
				else :
				?>
				
              <?php  endif;?>
            </ul>
            <!-- end info --> 
          </div>
          <!-- end movie-info-box --> 
        </div>
        <!-- end col-9 -->
        <div class="col-lg-3">
          <div class="movie-side-box">
            <figure><img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>"></figure>
          </div>
          <!-- end movie-side-box --> 
        </div>
        <!-- end col-3 -->
        <div class="col-12">
          <div class="info-bottom">
            <div class="add-btn"> <?php echo do_shortcode('[favorite_button]');?> </div>
            <?php echo do_shortcode('[posts_like_dislike]');?> </div>
        </div>
        <!-- end col-12 --> 
      </div>
      <!-- end row --> 
    </div>
    <!-- end container --> 
  </section>
  <!-- end content-section -->
  <section class="content-section" data-background="#111111">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="section-title light">
            <h6><?php echo esc_html__( 'FIND ANYWHERE ELSE', 'digiflex' );?></h6>
            <h2><?php echo esc_html__( 'Related Audiobooks', 'digiflex' );?></h2>
          </div>
          <!-- end section-title --> 
        </div>
        <!-- end col-12 -->
        <?php

        $post_id = get_the_ID();
        $args = array(
          'post_type' => 'audiobook',
          'post__not_in' => array( $post_id ),
          'posts_per_page' => '6',
          'meta_query' => array(
            array(
              'taxonomy' => $term,
              'field' => 'slug',
            ),
          ),

        );
        $movie = new WP_Query( $args );


        if ( $movie->have_posts() ):
          while ( $movie->have_posts() ):
            $movie->the_post();

        $thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );

        $title = get_the_title();


        ?>
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
          <div class="video-thumb light">
            <a href="<?php the_permalink(); ?>" class="video-image"> <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>">
              <?php if( get_field('audiobook_quality') ): ?>
              <div class="hd">
                <?php the_field('audiobook_quality') ?>
              </div>
              <!-- end hd -->
              <?php endif; ?>
            </a>
            <div class="video-content">
				
              <?php if( get_field('audiobook_age_range') ): ?>
              <div class="age">
                <?php the_field('audiobook_age_range') ?>
              </div>
              <!-- end age -->
              <?php if( get_field('audiobook_release_year') ): ?>
              <small class="year">
              <?php the_field('audiobook_release_year') ?>
              </small>
              <?php endif; ?>
              <?php

              $terms = get_the_terms( $post->ID, 'categories' );
              if ( $terms && !is_wp_error( $terms ) ):
                ?>
              <ul class="tags">
                <?php foreach ( $terms as $term )  ?>
                <li><?php echo esc_html__( $term->name ); ?></li>
                <?php  ?>
              </ul>
              <?php endif;?>
              <?php endif; ?>
              <h3 class="name"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" data-text="<?php echo wp_kses_post( $title ); ?>"> <?php echo wp_kses_post( $title ); ?> </a></h3>
            </div>
            <!-- end video-content --> 
          </div>
          <!-- end video-thumb --> 
        </div>
        <!-- end col-2 -->
        <?php endwhile; ?>
        <?php endif; ?>
      </div>
      <!-- end row --> 
    </div>
    <!-- end container --> 
  </section>
  <!-- end content-section -->
</main>
<?php get_footer(); ?>
