<?php

/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package digiflex
 */
get_header();

?>
<?php
digiflex_render_page_header('search');
?>
<main>
  <section class="content-section">
    <div class="container-fluid">
      <div id="videos" class="vc_row wpb_row vc_row-fluid movies_section">
        <div class="wpb_column vc_column_container vc_col-sm-12">
          <div class="vc_column-inner">
            <div class="wpb_wrapper">
              <div class="row">
                <div class="grid">
                  <?php

                  $search_query = get_search_query();

                  $tv_show_query = new WP_Query(array(
                    'post_type'      => 'tv_show',
                    'posts_per_page' => -1,
                    's'              => $search_query,
                  ));

                  if ($tv_show_query->have_posts()) :
                    while ($tv_show_query->have_posts()) : $tv_show_query->the_post();

                    $logo = (digiflex_get_option('logo')) ? digiflex_get_option('logo') : get_template_directory_uri() . '/images/logo@2x.png';

                    $thumb_id = get_post_thumbnail_id($post_id);
                    $thumb_url = wp_get_attachment_image_src($thumb_id, 'full')[0];
  
                    $image_valid = false;
                    if ($thumb_url) {
                      $response = wp_remote_head($thumb_url);
                      if (!is_wp_error($response) && $response['response']['code'] === 200) {
                        $image_valid = true;
                      }
                    }
                    
                      $imdb_score = get_field('tv_show_imdb_score', $post->ID); // Recupera o valor do campo 'tv_show_imdb_score'
                      $select_quality = get_field('tv_show_select_quality', $post->ID); // Recupera o valor do campo 'tv_show_select_quality'
                      $producer = get_field('tv_show_producer', $post->ID); // Recupera o valor do campo 'tv_show_producer'
                      $release_year = get_field('tv_show_release_year', $post->ID); // Recupera o valor do campo 'tv_show_release_year'
                  ?>

                      <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 grid-item grid-item-<?php echo $post->ID; ?>">
                        <div class="video-thumb  light ">
                          <?php echo do_shortcode("[starday_favorite_button post_id={$post->ID}]"); ?>
                          <a href="<?php the_permalink(); ?>" class="video-image">
                            <?php if ($image_valid) : ?>
                              <img decoding="async" src="<?php echo esc_url($thumb_url); ?>" alt="<?php echo $post->post_title; ?>">
                            <?php else : ?>
                              <img decoding="async" class="no-cover" src="<?php echo esc_url($logo); ?>" alt="<?php echo $post->post_title; ?>">
                            <?php endif; ?>
                            <?php if ($imdb_score) : ?>
                              <div class="circle-rate">
                                <svg class="circle-chart" viewBox="0 0 30 30" width="100" height="100" xmlns="http://www.w3.org/2000/svg">
                                  <circle class="circle-chart__background" stroke="#2f3439" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                  <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php echo ($imdb_score * 10 - 8); ?>,100" cx="15" cy="15" r="14"></circle>
                                </svg>
                                <b>
                                  <?php echo $imdb_score; ?>
                                </b>
                              </div>
                              <!-- end circle-rate -->
                            <?php endif; ?>
                            <?php if ($select_quality) : ?>
                              <div class="hd">
                                <?php echo $select_quality; ?>
                              </div>
                              <!-- end hd -->
                            <?php endif; ?>
                          </a>
                          <div class="video-content">
                            <?php if ($producer) : ?>
                              <div class="age">
                                <?php echo $producer; ?>
                              </div>
                              <!-- end age -->
                            <?php endif; ?>

                            <?php if ($release_year) : ?>
                              <small class="year">
                                <?php echo $release_year; ?>
                              </small>
                            <?php endif; ?>
                            <h3 class="name cgdigital">
                              <a href="<?php the_permalink($post->ID); ?>" title="<?php echo $post->post_title; ?>" data-text="<?php echo $post->post_title; ?>">
                                <?php echo $post->post_title; ?>
                              </a>
                            </h3>
                          </div>
                        </div>
                      </div>

                    <?php
                    endwhile;

                    wp_reset_postdata();
                  else :
                    ?>
                    <p>Nenhum resultado encontrado.</p>
                  <?php
                  endif;
                  ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row justify-content-center">

      </div>
    </div>
  </section>
</main>

<style>
  .search .content-section {
    background: #2d2d2d;
    padding: 70px 0;
  }

  .search main {
    margin-top: 314px !important;
  }

  .search .tv-show-entry {
    margin-bottom: 30px;
  }

  .search .tv-show-entry img {
    max-width: 100%;
    height: auto;
  }

  .search .video-thumb .video-content .name a {
    color: #fff !important;
    line-height: 21px;
  }

  .search .video-thumb .video-content .name.cgdigital a {
    font-size: 12px;
    margin-top: 0px;
  }

  .search #videos .grid {
    text-align: center;
  }
  
  .search #videos {
    max-width: 1350px;
    margin-left: auto;
    margin-right: auto;
  }  

  .search .content-section .container {
    max-width: 1350px;
  }

  .search .video-thumb .video-content .name {
    margin-top: 7px;
    text-align: left;
  }

  .search .no-cover {
    height: 260px;
    padding: 49px;
    padding-bottom: 90px;
    padding-top: 90px;
  }

  .search .video-thumb .video-image img {
    min-height: 260px;
    max-height: 260px;
  }

  .search .grid-item {
    display: inline-flex;
    padding-left: 14px;
    padding-right: 14px;    
  }

  .search .wpb_wrapper .isotope-pager {
    margin: 0;
    width: 100%;
  }

  .search .wpb_wrapper .isotope-pager .pager {
    transform: translateX(0px);
    height: 42px;
    line-height: 42px;
    padding: 0 14px;
    font-size: 13px;
  }

  .search .page-header {
    background: url('<?php echo get_template_directory_uri() . '/images/banner-resultados.png'; ?>')
  }

  .search .page-header .container {
    position: relative;
    z-index: 1;
    color: #fff;
    padding-top: 40px;
    max-width: 1110px;
  }
</style>

<?php
get_footer();
?>