<?php
$footer_bg_color = digiflex_get_option( 'footer_bg_color' ) ? digiflex_get_option( 'footer_bg_color' ) : '#111111';
$footer_bg_image = digiflex_get_option( 'footer_bg_image' ) ? digiflex_get_option( 'footer_bg_image' ) : '';
$footer_style = 'background-color: ' . $footer_bg_color;
$copyright = digiflex_get_option( 'footer_copyright_text' );
$site_credit = digiflex_get_option( 'footer_site_credit' );


if ( !$copyright ) {
  $copyright = esc_html__( 'Digiflex | Online Movie Streaming', 'digiflex' );
}

if ( !$site_credit ) {
  $site_credit = esc_html__( 'Site created by Themezinho', 'digiflex' );
}


$footer_bg = ( $footer_bg_image != '' ) ? 'data-background="' . esc_url( $footer_bg_image ) . '"': '';
?>
<footer class="footer" <?php echo esc_attr( $footer_bg ); ?> style="<?php echo esc_attr( $footer_style ); ?>">
  <div class="container">
    <div class="row">
      <?php if( is_active_sidebar( 'footer-widget-1' ) || is_active_sidebar( 'footer-widget-2' ) || is_active_sidebar( 'footer-widget-3' ) || is_active_sidebar( 'footer-widget-4' ) ) { ?>
      <?php if( is_active_sidebar( 'footer-widget-1' ) ) : ?>
      <div class="col-lg-4">
        <?php dynamic_sidebar( 'footer-widget-1' ); ?>
      </div>
      <?php endif; ?>
      <?php if( is_active_sidebar( 'footer-widget-2' ) ) : ?>
      <div class="col-lg-2 offset-lg-1 col-md-4">
        <?php dynamic_sidebar( 'footer-widget-2' ); ?>
      </div>
      <?php endif; ?>
      <?php if( is_active_sidebar( 'footer-widget-3' ) ) : ?>
      <div class="col-lg-2 col-md-4">
        <?php dynamic_sidebar( 'footer-widget-3' ); ?>
      </div>
      <?php endif; ?>
		<?php if( is_active_sidebar( 'footer-widget-4' ) ) : ?>
      <div class="col-lg-2 col-md-4">
        <?php dynamic_sidebar( 'footer-widget-4' ); ?>
      </div>
      <?php endif; ?>
      <?php } ?>
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
	 <?php if( $copyright ) { ?>
	<div class="bottom-bar">
	<div class="container">
         <span>&copy; <?php echo date("Y"); ?> <?php echo esc_html__( $copyright ); ?></span> 
			<span> <?php echo esc_html__( $site_credit ); ?> </span> 
		</div>
	<!-- end container --></div>
        <!-- end footer-bottom -->
        <?php } ?>
</footer>
<?php wp_footer(); ?>


</body>
</html>