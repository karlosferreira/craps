<?php
get_header();


$thumbnail_image = get_the_post_thumbnail_url( get_the_ID() );
$title = get_the_title();
$title_image = get_field('title_image_black');
$description = get_field('description');
$rating_title = get_field('rating_title_black', 'option');
$select_quality_image = get_field('select_quality_image');

$args = array(
  'post_type' => 'e-book',
  'posts_per_page' => '990',
  'orderby' => 'date',
  'order' => 'ASC',
);

?>
<header class="page-header page-header-app single">
    <div class="pattern-bg"></div>
    <div class="poster-bg" data-background="<?php the_field('e_book_slider_image') ?>"></div>
    <div class="container">
        <div class="row">
            <?php if(get_field('embed_e_book_player')){ ?>
                <div class="col-12">
                    <div class="video-player">
                        <?php the_field('embed_e_book_player') ?>
                    </div>
                </div>
            <?php } else { ?>
                <div class="col-10 offset-1 col-md-4 offset-md-4">
                    <div class="movie-side-box">
                        <figure>
                            <img src="<?php echo esc_url( $thumbnail_image ); ?>"
                                alt="<?php the_title_attribute(); ?>">
                        </figure>
                    </div>
                </div>
            <?php } ?>
            <!-- end col-12 -->
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <style>
    .button-container {
        display: flex;
        justify-content: start;
    }

    .button-container2 {
        padding-top: 30px;
        /* Adjust the value as per your preference */
        margin-left: -38px;
    }

    .button {
        border: 2px solid;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        padding: 12px 24px;
        text-align: center;
        text-decoration: none;
        transition: background-color 0.3s, color 0.3s;
    }

    .button.black {
        color: black;
        border-color: black;
        margin-right: 20px;
        /* Create a 20px gap between buttons */
        text-decoration: none;
        font-size: 16px;
        padding: 12px 24px;
    }

    .button.black:hover {
        background-color: black;
        color: white;
        text-decoration: none;
    }

    .button.red {
        color: white;
        background-color: red;
        text-decoration: none;
        font-weight: bold;
    }

    .button.red:hover {
        background-color: darkred;
        text-decoration: none;
        font-weight: bold;
    }

    .info-bottom{
        padding-top: 0;
    }

    .info-bottom .pld-common-wrap > a.pld-like-dislike-trigger i{
        line-height: 66px;
        color: #888888;
    }
    </style>
</header>
<main>
    <section class="content-section">
      <div class="container">
          <div class="row">
            <div class="col-12">
                <div>
                    <?php echo do_shortcode(get_field('embed_e_book')) ?>
                </div>
                <!-- end col-12 -->
            </div>

            <div class="col-12">
                <?php //comments_template( '/short-comments.php' ); ?> 
                <?php echo do_shortcode('[wpdiscuz_comments]') ?>
            </div>

            <!-- <div class="col-12">
                <div class="button-container2">
                    <div class="info-bottom">
                        <?php echo do_shortcode('[posts_like_dislike]');?>
                    </div>
                </div>
            </div> -->
          </div>
        </div>
        <!-- end container -->
    </section>
    <!-- end content-section -->
    <section class="content-section" data-background="#111111">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title light">
                        <h2>E-books Relacionados
                        </h2>
                    </div>
                    <!-- end section-title -->
                </div>
                <!-- end col-12 -->
                <div class="col-12">
                    <div class="carousel-e-books">
                        <div class="swiper-wrapper">
                            <?php
                              $movie = new WP_Query( $args );
                              if ( $movie->have_posts() ):
                                while ( $movie->have_posts() ):
                                  $movie->the_post();
                            ?>
                            <div class="swiper-slide">
                                <div class="video-thumb <?php if( $display_light == "light" ) { ?> light <?php } ?>">
                                    <a href="<?php the_permalink(); ?>" class="video-image"> <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>">
                                        <div class="description">
                                            <h3 class="name"><?php echo wp_kses_post( $title ); ?></h3>

                                            <?php
                                            
                                            $ebook_description = get_field( 'e_book_short_description' );

                                            if( !empty( $ebook_description ) ):
                                            $trimmed_text = wp_html_excerpt( $ebook_description, 450 );
                                            $trimmed_text_mobile = wp_html_excerpt( $ebook_description, 800 );
                                            $last_space = strrpos( $trimmed_text, ' ' );
                                            $modified_trimmed_text = substr( $trimmed_text, 0, $last_space );
                                            echo '<div class="d-none d-md-block">' . $modified_trimmed_text . '...' . '</div>';
                                            echo '<div class="d-md-none">' . $trimmed_text_mobile . '...' . '</div>';
                                            endif; 

                                            ?>


                                            <?php //the_field('e_book_short_description') ?>
                                        </div>
                                    </a>

                                    <div class="video-content">
                                        <?php if( get_field('audiobook_age_range') ): ?>
                                            <div class="age">
                                            <?php the_field('audiobook_age_range') ?>
                                            </div>
                                        <!-- end age -->
                                        <?php endif; ?>

                                        <?php if( get_field('audiobook_release_year') ): ?>
                                            <small class="year">
                                            <?php the_field('audiobook_release_year') ?>
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    <!-- end video-content --> 
                                </div>
                                <!-- end episode-box -->
                            </div>
                            <!-- end swiper-slide -->
                            <?php endwhile; ?>
                            <?php endif;  ?>
                        </div>
                        <!-- end swiper-wrapper -->
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                    <!-- end carousel-tv-shows  -->
                </div>
                <!-- end col-12 -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </section>
    <!-- end content-section -->
</main>
<?php get_footer(); ?>