<?php

/**
 * Template Name: homepage
 *
 */

get_header();

?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
  #series {
    padding: 40px 0;
  }
</style>

<?php get_template_part('template-parts/section', 'webdoor'); ?>

<main>
  <?php get_template_part('template-parts/section', 'series'); ?>
  <?php
  if (have_posts()) :
    while (have_posts()) :
      the_post();
      the_content();
    endwhile;
  endif;
  ?>
</main>
<?php get_footer(); ?>

<script>
  (function($) {
    slideSeries.clone().appendTo(wrapper);

    $(document).ready(function() {
      "use strict";

      <?php if (have_rows('banner_videos')) :
        while (have_rows('banner_videos')) : the_row();  ?>

          <?php $banner_videos_desktop = get_sub_field('imagem'); ?>
          <?php $banner_videos_mobile = get_sub_field('imagem_mobile'); ?>

          var bannerVideos = $(window).width() <= 767 ? '<?php echo esc_url($banner_videos_mobile['url']); ?>' : '<?php echo esc_url($banner_videos_desktop['url']); ?>'
          $('.wpb-content-wrapper').css('background-image', 'url(' + bannerVideos + ')');

      <?php endwhile;
      endif; ?>
    });
  })(jQuery);
</script>

<script>
  (() => {
    const slideSeries = document.querySelectorAll('.section-series');
    const wrapper = document.querySelector('.wpb-content-wrapper');

    const bgImg = '<?php 
      $bgImg = get_template_directory_uri() . '/images/bg-degrade.png';
      echo esc_url($bgImg);
    ?>';

    slideSeries.forEach(slide => {
      wrapper.insertBefore(slide, wrapper.firstChild);
    });

    wrapper.style.backgroundImage = 'url(' + bgImg + ')';
    wrapper.style.backgroundPositionY = '10px';
  })();
</script>