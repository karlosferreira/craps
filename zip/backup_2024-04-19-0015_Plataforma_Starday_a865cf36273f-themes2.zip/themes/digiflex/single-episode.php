<?php
get_header();
?>
<header class="page-header single">
  <div class="poster-bg" data-background="<?php the_field( 'episode_thumbnail'); ?>"></div>
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="video-player">
          <?php the_field('embed_video') ?>
          <ul class="episode-navigation">
            <li>
              <?php previous_post_link('%link', 'Prev Episode', $in_same_term = true, $excluded_terms = '', $taxonomy = 'episode_tag'); ?>
            </li>
            <li>
              <?php next_post_link('%link', 'Next Episode', $in_same_term = true, $excluded_terms = '', $taxonomy = 'episode_tag'); ?>
            </li>
          </ul>
        </div>
        <!-- end video-player --> 
      </div>
      <!-- end col-12 --> 
    </div>
    <!-- end row --> 
  </div>
  <!-- end container --> 
</header>
<main> </main>
<?php get_footer(); ?>
