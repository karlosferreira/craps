<style>
.swiper-slide .img-fluid {
   max-width: 80%;
}   
</style>
<section class="content-section section-series no-spacing">
   <div class="container">
      <div id="series" class="vc_row wpb_row vc_row-fluid vc_custom_1699020235590">
         <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner">
               <div class="wpb_wrapper">
                  <div class="section-title text-center" style="color:#1e1e1e;">
                     <h6>SERIES EM DESTAQUE</h6>
                  </div>
                  <div class="row">
                     <div class="col-12">
                        <div class="tv-shows-home swiper-container-horizontal">
                           <div class="swiper-wrapper">

                              <?php
                              $series_args = array(
                                 'post_type' => 'series',
                                 'posts_per_page' => 10,
                                 'orderby' => 'date',
                                 'order' => 'DESC',
                                 'meta_query' => array(
                                    array(
                                       'key' => 'custom_new_playlist',
                                       'compare' => 'EXISTS',
                                    )
                                 )
                              );

                              $series_query = new WP_Query($series_args);

                              $series_list = $series_query->posts;

                              foreach ($series_list as $key => $serie) {
                                 $featured_image_url = get_the_post_thumbnail_url($serie->ID, 'full');
                                 $permalink = get_permalink($serie->ID);

                                 $episodes_args = array(
                                    'post_type' => 'tv_show',
                                    'meta_query' => array(
                                       array(
                                          'key' => 'series_tv_show_rel',
                                          'value' => '"' . $serie->ID . '"',
                                          'compare' => 'LIKE'
                                       )
                                    )
                                 );
                                 
                                 $episodes_query = new WP_Query($episodes_args);

                                 if ($episodes_query) {
                                    ?>
                                       <div class="swiper-slide" data-swiper-slide-index="0" style="width: 356.667px; margin-right: 50px;">
                                          <a href="<?php echo esc_url($permalink); ?>">
                                             <img decoding="async" src="<?php echo esc_url($featured_image_url); ?>" class="img-fluid" alt="<?php the_title_attribute(); ?>">
                                          </a>
                                       </div>                                    
                                    <?php
                                 }
                                 
                                 wp_reset_postdata();


                              }

                              wp_reset_postdata();
                              
                              ?>
                           </div>
                        </div>
                        <div class="swiper-pagination"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>