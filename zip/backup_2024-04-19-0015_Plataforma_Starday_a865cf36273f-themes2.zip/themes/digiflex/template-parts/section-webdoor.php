<?php

    $args = array(
        'post_type' => 'tv_show',
        'post_per_page' => -1,
        'meta_key' => 'display_on_slider',
        'meta_value' => 'yes'
    );

    $movie = new WP_Query($args);

?>

<header class="slider">
    <?php if ($movie->have_posts()) : ?>
        <div class="owl-carousel owl-theme owl-carousel-home-banner">
            <?php while ($movie->have_posts()) :
                $movie->the_post();

                $thumbnail_image = get_the_post_thumbnail_url(get_the_ID());
                $title = get_the_title();
                $title_image = get_field('title_image');
                $rating_title = get_field('rating_title', 'option');
                $select_quality_image = get_field('select_quality_image');
                $video_background = get_field('video_background');
                $video_background_mobile = get_field('video_background_mobile');
                $post_terms = get_the_terms(get_the_ID(), 'tv_show_tag');
            ?>
                <?php if ($video_background) { ?>
                    <div class="item">
                        <video autoplay="" class="d-none d-md-block" loop="" muted="">
                            <source src="<?php echo $video_background['url']; ?>" type="video/mp4" />
                        </video>

                        <video autoplay="" class="d-md-none" loop="" muted="">
                            <source src="<?php echo $video_background_mobile['url']; ?>" type="video/mp4" />
                        </video>
                        <a href="<?php the_permalink(); ?>">
                            <div class="item-inner d-md-none">
                                <div class="container">
                                    <?php if (get_field('tv_show_slider_tagline')) : ?>
                                        <h6 class="tagline"> <?php the_field('tv_show_slider_tagline') ?></h6>
                                    <?php endif; ?>
                                    <h2 class="name">
                                        <?php if (get_field('title_image')) { ?>
                                            <img src="<?php echo esc_url($title_image['url']); ?>" alt="<?php echo esc_attr($title_image['alt']); ?>" class="img-fluid">
                                        <?php } else {
                                            echo esc_html__($post_terms[0]->name);
                                        } ?>
                                    </h2>

                                    <h3>
                                        <div class="subdescription">
                                            <?php $description = get_field('description'); ?>
                                            <?php echo $description; ?>
                                        </div>
                                    </h3>

                                    <div class="features">
                                        <div class="d-flex align-items-center imdb_score">
                                            <?php if (get_field('imdb_score')) : ?>
                                                <div class="imdb_title d-none d-md-block">
                                                    <p class="mb-0 mr-2"><?php the_field('imdb_title', 'option') ?></p>
                                                </div>
                                                <div class="rate">
                                                    <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                                        <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php $num = get_field('imdb_score');
                                                                                                                                                    echo esc_html__($num * '10' - '8'); ?>,100" cx="15" cy="15" r="14"></circle>
                                                    </svg>
                                                    <b>
                                                        <?php the_field('imdb_score') ?>
                                                    </b>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (get_field('tv_show_range')) : ?>
                                                <div class="range">
                                                    <?php the_field('tv_show_range') ?>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (get_field('tv_show_subtitle')) : ?>
                                                <div class="cc">Legendado</div>
                                            <?php endif; ?>

                                            <?php if (get_field('tv_show_dubbed')) : ?>
                                                <div class="cc">Dublado</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if (get_field('tv_show_short_description')) : ?>
                                        <p class="description">
                                            <?php
                                            $description = get_field('tv_show_short_description');
                                            echo substr($description, 0, 200) . '...';
                                            ?>
                                        </p>
                                    <?php endif; ?>

                                    <?php if (get_field('display_slider_button') == 'yes') { ?>
                                        <a href="<?php the_permalink(); ?>" class="play-btn"><?php the_field('slider_button_label') ?></a>
                                    <?php } ?>
                                </div>
                            </div>
                        </a>

                        <div class="item-inner d-none d-md-flex">
                            <div class="container">
                                <?php if (get_field('tv_show_slider_tagline')) : ?>
                                    <h6 class="tagline"> <?php the_field('tv_show_slider_tagline') ?></h6>
                                <?php endif; ?>
                                <h2 class="name">
                                    <?php if (get_field('title_image')) { ?>
                                        <img src="<?php echo esc_url($title_image['url']); ?>" alt="<?php echo esc_attr($title_image['alt']); ?>" class="img-fluid">
                                    <?php } else {
                                        echo esc_html__($post_terms[0]->name);
                                    } ?>
                                </h2>

                                <h3>
                                    <div class="subdescription">
                                        <?php $description = get_field('description'); ?>
                                        <?php echo $description; ?>
                                    </div>
                                </h3>

                                <div class="features">
                                    <div class="d-flex align-items-center imdb_score">
                                        <?php if (get_field('imdb_score')) : ?>
                                            <div class="imdb_title d-none d-md-block">
                                                <p class="mb-0 mr-2"><?php the_field('imdb_title', 'option') ?></p>
                                            </div>
                                            <div class="rate">
                                                <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                                                    <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                                    <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php $num = get_field('imdb_score');
                                                                                                                                                echo esc_html__($num * '10' - '8'); ?>,100" cx="15" cy="15" r="14"></circle>
                                                </svg>
                                                <b>
                                                    <?php the_field('imdb_score') ?>
                                                </b>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (get_field('tv_show_range')) : ?>
                                            <div class="range">
                                                <?php the_field('tv_show_range') ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (get_field('tv_show_subtitle')) : ?>
                                            <div class="cc">Legendado</div>
                                        <?php endif; ?>

                                        <?php if (get_field('tv_show_dubbed')) : ?>
                                            <div class="cc">Dublado</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if (get_field('tv_show_short_description')) : ?>
                                    <p class="description">
                                        <?php
                                        $description = get_field('tv_show_short_description');
                                        echo substr($description, 0, 200) . '...';
                                        ?>
                                    </p>
                                <?php endif; ?>

                                <?php if (get_field('display_slider_button') == 'yes') { ?>
                                    <a href="<?php the_permalink(); ?>" class="play-btn"><?php the_field('slider_button_label') ?></a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="item" style="background-image: url(<?php the_field('tv_show_slider_image') ?>)">
                        <a href="<?php the_permalink(); ?>">
                            <div class="item-inner d-md-none">
                                <div class="slide-image-mobile" style="background-image: url(<?php the_field('tv_show_slider_mobile_image') ?>)"></div>
                                <div class="container">
                                    <?php if (get_field('tv_show_slider_tagline')) : ?>
                                        <h6 class="tagline"> <?php the_field('tv_show_slider_tagline') ?></h6>
                                    <?php endif; ?>
                                    <h2 class="name">
                                        <?php if (get_field('title_image')) { ?>
                                            <img src="<?php echo esc_url($title_image['url']); ?>" alt="<?php echo esc_attr($title_image['alt']); ?>" class="img-fluid">
                                        <?php } else {
                                            echo esc_html__($post_terms[0]->name);
                                        } ?>
                                    </h2>

                                    <h3>
                                        <div class="subdescription">
                                            <?php $description = get_field('description'); ?>
                                            <?php echo $description; ?>
                                        </div>
                                    </h3>

                                    <div class="features">
                                        <div class="d-flex align-items-center imdb_score">
                                            <?php if (get_field('imdb_score')) : ?>
                                                <div class="imdb_title d-none d-md-block">
                                                    <p class="mb-0 mr-2"><?php the_field('imdb_title', 'option') ?></p>
                                                </div>
                                                <div class="rate">
                                                    <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                                        <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php $num = get_field('imdb_score');
                                                                                                                                                    echo esc_html__($num * '10' - '8'); ?>,100" cx="15" cy="15" r="14"></circle>
                                                    </svg>
                                                    <b>
                                                        <?php the_field('imdb_score') ?>
                                                    </b>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (get_field('tv_show_range')) : ?>
                                                <div class="range">
                                                    <?php the_field('tv_show_range') ?>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (get_field('tv_show_subtitle')) : ?>
                                                <div class="cc">Legendado</div>
                                            <?php endif; ?>

                                            <?php if (get_field('tv_show_dubbed')) : ?>
                                                <div class="cc">Dublado</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if (get_field('tv_show_short_description')) : ?>
                                        <p class="description">
                                            <?php
                                            $description = get_field('tv_show_short_description');
                                            echo substr($description, 0, 200) . '...';
                                            ?>
                                        </p>
                                    <?php endif; ?>

                                    <?php if (get_field('display_slider_button') == 'yes') { ?>
                                        <a href="<?php the_permalink(); ?>" class="play-btn"><?php the_field('slider_button_label') ?></a>
                                    <?php } ?>
                                </div>
                            </div>
                        </a>

                        <div class="item-inner d-none d-md-flex">
                            <div class="slide-image-mobile" style="background-image: url(<?php the_field('tv_show_slider_mobile_image') ?>)"></div>
                            <div class="container">
                                <?php if (get_field('tv_show_slider_tagline')) : ?>
                                    <h6 class="tagline"> <?php the_field('tv_show_slider_tagline') ?></h6>
                                <?php endif; ?>
                                <h2 class="name">
                                    <?php if (get_field('title_image')) { ?>
                                        <img src="<?php echo esc_url($title_image['url']); ?>" alt="<?php echo esc_attr($title_image['alt']); ?>" class="img-fluid">
                                    <?php } else {
                                        echo esc_html__($post_terms[0]->name);
                                    } ?>
                                </h2>

                                <h3>
                                    <div class="subdescription">
                                        <?php $description = get_field('description'); ?>
                                        <?php echo $description; ?>
                                    </div>
                                </h3>

                                <div class="features">
                                    <div class="d-flex align-items-center imdb_score">
                                        <?php if (get_field('imdb_score')) : ?>
                                            <div class="imdb_title d-none d-md-block">
                                                <p class="mb-0 mr-2"><?php the_field('imdb_title', 'option') ?></p>
                                            </div>
                                            <div class="rate">
                                                <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                                                    <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                                    <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php $num = get_field('imdb_score');
                                                                                                                                                echo esc_html__($num * '10' - '8'); ?>,100" cx="15" cy="15" r="14"></circle>
                                                </svg>
                                                <b>
                                                    <?php the_field('imdb_score') ?>
                                                </b>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (get_field('tv_show_range')) : ?>
                                            <div class="range">
                                                <?php the_field('tv_show_range') ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (get_field('tv_show_subtitle')) : ?>
                                            <div class="cc">Legendado</div>
                                        <?php endif; ?>

                                        <?php if (get_field('tv_show_dubbed')) : ?>
                                            <div class="cc">Dublado</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if (get_field('tv_show_short_description')) : ?>
                                    <p class="description">
                                        <?php
                                        $description = get_field('tv_show_short_description');
                                        echo substr($description, 0, 200) . '...';
                                        ?>
                                    </p>
                                <?php endif; ?>

                                <?php if (get_field('display_slider_button') == 'yes') { ?>
                                    <a href="<?php the_permalink(); ?>" class="play-btn"><?php the_field('slider_button_label') ?></a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php endwhile; ?>
        </div>

        <ul id='carousel-custom-dots' class='owl-dots'>
            <?php while ($movie->have_posts()) :
                $movie->the_post(); ?>
                <li class='owl-dot'>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
                        <circle r="13" cy="15" cx="15"></circle>
                    </svg>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php endif; ?>
</header>