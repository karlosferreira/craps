<?php
get_header();

$thumbnail_image = get_the_post_thumbnail_url(get_the_ID());
$title = get_the_title();
$title_image = get_field('title_image_black');
$description = get_field('description');
$rating_title = get_field('rating_title_black', 'option');
$select_quality_image = get_field('select_quality_image');

// playlist da série
// Obtém os metadados da postagem atual
$serie_field = get_post_meta(get_the_ID());

// Verifica se $serie_field contém a chave _rel_series_tv_show
if (isset($serie_field['_rel_series_tv_show'])) {
    // Obtém o valor associado à chave _rel_series_tv_show
    $rel_series_tv_show = $serie_field['_rel_series_tv_show'];

    $serie_value = get_field($rel_series_tv_show[0], get_the_ID());

    $serie_meta = get_post_meta($serie_value[0]);

    $serie_playlist = $serie_meta['playlist_items'][0];

    // Desserializa a string para obter o array
    $playlist_array = unserialize($serie_playlist);





    // if ($serie_meta['custom_new_playlist'][0]) {
    //     $serie_playlist = $serie_meta['custom_new_playlist'][0];
    //     $playlist = explode(',', $serie_playlist);
    //     $other_shows = array_diff($playlist, array(get_the_ID()));
    //     print_r($other_shows);
    //     die();
    // } else {
    //     $serie_playlist = array_diff($playlist_array, array(get_the_ID()));
    //     print_r($serie_playlist);
    //     die();
    // }


}

// Aqui termina a nova rotina de relacionamento da playlist da série

?>
<header class="page-header page-header-app single">
    <div class="pattern-bg"></div>
    <div class="poster-bg" data-background="<?php the_field('tv_show_slider_image') ?>"></div>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="video-player grid-item-<?php echo get_the_ID(); ?>">
                    <?php the_field('embed_tv_show') ?>
                    <?php echo do_shortcode("[starday_favorite_button post_id={$post->ID}]"); ?>
                    <?php //echo do_shortcode('[ccc_my_favorite_select_button text="Assistido" style=""]') 
                    ?>

                </div>
            </div>
        </div>
    </div>
    <style>
        .button-container {
            display: flex;
            justify-content: start;
        }

        .button-container2 {
            padding-top: 30px;
            margin-left: -38px;
        }

        .button {
            border: 2px solid;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            padding: 12px 24px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s, color 0.3s;
        }

        .button.black {
            color: black;
            border-color: black;
            margin-right: 20px;
            text-decoration: none;
            font-size: 16px;
            padding: 12px 24px;
        }

        .button.black:hover {
            background-color: black;
            color: white;
            text-decoration: none;
        }

        .button.red {
            color: white;
            background-color: red;
            text-decoration: none;
            font-weight: bold;
        }

        .button.red:hover {
            background-color: darkred;
            text-decoration: none;
            font-weight: bold;
        }

        .info-bottom {
            padding-top: 0;
        }

        .info-bottom .pld-common-wrap>a.pld-like-dislike-trigger i {
            line-height: 66px;
            color: #888888;
        }
    </style>
</header>
<main>
    <section class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-10 offset-1 d-block d-md-none">

                    <div class="movie-info-box">
                        <h2 class="name" style="font-size:30px">
                            <?php if (get_field('title_image_black')) { ?>
                                <img src="<?php echo esc_url($title_image['url']); ?>" alt="<?php echo esc_attr($title_image['alt']); ?>" class="img-fluid mb-3">
                            <?php } else { ?>
                                <?php echo wp_kses_post($title); ?>
                            <?php } ?>
                        </h2>

                        <h3>
                            <div class="subdescription">
                                <p>
                                    <?php echo $description; ?>
                                </p>
                            </div>
                        </h3>

                        <div class="features mb-0">
                            <div class="d-flex align-items-center imdb_score">
                                <?php if (get_field('tv_show_imdb_score')) : ?>

                                    <div class="rate">
                                        <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                                            <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                            <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php $num = get_field('tv_show_imdb_score');
                                                                                                                                        echo esc_html__($num * '10' - '8'); ?>,100" cx="15" cy="15" r="14"></circle>
                                        </svg>
                                        <b>
                                            <?php the_field('tv_show_imdb_score') ?>
                                        </b>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if (get_field('tv_show_range')) : ?>
                                <div class="range">
                                    <?php the_field('tv_show_range') ?>
                                </div>
                            <?php endif; ?>

                            <?php if (get_field('tv_show_subtitle')) : ?>
                                <?php the_field('tv_show_subtitle') ?>
                            <?php endif; ?>
                            <?php if (get_field('tv_show_dubbed')) : ?>
                                <?php the_field('tv_show_dubbed') ?>
                            <?php endif; ?>
                            <?php
                            $terms = get_the_terms($post->ID, 'tv_show_categories');
                            if ($terms && !is_wp_error($terms)) :
                            ?>
                                <div class="category">
                                    <?php foreach ($terms as $term) { ?>
                                        <?php echo esc_html__($term->name); ?>
                                    <?php } ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="movie-side-box d-block d-md-none">
                            <figure>
                                <img src="<?php echo esc_url($thumbnail_image); ?>" alt="<?php the_title_attribute(); ?>">
                            </figure>
                        </div>

                        <?php if (get_field('tv_show_short_description')) : ?>
                            <p class="description" style="padding-top: 20px;">
                                <?php the_field('tv_show_short_description') ?>
                            </p>
                        <?php endif; ?>

                        <ul class="info">
                            <?php if (get_field('tv_show_director')) : ?>
                                <li>
                                    <h6><?php echo esc_html__('Director: ', 'digiflex'); ?></h6>
                                    <span><?php the_field('tv_show_director') ?></span>
                                </li>
                            <?php endif; ?>
                            <?php if (get_field('tv_show_cast')) : ?>
                                <li>
                                    <h6><?php echo esc_html__('Casting', 'digiflex'); ?></h6>
                                    :
                                    <span><?php the_field('tv_show_cast') ?></span>
                                </li>
                            <?php endif; ?>
                            <?php if (get_field('tv_show_producer')) : ?>
                                <li>
                                    <h6><?php echo esc_html__('Production: : ', 'digiflex'); ?></h6>
                                    <span><?php the_field('tv_show_producer'); ?></span>
                                </li>
                            <?php endif; ?>

                            <?php if (have_rows('extra_fields_tvshow')) : ?>
                                <?php while (have_rows('extra_fields_tvshow')) : the_row(); ?>
                                    <li>
                                        <h6><?php the_sub_field('title_tvshow'); ?></h6>
                                        :
                                        <span> <?php the_sub_field('content_tvshow'); ?></span>
                                    </li>
                                <?php endwhile;
                            else : ?>
                            <?php endif; ?>
                        </ul>

                        <div class="button-container2">
                            <div class="info-bottom">
                                <?php echo do_shortcode('[posts_like_dislike]'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8 d-none d-md-flex">
                    <div class="movie-info-box">
                        <h2 class="name" style="font-size:30px">
                            <?php if (get_field('title_image_black')) { ?>
                                <img src="<?php echo esc_url($title_image['url']); ?>" alt="<?php echo esc_attr($title_image['alt']); ?>" class="img-fluid mb-3">
                            <?php } else { ?>
                                <?php echo wp_kses_post($title); ?>
                            <?php } ?>
                        </h2>

                        <h3>
                            <div class="subdescription">
                                <p>
                                    <?php echo $description; ?>
                                </p>
                            </div>
                        </h3>

                        <div class="features mb-0">
                            <div class="d-flex align-items-center imdb_score">
                                <?php if (get_field('tv_show_imdb_score')) : ?>

                                    <div class="rate">
                                        <svg class="circle-chart" viewBox="0 0 30 30" width="40" height="40" fill="transparent" xmlns="http://www.w3.org/2000/svg">
                                            <circle class="circle-chart__background" stroke="#eee" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                            <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php $num = get_field('tv_show_imdb_score');
                                                                                                                                        echo esc_html__($num * '10' - '8'); ?>,100" cx="15" cy="15" r="14"></circle>
                                        </svg>
                                        <b>
                                            <?php the_field('tv_show_imdb_score') ?>
                                        </b>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if (get_field('tv_show_range')) : ?>
                                <div class="range">
                                    <?php the_field('tv_show_range') ?>
                                </div>
                            <?php endif; ?>

                            <?php if (get_field('tv_show_subtitle')) : ?>
                                <?php the_field('tv_show_subtitle') ?>
                            <?php endif; ?>
                            <?php if (get_field('tv_show_dubbed')) : ?>
                                <?php the_field('tv_show_dubbed') ?>
                            <?php endif; ?>
                            <?php
                            $terms = get_the_terms($post->ID, 'tv_show_categories');
                            if ($terms && !is_wp_error($terms)) :
                            ?>
                                <div class="category">
                                    <?php foreach ($terms as $term) { ?>
                                        <?php echo esc_html__($term->name); ?>
                                    <?php } ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if (get_field('tv_show_short_description')) : ?>
                            <p class="description" style="padding-top: 20px;">
                                <?php the_field('tv_show_short_description') ?>
                            </p>
                        <?php endif; ?>

                        <ul class="info">
                            <?php if (get_field('tv_show_director')) : ?>
                                <li>
                                    <h6><?php echo esc_html__('Director: ', 'digiflex'); ?></h6>
                                    <span><?php the_field('tv_show_director') ?></span>
                                </li>
                            <?php endif; ?>
                            <?php if (get_field('tv_show_cast')) : ?>
                                <li>
                                    <h6><?php echo esc_html__('Casting', 'digiflex'); ?></h6>
                                    :
                                    <span><?php the_field('tv_show_cast') ?></span>
                                </li>
                            <?php endif; ?>
                            <?php if (get_field('tv_show_producer')) : ?>
                                <li>
                                    <h6><?php echo esc_html__('Production: ', 'digiflex'); ?></h6>
                                    <span><?php the_field('tv_show_producer') ?></span>
                                </li>
                            <?php endif; ?>

                            <?php if (have_rows('extra_fields_tvshow')) : ?>
                                <?php while (have_rows('extra_fields_tvshow')) : the_row(); ?>
                                    <li>
                                        <h6><?php the_sub_field('title_tvshow'); ?></h6>
                                        :
                                        <span> <?php the_sub_field('content_tvshow'); ?></span>
                                    </li>
                                <?php endwhile;
                            else : ?>
                            <?php endif; ?>
                        </ul>

                        <div class="button-container2">
                            <div class="info-bottom">
                                <?php echo do_shortcode('[posts_like_dislike]'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 offset-md-1 d-none d-md-block">
                    <div class="movie-side-box grid-item-<?php echo get_the_ID(); ?>">
                        <figure>
                            <?php echo do_shortcode("[starday_favorite_button post_id={$post->ID}]"); ?>
                            <?php //echo do_shortcode('[ccc_my_favorite_select_button text="Assistido" style=""]') 
                            ?>

                            <img src="<?php echo esc_url($thumbnail_image); ?>" alt="<?php the_title_attribute(); ?>">
                        </figure>
                    </div>
                </div>

                <div class="col-12">
                    <?php echo do_shortcode('[wpdiscuz_comments]') ?>
                </div>

                <div class="col-12">
                    <div class="button-container">
                        <a href="https://starday.com.br" target="_blank" class="button black">SAIBA MAIS</a>
                        <a href="https://stardayoficial.com/assinatura-starday-passo-1/" target="_blank" class="button red">ASSINE AGORA</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php

$playlist_array = isset($playlist_array) ? $playlist_array : array();

if (isset($serie_meta['custom_new_playlist'][0]) && !empty($serie_meta['custom_new_playlist'][0])) {
    $serie_playlist = $serie_meta['custom_new_playlist'][0];
    $playlist = explode(',', $serie_playlist);
    $other_shows = array_diff($playlist, array(get_the_ID()));
?>

    <section class="content-section" data-background="#111111">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title light">
                        <h2>
                            Episódios Relacionados
                        </h2>
                    </div>
                </div>
                <div class="col-12">
                    <div class="carousel-tv-shows">
                        <div class="swiper-wrapper">
                            <?php

                            if ($other_shows) {

                                $args = array(
                                    'post_type' => 'tv_show',
                                    'posts_per_page' => -1,
                                    'post__in' => $other_shows,
                                    'orderby' => 'post__in'
                                );

                                $tv_shows_query = new WP_Query($args);

                                if ($tv_shows_query->have_posts()) {
                                    while ($tv_shows_query->have_posts()) {
                                        $tv_shows_query->the_post();
                            ?>

                                        <div class="swiper-slide">
                                            <div class="episode-box grid-item-<?php echo get_the_ID(); ?>">
                                                <?php echo do_shortcode("[starday_favorite_button post_id='" . get_the_ID() . "']"); ?>
                                                <figure>
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php
                                                        if (has_post_thumbnail()) {
                                                            $related_thumbnail_image = get_the_post_thumbnail_url(get_the_ID());
                                                        ?>
                                                            <img src="<?php echo esc_url($related_thumbnail_image); ?>" alt="<?php the_field('episode_name'); ?>">
                                                        <?php
                                                        } else {
                                                        ?>
                                                            <img src="<?php echo esc_url(get_template_directory_uri() . '/images/capa-filler.png'); ?>" alt="Starday">
                                                        <?php
                                                        }
                                                        ?>
                                                    </a>
                                                </figure>

                                                <div class="content">
                                                    <small>
                                                        <?php echo $post_terms[0]->name; ?>
                                                        <?php if (get_field('episode_number')) { ?>
                                                            - Episódio
                                                            <?php the_field('episode_number'); ?>
                                                        <?php } ?>
                                                    </small>

                                                    <h6>
                                                        <?php the_field('episode_name'); ?>
                                                    </h6>
                                                </div>

                                            </div>
                                        </div>
                            <?php
                                    }
                                    wp_reset_postdata();
                                }
                            }
                            ?>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php } else {

    $serie_playlist = isset($playlist) ? array_diff($playlist, array(get_the_ID())) : array();
?>

    <section class="content-section" data-background="#111111">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title light">
                        <h2>
                            Episódios Relacionados
                        </h2>
                    </div>
                </div>
                <div class="col-12">
                    <div class="carousel-tv-shows">
                        <div class="swiper-wrapper">
                            <?php

                            if ($serie_playlist) {

                                $args = array(
                                    'post_type' => 'tv_show',
                                    'posts_per_page' => -1,
                                    'post__in' => $serie_playlist,
                                    'orderby' => 'post__in'
                                );

                                $tv_shows_query = new WP_Query($args);

                                if ($tv_shows_query->have_posts()) {
                                    while ($tv_shows_query->have_posts()) {
                                        $tv_shows_query->the_post();
                            ?>

                                        <div class="swiper-slide">
                                            <div class="episode-box grid-item-<?php echo get_the_ID(); ?>">
                                                <?php echo do_shortcode("[starday_favorite_button post_id='" . get_the_ID() . "']"); ?>
                                                <figure>
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php
                                                        if (has_post_thumbnail()) {
                                                            $related_thumbnail_image = get_the_post_thumbnail_url(get_the_ID());
                                                        ?>
                                                            <img src="<?php echo esc_url($related_thumbnail_image); ?>" alt="<?php the_field('episode_name'); ?>">
                                                        <?php
                                                        } else {
                                                        ?>
                                                            <img src="<?php echo esc_url(get_template_directory_uri() . '/images/capa-filler.png'); ?>" alt="Starday">
                                                        <?php
                                                        }
                                                        ?>
                                                    </a>
                                                </figure>

                                                <div class="content">
                                                    <small>
                                                        <?php echo $post_terms[0]->name; ?>
                                                        <?php if (get_field('episode_number')) { ?>
                                                            - Episódio
                                                            <?php the_field('episode_number'); ?>
                                                        <?php } ?>
                                                    </small>

                                                    <h6>
                                                        <?php the_field('episode_name'); ?>
                                                    </h6>
                                                </div>

                                            </div>
                                        </div>
                            <?php
                                    }
                                    wp_reset_postdata();
                                }
                            }
                            ?>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php } ?>


</main>
<?php get_footer(); ?>