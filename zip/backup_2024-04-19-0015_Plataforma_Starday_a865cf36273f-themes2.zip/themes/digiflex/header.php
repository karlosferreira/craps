<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<?php wp_body_open(); ?>
<?php
  $enable_user_name = ( digiflex_get_option( 'disable_user_name' ) ) ? false : true;
  $logo = ( digiflex_get_option( 'logo' ) ) ? digiflex_get_option( 'logo' ) : get_template_directory_uri() . '/images/logo@2x.png';
  $retina_logo = ( digiflex_get_option( 'retina_logo' ) ) ? digiflex_get_option( 'retina_logo' ) : '';

  ?>
<div class="search-box">
  <div class="container">
    <form role="search" action="<?php echo site_url('/'); ?>" method="get" id="searchform">
		<select name="post_type">
			<option value="movie">Movie</option>
			<option value="tv_show">TV Show</option>
		</select>
		 <input type="search" name="s" placeholder="<?php echo esc_attr__( 'Search here', 'digiflex' );?>"/>
      <input type="submit" value="<?php echo esc_attr__( 'FIND', 'digiflex' );?>" />
    </form>
  </div>
  <!-- end container --> 
</div>
<!-- end search-box -->
<nav class="mobile-menu">
  <div class="inner">
    <div class="mobile-search">
      <form role="search" action="<?php echo site_url('/'); ?>" method="get" id="searchform2">
		  <select name="post_type">
			<option value="movie">Movie</option>
			<option value="tv_show">TV Show</option>
		</select>
        <input type="search" name="s" placeholder="<?php echo esc_attr__( 'Search here', 'digiflex' );?>"/>
        <input type="submit" value="<?php echo esc_attr__( 'FIND', 'digiflex' );?>" />
      </form>
    </div>
    <!-- end mobile-search --> 
    <a href="<?php echo esc_url( get_permalink( get_page_by_title( 'My Account' ) ), 'digiflex' ); ?>" class="button-account"><i class="lni lni-user"></i> <?php echo esc_html__( 'ACCOUNT', 'digiflex' );?> </a> 
    <!-- end button-account -->
    <div class="site-menu">
      <?php
      if ( has_nav_menu( 'header' ) ) {
        wp_nav_menu( array(
          'theme_location' => 'header',
          'menu_class' => 'menu-horizontal',
          'walker' => new WP_Consto_Navwalker(),
        ) );
      }
      ?>
    </div>
    <!-- end site-menu --> 
  </div>
  <!-- end inner --> 
</nav>
<!-- end mobile-menu -->

<nav class="navbar">
  <div class="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $logo ); ?>"
	<?php if( $retina_logo != '' ) : ?>
		srcset="<?php echo esc_url( $retina_logo ); ?>"
	<?php endif; ?>
		alt="<?php bloginfo( 'name' ); ?>"></a></div>
  <div class="site-menu">
    <?php
    if ( has_nav_menu( 'header' ) ) {
      wp_nav_menu( array(
        'theme_location' => 'header',
        'menu_class' => 'menu-horizontal',
        'walker' => new WP_Consto_Navwalker(),
      ) );
    }
    ?>
  </div>
  <!-- end site-menu -->

			<?php
if ( digiflex_get_option( 'enable_user_menu' ) ): 
  ?>
  <div class="user-menu">
    <div class="navbar-search"> <i class="lni lni-search-alt"></i> </div>
    <!-- end navbar-search -->
    <div class="navbar-bookmark"> <a href="<?php echo esc_url( get_permalink( get_page_by_title( 'Bookmark' ) ), 'digiflex' ); ?>"><i class="lni lni-bookmark"></i></a> </div>
    <!-- end navbar-bookmark -->
    <div class="navbar-account">
      <?php
      if ( is_user_logged_in() ) {
        $current_user = wp_get_current_user();
        if ( ( $current_user instanceof WP_User ) ) {
          ?>
      <div class="user-dropdown"> <?php echo esc_html__( $current_user->display_name ); ?>
        <?php
        if ( has_nav_menu( 'user_menu' ) ) {
          wp_nav_menu( array(
            'theme_location' => 'user_menu',
            'walker' => new WP_Consto_Navwalker(),
          ) );
        }
        ?>
      </div>
      <!-- end user-dropdown -->
      <figure> <?php echo get_avatar( $current_user->ID, 40 );  } ?> </figure>
      <?php } else { ?>
      <a href="<?php echo esc_url( get_permalink( get_page_by_title( 'My Account' ) ), 'digiflex' ); ?>"><?php echo esc_html__( 'ACCOUNT', 'digiflex' );?> <i class="lni lni-user"></i> </a>
      <?php } ?>
    </div>
    <!-- end navbar-account --> 
  </div>
  <!-- end user-menu -->

  <?php  endif; ?>
  <?php if ( has_nav_menu( 'header' ) ) : ?>
  <div class="hamburger-menu">
    <button class="hamburger">
    <svg width="45" height="45" viewBox="0 0 100 100">
      <path class="line line1" d="M 20,29.000046 H 80.000231 C 80.000231,29.000046 94.498839,28.817352 94.532987,66.711331 94.543142,77.980673 90.966081,81.670246 85.259173,81.668997 79.552261,81.667751 75.000211,74.999942 75.000211,74.999942 L 25.000021,25.000058" />
      <path class="line line2" d="M 20,50 H 80" />
      <path class="line line3" d="M 20,70.999954 H 80.000231 C 80.000231,70.999954 94.498839,71.182648 94.532987,33.288669 94.543142,22.019327 90.966081,18.329754 85.259173,18.331003 79.552261,18.332249 75.000211,25.000058 75.000211,25.000058 L 25.000021,74.999942" />
    </svg>
    </button>
  </div>
  <!-- end hamburger-menu -->
  <?php endif; ?>
</nav>