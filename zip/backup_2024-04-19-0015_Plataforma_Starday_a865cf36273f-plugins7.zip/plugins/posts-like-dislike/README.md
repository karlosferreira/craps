# posts-like-dislike
This is the official github repository for the Posts Like Dislike plugin available in the wordpress.org plugin repository.
