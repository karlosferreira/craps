<?php
/*
Plugin Name: Starday - Posts favoritos do usuário
Description: Adiciona uma lista de tv_shows favoritos ao perfil do usuário.
Version: 1.0
Author: Carlos Ferreira
*/

function custom_user_fields_add_field()
{
    $field_name = 'tv_show_favorites';
    $post_type = 'tv_show';

    register_meta('user', $field_name, array(
        'type' => 'array',
        'single' => false,
        'show_in_rest' => true,
    ));

    add_action('show_user_profile', 'custom_user_fields_display_field');
    add_action('edit_user_profile', 'custom_user_fields_display_field');

    add_action('personal_options_update', 'custom_user_fields_save_field');
    add_action('edit_user_profile_update', 'custom_user_fields_save_field');
}
add_action('init', 'custom_user_fields_add_field');

function custom_user_fields_display_field($user)
{
    $field_name = 'tv_show_favorites';
    $field_value = get_user_meta($user->ID, $field_name, true);
?>
    <h3>Favoritos de Programas de TV</h3>
    <table class="form-table">
        <tr>
            <th><label for="<?php echo $field_name; ?>">IDs de <?php echo $field_name; ?></label></th>
            <td>
                <input type="text" name="<?php echo $field_name; ?>" id="<?php echo $field_name; ?>" value="<?php echo esc_attr(json_encode($field_value)); ?>" class="regular-text" />
                <p class="description">Informe uma lista de IDs de <?php echo $field_name; ?> separados por vírgulas.</p>
            </td>
        </tr>
    </table>
<?php
}

function custom_user_fields_save_field($user_id)
{
    $field_name = 'tv_show_favorites';

    if (current_user_can('edit_user', $user_id)) {
        $field_value = json_decode(sanitize_text_field($_POST[$field_name]), true);
        update_user_meta($user_id, $field_name, $field_value);
    }
}


function starday_favorite_button_shortcode($atts)
{
    $atts = shortcode_atts(
        array(
            'post_id' => null,
        ),
        $atts,
        'starday_favorite_button'
    );

    if (empty($atts['post_id'])) {
        return '';
    }

    ob_start();

    $plugin_dir_url = plugins_url('/', __FILE__);
?>
    <link rel="stylesheet" href="<?php echo $plugin_dir_url; ?>assets/css/animate.min.css" />
    <style>
        .episode-box .ccc-favorite-post-toggle {
            position: absolute;
            right: 14px;
        }

        .loader-remove-favorite-animated {
            width: 28px;
        }


        @keyframes pulse {
            0% {
                display: none;
            }

            50% {
                display: block;
            }

            100% {
                display: none;
            }
        }

        .pulse {
            animation-name: pulse;
            animation-duration: 1s;
            animation-iteration-count: infinite;
            animation-timing-function: ease-in-out;
        }

        .video-thumb .ccc-favorite-post-toggle {
            position: absolute;
            margin: 0;
            right: 10px;
            top: 10px;
        }

        .ccc-favorite-post-toggle[data-ccc_my_favorites-select_button-style="1"] {
            text-align: right;
            z-index: 10;
        }

        .ccc-favorite-post-toggle>a {
            display: inline-block;
            vertical-align: top;
            box-sizing: border-box;
            padding: 0 6px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .ccc-favorite-post-toggle-button {
            align-items: center;
            background-color: transparent;
            width: 25px;
            height: 25px;
            border: 1px solid #595757;
            border-radius: 4px;
            position: relative;
            opacity: 1;
        }

        .ccc-favorite-post-toggle>a::before {
            content: "\f08a";
        }

        .ccc-favorite-post-count>a::before,
        .ccc-favorite-post-toggle>a::before,
        .ccc-favorite-post-delete>a::before {
            font-family: 'icomoon-ccc-my_favorite' !important;
            speak: never;
            font-style: normal;
            font-weight: normal;
            font-variant: normal;
            text-transform: none;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .ccc-favorite-post-toggle-button::before {
            content: '' !important;
            display: inline-block;
            color: #595757;
            width: 8px;
            height: 13px;
            border-right: 2px solid #595757;
            border-bottom: 2px solid #595757;
            transform: translate(-50%, -60%) rotate(45deg) scale(1);
            position: absolute;
            left: 50%;
            top: 50%;
            opacity: 1;
        }
    </style>
    <div class="ccc-favorite-post-toggle" data-ccc_my_favorites-select_button-style="1">
        <?php
        $is_user_logged_in = is_user_logged_in();
        $is_favorites_page = is_page('favoritos');

        $is_favorite_post = false;
        if ($is_user_logged_in) {
            $user_id = get_current_user_id();
            $user_favorites = get_user_meta($user_id, 'tv_show_favorites', true);
            $is_favorite_post = is_array($user_favorites) && in_array($atts['post_id'], $user_favorites);
        }

        $button_class = $is_user_logged_in && ($is_favorites_page || $is_favorite_post) ? 'save' : '';
        ?>
        <a href="#" class="ccc-favorite-post-toggle-button <?php echo esc_attr($button_class); ?>" data-post_id-ccc_favorite="<?php echo esc_attr($atts['post_id']); ?>">
            <!-- <span class="text">Favorite</span> -->
        </a>
    </div>

<?php
    return ob_get_clean();
}
add_shortcode('starday_favorite_button', 'starday_favorite_button_shortcode');

function starday_add_js_to_frontend()
{
?>
    <script src="https://kit.fontawesome.com/8bd60f87cb.js" crossorigin="anonymous"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var favoriteButtons = document.querySelectorAll('.ccc-favorite-post-toggle a');

            favoriteButtons.forEach(function(button) {
                button.addEventListener('click', function(event) {
                    event.preventDefault();

                    // Obtém o postId do botão atual
                    var postId = button.getAttribute('data-post_id-ccc_favorite');

                    // Seleciona todos os botões com o mesmo postId
                    var buttonsWithSamePostId = document.querySelectorAll('[data-post_id-ccc_favorite="' + postId + '"]');

                    // Itera sobre os botões com o mesmo postId
                    buttonsWithSamePostId.forEach(function(btn) {
                        // Verifica se o botão não tem a classe 'save'
                        if (!btn.classList.contains('save')) {
                            btn.classList.add('save');
                        } else {
                            btn.classList.toggle('save');
                        }

                        // Adiciona as classes de animação
                        btn.classList.add('animate__animated', 'animate__heartBeat', 'animate__infinite');
                    });

                });
            });
        });
    </script>
<?php
}
add_action('wp_footer', 'starday_add_js_to_frontend');


function check_and_add_to_favorites($param)
{
    error_log('Start check_and_add_to_favorites');

    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

    $post = get_post($post_id);

    $temp_arr = [];

    if ($post) {
        $user_id = get_current_user_id();
        $field_name = 'tv_show_favorites';
        $user_favorites = get_user_meta($user_id, $field_name, true);

        if (!empty($user_favorites)) {
            $temp_arr = $user_favorites;

            if (!in_array($post_id, $temp_arr)) {
                array_push($temp_arr, $post_id);
            } else {
                $remove_favorite = array_search($post_id, $temp_arr);
                if ($remove_favorite !== false) {
                    unset($temp_arr[$remove_favorite]);
                }
            }

            $temp_arr = array_values($temp_arr);

            update_user_meta($user_id, $field_name, $temp_arr);
        } else {
            array_push($temp_arr, $post_id);
            update_user_meta($user_id, $field_name, $temp_arr);
        }
    }


    error_log('End check_and_add_to_favorites');
    wp_die();
}
add_action('wp_ajax_check_and_add_to_favorites', 'check_and_add_to_favorites');
add_action('wp_ajax_nopriv_check_and_add_to_favorites', 'check_and_add_to_favorites');

function starday_add_js_to_footer()
{
?>
    <script>
        (function ($) {

            $(document).ready(function () {
                "use strict";
                var itemSelector = '.grid-item'; 

                var $container = $('.grid').isotope({
                    layoutMode: 'fitRows',
                    itemSelector: itemSelector,
                    fitRows: {
                    gutter: 20
                    }
                })

                var responsiveIsotope = [
                    [480, 12],
                    [720, 12]
                ];

                var itemsPerPageDefault = 12;
                var itemsPerPage = defineItemsPerPage();
                var currentNumberPages = 1;
                var currentPage = 1;
                var currentFilter = '*';
                var filterAtribute = 'data-filter';
                var pageAtribute = 'data-page';
                var pagerClass = 'isotope-pager';

                var itemsLength = $container.children(itemSelector).length;
                var pages = Math.ceil(itemsLength / itemsPerPage);

                function changeFilter(selector) {
                    $container.isotope({
                    filter: selector
                    });
                }

                function goToPage(n) {

                    currentPage = n;
                    let current = parseInt(n);
                    var itemsLength = $container.children(itemSelector).length;
                    console.log('itemsLength', itemsLength)
                    var pages = Math.ceil(itemsLength / itemsPerPage);
                    let max = pages;

                    var selector = itemSelector;
                    selector += ( currentFilter != '*' ) ? '['+filterAtribute+'="'+currentFilter+'"]' : '';
                    selector += '['+pageAtribute+'="'+currentPage+'"]';

                    $('html, body').animate({
                        scrollTop: $('.movies_section').offset().top
                    }, 800);

                    changeFilter(selector);

                    var currentClass = '';
                    var $isotopePager = ( $('.'+pagerClass).length == 0 ) ? $('<div class="'+pagerClass+'"></div>') : $('.'+pagerClass);
                    $isotopePager.html('');

                    var $isotopePager = ( $('.'+pagerClass).length == 0 ) ? $('<div class="'+pagerClass+'"></div>') : $('.'+pagerClass);
                    $isotopePager.html('');

                    console.log('current', current)
                    var $previousButton = $('<a href="javascript:void(0);" class="pager previous" data-page="'+((current-1) === 0 ? pages : current - 1)+'">« <span>Anterior</span></a>');
                    $previousButton.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                    });
                    var $nextButton = $('<a href="javascript:void(0);" class="pager next" data-page="'+((current+1) > pages ? 1 : current+1)+'"><span>Próximo</span> »</a>');
                    $nextButton.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                    });

                    $isotopePager.append($previousButton);

                    

                    if (!current || !max) return null

                    let prev = current === 1 ? null : current - 1,
                        next = current === max ? null : current + 1,
                        items = [1]

                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(1)+'"></a>');
                        $pager.html(1);	
                        $pager.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                        });
                        $pager.appendTo($isotopePager);

                    if (current === 1 && max === 1) return null
                    if (current > 4){
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                        $pager.html('...');	
                        $pager.appendTo($isotopePager);
                        items.push('…')
                    }

                    let r = 2, r1 = current - r, r2 = current + r

                    for (let i = r1 > 2 ? r1 : 2; i <= Math.min(max, r2); i++){
                        items.push(i)
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(i)+'"></a>');
                        $pager.html(i);	
                        $pager.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                        });
                        $pager.appendTo($isotopePager);
                    }

                    if (r2 + 1 < max){
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                        $pager.html('...');	
                        $pager.appendTo($isotopePager);
                        items.push('…')
                    }
                    if (r2 < max){
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(max)+'"></a>');
                        $pager.html(max);	
                        $pager.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                        });
                        $pager.appendTo($isotopePager);
                        items.push(max)
                    }

                    $isotopePager.append($nextButton);
                    $container.after($isotopePager);

                    $('.isotope-pager .pager[data-page="'+current+'"]').addClass('current');
                }

                function defineItemsPerPage() {
                    var pages = itemsPerPageDefault;

                    for( var i = 0; i < responsiveIsotope.length; i++ ) {
                    if( $(window).width() <= responsiveIsotope[i][0] ) {
                        pages = responsiveIsotope[i][1];
                        break;
                    }
                    }
                    return pages;
                }

                function setPagination() {
                    var SettingsPagesOnItems = function(){
                    var itemsLength = $container.children(itemSelector).length;
                    var pages = Math.ceil(itemsLength / itemsPerPage);
                    var item = 1;
                    var page = 1;
                    var selector = itemSelector;
                        selector += ( currentFilter != '*' ) ? '['+filterAtribute+'="'+currentFilter+'"]' : '';
                    
                    $container.children(selector).each(function(){
                        if( item > itemsPerPage ) {
                        page++;
                        item = 1;
                        }
                        $(this).attr(pageAtribute, page);
                        item++;
                    });
                    currentNumberPages = page;
                    }();

                    var CreatePagers = function() {
                    var currentClass = '';
                    let current = 1;

                    var $isotopePager = ( $('.'+pagerClass).length == 0 ) ? $('<div class="'+pagerClass+'"></div>') : $('.'+pagerClass);
                    $isotopePager.html('');

                    var $previousButton = $('<a href="javascript:void(0);" class="pager previous" data-page="'+(current-1)+'">« <span>Anterior</span></a>');
                    $previousButton.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                    });
                    var $nextButton = $('<a href="javascript:void(0);" class="pager next" data-page="'+(current+1)+'"><span>Próximo</span> »</a>');
                    $nextButton.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        console.log('pegou evento', page)
                        goToPage(page);
                    });

                    $isotopePager.append($previousButton);

                    var itemsLength = $container.children(itemSelector).length;
                    var pages = Math.ceil(itemsLength / itemsPerPage);
                    let max = pages;
                    if (!current || !max) return null

                    let prev = current === 1 ? null : current - 1,
                        next = current === max ? null : current + 1,
                        items = [1]

                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(1)+'"></a>');
                        $pager.html(1);	
                        $pager.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                        });
                        $pager.appendTo($isotopePager);

                    if (current === 1 && max === 1) return null
                    if (current > 4){
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                        $pager.html('...');	
                        $pager.appendTo($isotopePager);
                        items.push('…')
                    }

                    let r = 2, r1 = current - r, r2 = current + r

                    for (let i = r1 > 2 ? r1 : 2; i <= Math.min(max, r2); i++){
                        items.push(i)
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(i)+'"></a>');
                        $pager.html(i);	
                        $pager.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                        });
                        $pager.appendTo($isotopePager);
                    }

                    if (r2 + 1 < max){
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'"></a>');
                        $pager.html('...');	
                        $pager.appendTo($isotopePager);
                        items.push('…')
                    }
                    if (r2 < max){
                        var $pager = $('<a href="javascript:void(0);" class="pager '+ currentClass +'" '+pageAtribute+'="'+(max)+'"></a>');
                        $pager.html(max);	
                        $pager.click(function(){
                        var page = $(this).eq(0).attr(pageAtribute);
                        goToPage(page);
                        });
                        $pager.appendTo($isotopePager);
                        items.push(max)
                    }
                    
                    $isotopePager.append($nextButton);
                    $container.after($isotopePager);

                    $('.isotope-pager .pager[data-page="'+current+'"]').addClass('current');
                    }();
                }

                var favoriteButtons = document.querySelectorAll('.ccc-favorite-post-toggle-button');

                    favoriteButtons.forEach(function(button) {
                        button.addEventListener('click', function(event) {
                            event.preventDefault();
                            var postId = button.getAttribute('data-post_id-ccc_favorite');

                            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

                            var data = {
                                'action': 'check_and_add_to_favorites',
                                'post_id': postId
                            };

                            jQuery.post(ajaxurl, data, function() {
                                if (window.location.pathname.includes('/favoritos')) {
                                    const postIdValue = button.getAttribute('data-post_id-ccc_favorite'); // Extrai o valor do atributo
                                    const completeGridItem = 'grid-item-' + postIdValue;

                                    const gridItemElement = document.querySelector('.' + completeGridItem);
                                    const gridElement = document.querySelector('.grid');
                                    if (gridItemElement) {
                                        gridItemElement.classList.add('animate__bounceOut');

                                        gridItemElement.addEventListener('animationend', function() {
                                            gridItemElement.style.display = 'none';

                                            setTimeout(() => {
                                                gridItemElement.remove();
                                                console.log('removendo elemento', gridItemElement)
                                                $container.isotope( 'reloadItems' ).isotope();

                                                itemsPerPage = defineItemsPerPage();
                                                setPagination();
                                                goToPage(1);

                                                const remainingGridItems = document.querySelectorAll('.grid-item');
                                                console.log('remainingGridItems', remainingGridItems.length)
                                                if(remainingGridItems.length <= 12){
                                                    $('.isotope-pager').hide();
                                                }

                                                if (remainingGridItems.length === 0) {
                                                    gridElement.innerHTML = '<div class="grid">Você ainda não tem favoritos.</div>';
                                                }
                                            }, 300);
                                        });
                                    } else {
                                        const remainingGridItems = document.querySelectorAll('.grid-item');
                                        if (remainingGridItems.length === 0) {
                                            const gridContainer = document.querySelector('.grid');
                                            if (gridContainer) {
                                                gridContainer.innerHTML = '<div class="grid">Você ainda não tem favoritos.</div>';
                                            }
                                        }
                                    }
                                } else {
                                    const postIdValue = button.getAttribute('data-post_id-ccc_favorite');

                                    const allButtons = document.querySelectorAll('.ccc-favorite-post-toggle-button');

                                    allButtons.forEach(function(btn) {
                                        if (btn.getAttribute('data-post_id-ccc_favorite') === postIdValue) {
                                            btn.classList.remove('animate__infinite');

                                            btn.addEventListener('animationend', function() {
                                                btn.classList.remove('animate__infinite');
                                            }, {
                                                once: true
                                            });
                                        }
                                    });
                                }

                            });

                        });
                    });

                document.addEventListener("DOMContentLoaded", function() {
                    
                });
            });
        })(jQuery);
    </script>
    <?php
}
add_action('wp_footer', 'starday_add_js_to_footer');

function starday_favorite_list_shortcode_function($atts)
{
    $atts = shortcode_atts(
        array(
            'current_user' => false,
        ),
        $atts,
        'starday_favorite_list_shortcode'
    );

    $user_id = absint($atts['current_user']);

    $tv_show_favorites = get_user_meta($user_id, 'tv_show_favorites', true);

    if (!empty($tv_show_favorites) && is_array($tv_show_favorites)) {
        ob_start(); ?>

        <div class="grid">
            <?php foreach ($tv_show_favorites as $post_id) {
                $post = get_post($post_id);
                $logo = (digiflex_get_option('logo')) ? digiflex_get_option('logo') : get_template_directory_uri() . '/images/logo@2x.png';

                $thumb_id = get_post_thumbnail_id($post_id);
                $thumb_url = wp_get_attachment_image_src($thumb_id, 'full')[0];

                // Verifica se a URL da imagem é válida e se a resposta é 200 OK
                $image_valid = false;
                if ($thumb_url) {
                    $response = wp_remote_head($thumb_url);
                    if (!is_wp_error($response) && $response['response']['code'] === 200) {
                        $image_valid = true;
                    }
                }

                if ($post) {
                    // Recuperar os campos personalizados para esta postagem
                    $imdb_score = get_field('tv_show_imdb_score', $post_id);
                    $select_quality = get_field('tv_show_select_quality', $post_id);
                    $producer = get_field('tv_show_producer', $post_id);
                    $release_year = get_field('tv_show_release_year', $post_id);
                    ?>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 grid-item grid-item-<?php echo $post->ID; ?>">
                        <div class="video-thumb light">
                            <?php echo do_shortcode("[starday_favorite_button post_id={$post->ID}]"); ?>
                            <a href="<?php echo get_permalink($post->ID); ?>" class="video-image">
                                <?php if ($image_valid) : ?>
                                    <img decoding="async" src="<?php echo esc_url($thumb_url); ?>" alt="<?php echo $post->post_title; ?>">
                                <?php else : ?>
                                    <img decoding="async" class="no-cover" src="<?php echo esc_url($logo); ?>" alt="<?php echo $post->post_title; ?>">
                                <?php endif; ?>
                                <?php if ($imdb_score) : ?>
                                    <div class="circle-rate">
                                        <svg class="circle-chart" viewBox="0 0 30 30" width="100" height="100" xmlns="http://www.w3.org/2000/svg">
                                            <circle class="circle-chart__background" stroke="#2f3439" stroke-width="2" fill="none" cx="15" cy="15" r="14"></circle>
                                            <circle class="circle-chart__circle" stroke="#4eb04b" stroke-width="2" stroke-dasharray="<?php echo ($imdb_score * 10 - 8); ?>,100" cx="15" cy="15" r="14"></circle>
                                        </svg>
                                        <b>
                                            <?php echo $imdb_score; ?>
                                        </b>
                                    </div>
                                    <!-- end circle-rate -->
                                <?php endif; ?>
                                <?php if ($select_quality) : ?>
                                    <div class="hd">
                                        <?php echo $select_quality; ?>
                                    </div>
                                    <!-- end hd -->
                                <?php endif; ?>
                            </a>
                            <div class="video-content">
                                <?php if ($producer) : ?>
                                    <div class="age">
                                        <?php echo $producer; ?>
                                    </div>
                                    <!-- end age -->
                                <?php endif; ?>

                                <?php if ($release_year) : ?>
                                    <small class="year">
                                        <?php echo $release_year; ?>
                                    </small>
                                <?php endif; ?>
                                <h3 class="name cgdigital">
                                    <a href="<?php the_permalink($post->ID); ?>" title="<?php echo $post->post_title; ?>" data-text="<?php echo $post->post_title; ?>">
                                        <?php echo $post->post_title; ?>
                                    </a>
                                </h3>
                            </div>
                        </div>
                    </div>
            <?php
                }
            }
            wp_reset_postdata();
            ?>
        </div>

    <?php
        return ob_get_clean();
    } else {
        return 'Você ainda não tem favoritos.';
    } ?>
<?php }
add_shortcode('starday_favorite_list_shortcode', 'starday_favorite_list_shortcode_function');