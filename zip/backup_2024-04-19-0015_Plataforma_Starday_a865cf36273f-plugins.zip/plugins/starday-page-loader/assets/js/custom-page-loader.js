document.addEventListener("DOMContentLoaded", function () {
    window.scrollTo({
        top: 0,
    });

    var reloadOnce = true;

    var loader = document.createElement('div');
    loader.classList.add('preloader-plus');
    loader.innerHTML = `
        <div class="preloader-content">   	 					
            <img class="preloader-custom-img" src="https://app.stardayoficial.com/wp-content/uploads/2023/12/logo-preloader-2.png">
            <div class="lds-css ng-scope">
                <div class="lds-dots preloader-plus-default-icons">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>        
    `;

    function hideLoader() {
        loader.style.display = 'none';
    }

    loader.style.display = 'block';

    document.body.appendChild(loader);

    jQuery.ajax({
        url: starday_custom_page_loader.ajax_url,
        type: 'POST',
        data: {
            'action': 'starday_custom_page_loader_action'
        },
        dataType: 'json',
        success: function (response) {
            if (response.reloadOnce) {
                setTimeout(() => {
                    reloadOnce = false;
                    location.reload();
                }, 3000);
            } else {
                hideLoader();
            }
        },
        error: function (xhr, status, error) {
            console.error('Erro na requisição AJAX:', status, error);
            if (reloadOnce) {
                reloadOnce = false;
                //location.reload();
            }
        }
    });

    window.onload = function () {
        window.scrollTo({
            top: 0,
        });
        setTimeout(() => {
            if (window.location.hash) {
                var targetElement = document.querySelector(window.location.hash);
                if (targetElement) {
                    setTimeout(() => {
                        var offset = targetElement.getBoundingClientRect().top;
                        window.scrollTo({
                            top: offset,
                            behavior: 'smooth'
                        });
                    }, 1100);
                }
            }
            hideLoader();
        }, 1100);
    };

    var now = new Date();
    var hora = now.toLocaleTimeString();

    var horaElement = document.getElementById('reload_history');
    horaElement.value = hora;
});


var style = document.createElement('style');
style.innerHTML = `
    body {
        background: #000;
    }
    @keyframes lds-dots {
        0% {
            opacity: 1;
            transform: scale(1);
        }
        50% {
            opacity: 1;
            transform: scale(0.5);
        }
        100% {
            opacity: 1;
            transform: scale(0.5);
        }
    }
    @-webkit-keyframes lds-dots {
        0% {
            opacity: 0;
        }
        50% {
            opacity: 0.5;
        }
        100% {
            opacity: 1;
        }
    }
    .lds-dots div {
        width: 20%;
        height: 20%;
        border-radius: 50%;
        transform: scale(0.5);
        -webkit-animation: lds-dots 1s linear infinite;
        animation: lds-dots 1s linear infinite;
    }
    .lds-dots div:nth-child(1) {
        background: #ffeded;
        -webkit-animation-delay: 0.25s;
        animation-delay: 0.25s;
    }
    .lds-dots div:nth-child(2) {
        background: #ffeded;
        -webkit-animation-delay: 0.5s;
        animation-delay: 0.5s;
    }
    .lds-dots div:nth-child(3) {
        background: #ffeded;
        -webkit-animation-delay: 0.75s;
        animation-delay: 0.75s;
    }
    .lds-dots div:nth-child(4) {
        background: #ffeded;
        -webkit-animation-delay: 1s;
        animation-delay: 1s;
    }
    .lds-dots {
        display: flex;
        flex-flow: row nowrap;
        align-items: center;
        justify-content: space-between;
    }
`;
document.head.appendChild(style);