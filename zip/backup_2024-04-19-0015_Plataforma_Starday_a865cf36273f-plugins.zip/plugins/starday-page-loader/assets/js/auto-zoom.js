var isPageVisible = true;
var connectionType = null;
var originalDownlink = null;
var originalEffectiveType = null;

function pauseConnections() {
  if (navigator.connection && navigator.connection.pause) {
    navigator.connection.pause();
  }
}

function resumeConnections() {
  if (navigator.connection && navigator.connection.resume) {
    navigator.connection.resume();
  }
}

function handleVisibilityChange() {
  if (document.hidden) {
    isPageVisible = false;
    pauseConnections();
  } else {
    isPageVisible = true;
    resumeConnections();
  }
}

document.addEventListener("visibilitychange", handleVisibilityChange, false);