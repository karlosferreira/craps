<?php
/*
Plugin Name: Starday - Page Loader
Plugin URI: https://seusite.com/starday-custom-page-loader
Description: Um plugin para adicionar um carregador de página personalizado ao seu site WordPress.
Version: 1.0
Author: Carlos Ferreira
Author URI: https://seusite.com
License: GPL v2 or later
Text Domain: starday-custom-page-loader
*/

function starday_custom_page_loader_scripts() {
    wp_enqueue_script('starday-custom-page-loader-script', plugin_dir_url(__FILE__) . 'assets/js/custom-page-loader.js', array('jquery'), '1.0', true);
    
    wp_localize_script('starday-custom-page-loader-script', 'starday_custom_page_loader', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));

    wp_enqueue_style('starday-custom-page-loader-style', plugin_dir_url(__FILE__) . 'assets/css/custom-page-loader.css', array(), '1.0');
}
add_action('wp_enqueue_scripts', 'starday_custom_page_loader_scripts');

function starday_custom_user_profile_fields($user) {
    ?>
    <h3><?php _e('Último Acesso', 'starday-custom-page-loader'); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="reload_history"><?php _e('Data e Hora', 'starday-custom-page-loader'); ?></label></th>
            <td>
                <?php
                $reload_history = get_user_meta($user->ID, 'reload_history', true);
                $formatted_reload_history = '';

                if ($reload_history) {
                    // Use a hora e a data do servidor do WordPress quando o registro foi feito
                    $formatted_reload_history = date_i18n('l, j F Y H:i:s', $reload_history);
                }

                ?>
                <span><?php echo esc_attr($formatted_reload_history); ?></span>
                <?php if ($reload_history) : ?>
                    <br>
                    <button class="button" id="delete_reload_history"><?php _e('Apagar Acesso', 'starday-custom-page-loader'); ?></button>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var deleteButton = document.getElementById('delete_reload_history');
            if (deleteButton) {
                deleteButton.addEventListener('click', function () {
                    if (confirm('<?php _e('Tem certeza de que deseja apagar o registro de último acesso?', 'starday-custom-page-loader'); ?>')) {
                        // Executar ação para apagar o registro de último acesso
                        jQuery.ajax({
                            url: '<?php echo admin_url('admin-ajax.php'); ?>',
                            type: 'POST',
                            data: {
                                action: 'delete_reload_history',
                            },
                            success: function (response) {
                                // Recarregar a página após a exclusão
                                location.reload();
                            },
                            error: function (xhr, status, error) {
                                console.error('Erro ao apagar o registro de último acesso:', status, error);
                            }
                        });
                    }
                });
            }
        });
    </script>
    <?php
}


add_action('show_user_profile', 'starday_custom_user_profile_fields');
add_action('edit_user_profile', 'starday_custom_user_profile_fields');

function starday_custom_user_profile_fields_save($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    if (isset($_POST['reload_history'])) {
        update_user_meta($user_id, 'reload_history', $_POST['reload_history']);
    }
}
add_action('personal_options_update', 'starday_custom_user_profile_fields_save');
add_action('edit_user_profile_update', 'starday_custom_user_profile_fields_save');


function starday_custom_page_loader_ajax_handler() {
    if (!is_user_logged_in()) {
        wp_die();
    }

    $current_user = wp_get_current_user();
    
    if ($current_user) {

        // $reload_history = get_user_meta($current_user->ID, 'reload_history', true);
        
        // if ($reload_history && (time() - $reload_history < 720 * 60)) {
        //     $response = array(
        //         'reloadOnce' => false
        //     );
        // } else {
        //     $response = array(
        //         'reloadOnce' => true
        //     );
        //     update_user_meta($current_user->ID, 'reload_history', time());
        // }
        
        $response = array(
            'reloadOnce' => false
        );
        
        wp_send_json($response);

    }

}
add_action('wp_ajax_starday_custom_page_loader_action', 'starday_custom_page_loader_ajax_handler'); // Para usuários logados
//add_action('wp_ajax_nopriv_starday_custom_page_loader_action', 'starday_custom_page_loader_ajax_handler');

// Função para apagar o registro de último acesso
function delete_reload_history_ajax_handler() {
    $current_user = wp_get_current_user();
    delete_user_meta($current_user->ID, 'reload_history');
    wp_die();
}
add_action('wp_ajax_delete_reload_history', 'delete_reload_history_ajax_handler');

?>