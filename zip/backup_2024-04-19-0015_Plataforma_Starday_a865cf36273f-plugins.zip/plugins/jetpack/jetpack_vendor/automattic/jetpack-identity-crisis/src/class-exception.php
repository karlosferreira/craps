<?php
/**
 * Exception class for the Identity Crisis package.
 *
 * @package  automattic/jetpack-identity-crisis
 */

namespace Automattic\Jetpack\IdentityCrisis;

/**
 * Exception class for the Identity Crisis package.
 */
class Exception extends \Exception {}
